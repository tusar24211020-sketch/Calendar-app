# Calendar 1.7.0 — verification report

## Results (final source)
- `./gradlew testDebugUnitTest lintDebug assembleRelease --no-daemon --stacktrace`: **BUILD SUCCESSFUL**.
- Native JVM tests: **11 passed, 0 failures/errors/skips** (6 date-policy tests + 5 Robolectric framework tests).
- Browser tests: **455 checks passed**, no reported failures/page errors across six suites.
- Static source validation: passed (218 aliases, 434 date icon resource references, all resource XML, receiver permissions and bridge wiring).
- JavaScript syntax checks and workflow YAML parsing: passed.
- Android lint: **0 errors, 220 warnings**. Remaining warnings concern existing icon presentation and API-specific manifest attributes, not alarm scheduling. No warnings were disabled to pass this check.
- Release APK: compiled and APK signature verified with Android Build Tools 35. App ID `com.t.calendar`, versionCode 12, versionName 1.7.0, minSdk 24, targetSdk 35.
- Original `release.keystore` and `keystore.properties`: byte-for-byte unchanged.

## Native coverage
DateRules: exact 00:00:00.000 boundary, local timezone/weekday mapping, leap days, month/year rollover, DST 23/25-hour days, nonexistent midnight/skipped day, and every JDK timezone across 2026–2028.
DateIcon (Robolectric API 33, plus API 28 legacy path): exact wakeup/allow-while-idle flags, permission-denied inexact fallback, permission-grant upgrade, independent watchdog PendingIntent, no duplicate alarms on repeated refresh, timezone-change deadline recomputation, and one enabled date alias.

## Browser checks
Date label/layout 36; header 144; interaction 27; navigation/glass 217; regression 23; new midnight setup card/bridge 8. Existing suite reports are at source root. The bridge UI test uses a fake bridge; it does not grant actual Android permissions.

## Remaining lint warning categories
- IconLauncherShape: 218
- MonochromeLauncherIcon: 1
- UnusedAttribute: 1

## Not verified on hardware
No emulator/physical-device midnight run was performed. Tests do NOT establish real-world launcher-cache latency, OEM background behavior, locked-boot delivery, force-stop recovery, or exact permission UI behavior. Use the manual device checklist in `tests/README.txt`.

Exact scheduling requires special access on Android 12+. User force-stop, powered-off devices, OEM restrictions and launcher caches prevent any honest guarantee of a visibly changing icon at exactly 12:00:00 on every phone. No foreground service, covert battery exemption, launcher restart, or unsupported security bypass is used.

The source bundle intentionally excludes generated APKs, SDK/JDK, local.properties, Gradle caches and app/build outputs. Build it using the supplied workflow. Keep the ZIP/repository private because it retains the existing signing key.
