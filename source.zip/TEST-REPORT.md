# Calendar 1.10.0 — verification report

## Current interface
The Month and Holidays dock entries are merged into one Calendar tab (Bengali:
মাস ও ছুটি). The other dock controls are Settings and date Search.
A compact 44px-tall holiday disclosure sits directly below the calendar, closed
on a fresh page load. It expands the viewed month’s search/filter/list in place.
Opening brings actual holiday names into view on mobile; closing restores the
calendar’s scroll position. It never rebuilds the calendar/input DOM on toggle.
Date/holiday-row details remain available. Android Back first closes an active
dialog/date sheet, then the holiday list. Annual holidays remain in Settings.

## Checked fixes
- Removed the duplicate holiday navigation route and corrected the dock indicator.
- Hidden list controls are not exposed as focusable content; ARIA expanded/controls
  are synchronized and the bar supports Enter/Space, keyboard focus and Back.
- Query/filter and open state survive month changes/settings visits in a session.
- Month count reflects all records, not only a temporary search result.
- Unknown data years show an explicit No data state rather than a false zero.
- Live holiday search remains intact over midnight, month-end and New Year.
- Existing safe imported-event ID handling and paused-clock CI hotfix are retained.

## Automated verification
**1,241 browser checks passed**, no reported JavaScript page errors:
- clock-glass: 64
- header: 144
- holiday-calendar: 329
- interaction: 27
- merged-bar: 401
- midnight-setup: 8
- navigation-glass: 209
- regression: 23
- date-label-layout: 36

Production DateRules.java compiled to Java 17 bytecode using the available JDK 25;
**2,078,029 assertions passed**, covering all available timezones over 2026–2028,
local midnight, weekday/day aliases, leap/year/DST boundaries and today's 00:15
recovery. These standalone checks do not emulate Android service delivery.

Static validation passed: 218 launcher aliases, 434 date icon references,
permissions, direct-boot storage, resource XML and bridge contracts. JavaScript
syntax and workflow YAML/shell syntax passed. Native DateIcon/DateRules runtime
and original signing files are unchanged. Version-only native labels are updated.

Browser checks include Bengali/English, light/dark, widths 320/390/760/900/1280,
keyboard interaction, imports/exports, event editor, navigation, bounds, filters,
collapsed/expanded and Back behavior, dock clearance and no horizontal overflow.
Visual inspection covered collapsed mobile/desktop, expanded holiday names,
light/dark glass and the updated dock/settings. All fresh logs: QA/v1100/.
Current browser JSON reports: source root. Older QA folders/reports are historical.

## Not verified / required device follow-up
- Full Android Gradle compilation, lint and Robolectric suites were NOT run here.
  The supplied GitHub workflow runs those after browser/production Java checks.
- No physical POCO X3 NFC / Android 12 / MIUI 14 or emulator midnight run.
- The complete workflow has not been executed in the user's GitHub account.
- Bundled holiday announcements were preserved, not independently revalidated.
- Alarm permission, MIUI background policy and launcher caching still affect
  actual visible icon replacement; there is no universal instant-redraw guarantee.

Application ID com.t.calendar; versionName 1.10.0; versionCode 15.
Install over the old app with the same signing key and avoid uninstalling if local
settings/events must be preserved. Keep the source private: it includes the user's
existing signing files. Replace BOTH source.zip and the workflow and start a NEW run.
