const {chromium}=require('playwright');
const fs=require('fs');
(async()=>{
  const b=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/local/bin/chromium',headless:true,args:['--no-sandbox']});
  const checks=[],errors=[];
  function check(name,ok){checks.push({name,passed:!!ok});if(!ok)throw Error(name)}
  for(const native of [false,true]) {
    const c=await b.newContext({viewport:{width:390,height:844}});
    if(native)await c.addInitScript(()=>{window.setupCalls=0;window.AndroidBridge={setTheme(){},iconSetup(){window.setupCalls++}}});
    const p=await c.newPage(); p.on('pageerror',e=>errors.push(e.message));
    await p.goto(process.env.APP_URL||'http://127.0.0.1:8766');
    await p.locator('[data-tab="3"]').click();
    check('Native-only setup card: '+native,await p.locator('[data-act="iconSetup"]').count()===(native?1:0));
    check('Version label 1.7.0: '+native,(await p.locator('#view').textContent()).includes('v1.7.0'));
    if(native){
      await p.locator('[data-act="iconSetup"]').click();
      check('Bangla card invokes native bridge',await p.evaluate(()=>window.setupCalls)===1);
      await p.locator('[data-set="lang"][data-val="en"]').click();
      check('English setup label',await p.locator('[data-act="iconSetup"]').textContent().then(s=>s.includes('Midnight icon setup')));
      await p.locator('[data-act="iconSetup"]').click();
      check('English card invokes native bridge',await p.evaluate(()=>window.setupCalls)===2);
    }
    await c.close();
  }
  await b.close();check('No JavaScript errors',errors.length===0);
  fs.writeFileSync(require('path').resolve(__dirname,'../midnight-setup-QA.json'),JSON.stringify({checks,errors},null,2));
  console.log(JSON.stringify({passed:checks.length,errors}));
})().catch(e=>{console.error(e);process.exit(1)});
