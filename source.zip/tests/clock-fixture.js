'use strict';
/** Freeze BEFORE navigation: CI/font/page-load latency must not cross midnight.
 * Install one minute earlier so pauseAt always advances rather than asking the
 * running virtual clock to travel backwards by the install call's own latency.
 */
async function installPausedClock(page, time) {
  const target = new Date(time).getTime();
  if (!Number.isFinite(target)) throw new Error('Invalid test-clock timestamp');
  await page.clock.install({time: new Date(target - 60000)});
  await page.clock.pauseAt(new Date(target));
}
module.exports = {installPausedClock};
