package com.t.calendar;
import java.util.*;
/** Standalone test of production DateRules. Does not emulate Android services. */
public final class DatePolicyCheck {
    static long checks;
    static void check(boolean ok, String label) { checks++; if (!ok) throw new AssertionError(label); }
    static long at(TimeZone z,int y,int m,int d,int h,int min,int sec) {
        Calendar c=Calendar.getInstance(z,Locale.US);c.clear();c.set(y,m-1,d,h,min,sec);return c.getTimeInMillis();
    }
    public static void main(String[] args) {
        TimeZone z=TimeZone.getTimeZone("Asia/Dhaka");
        long midnight=at(z,2026,10,22,0,0,0), backup=at(z,2026,10,22,0,15,0);
        check(DateRules.nextMidnight(midnight-1,z)==midnight,"millisecond boundary");
        check(DateRules.nextMidnight(midnight,z)==at(z,2026,10,23,0,0,0),"tomorrow primary");
        for(long t:new long[]{midnight-1,midnight,midnight+5*60000,backup-1})
            check(DateRules.nextRecovery(t,z)==backup,"today backup retained");
        check(DateRules.nextRecovery(backup,z)==at(z,2026,10,23,0,15,0),"backup moves after delivery");
        check(DateRules.alias(midnight,z).equals("Alias4_22"),"weekday/day mapping");
        check(DateRules.alias(midnight,TimeZone.getTimeZone("UTC")).equals("Alias3_21"),"phone zone mapping");
        TimeZone ny=TimeZone.getTimeZone("America/New_York");
        long spring=at(ny,2026,3,8,0,0,0),fall=at(ny,2026,11,1,0,0,0);
        check(DateRules.nextMidnight(spring,ny)-spring==23*3600000L,"spring DST");
        check(DateRules.nextMidnight(fall,ny)-fall==25*3600000L,"fall DST");
        check(DateRules.nextMidnight(at(z,2028,2,28,23,59,59),z)==at(z,2028,2,29,0,0,0),"leap day");
        check(DateRules.nextMidnight(at(z,2026,12,31,23,59,59),z)==at(z,2027,1,1,0,0,0),"year rollover");
        for(String id:TimeZone.getAvailableIDs()) {
            TimeZone zone=TimeZone.getTimeZone(id);Calendar c=Calendar.getInstance(zone,Locale.US);
            c.clear();c.set(2026,Calendar.JANUARY,1,12,34,56);
            for(int d=0;d<1096;d++,c.add(Calendar.DAY_OF_MONTH,1)) {
                long now=c.getTimeInMillis(),next=DateRules.nextMidnight(now,zone),rec=DateRules.nextRecovery(now,zone);
                check(next>now&&next-now<=27*3600000L,id+" midnight future");
                check(rec>now&&rec-now<=28*3600000L,id+" recovery future");
                check(DateRules.alias(now,zone).matches("Alias[0-6]_(0[1-9]|[12][0-9]|3[01])"),id+" alias");
            }
        }
        System.out.println("PASS: "+checks+" production date-policy assertions; Android framework not tested here.");
    }
}
