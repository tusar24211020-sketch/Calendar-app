const {chromium}=require('playwright');const fs=require('fs'),path=require('path');
(async()=>{
 const b=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/local/bin/chromium',args:['--no-sandbox']});
 const checks=[],errors=[];const ck=(name,ok)=>{checks.push({name,passed:!!ok});if(!ok)throw Error(name)};
 const url=process.env.APP_URL||'http://127.0.0.1:8766';
 for(const theme of ['light','dark'])for(const width of [320,390,760,1280])for(const lang of ['bn','en']){
  const c=await b.newContext({viewport:{width,height:844},colorScheme:theme,timezoneId:'Asia/Dhaka',reducedMotion:'reduce'});
  await c.addInitScript(({lang})=>localStorage.setItem('bc.settings',JSON.stringify({lang})),{lang});
  const p=await c.newPage();p.on('pageerror',e=>errors.push(e.message));await p.goto(url);const tag=`${theme}/${width}/${lang} `;
  ck(tag+'two tabs only',await p.locator('[role="tab"]').count()===2&&await p.locator('#tab-2').count()===0);
  ck(tag+'merged calendar label',await p.locator('#tab-0 .tab-label').textContent()===(lang==='bn'?'মাস ও ছুটি':'Calendar'));
  ck(tag+'collapsed at start',await p.locator('#holiday-toggle').getAttribute('aria-expanded')==='false'&&await p.locator('#month-holidays-panel').isHidden());
  ck(tag+'correct disclosure linkage',await p.locator('#holiday-toggle').getAttribute('aria-controls')==='month-holidays-panel');
  ck(tag+'thin bar below calendar',await p.evaluate(()=>{const a=document.querySelector('.calendar-panel').getBoundingClientRect(),r=document.querySelector('#holiday-toggle').getBoundingClientRect();return r.top>=a.bottom&&r.top-a.bottom<=12&&r.height>=44&&r.height<=52&&r.width<=innerWidth}));
  ck(tag+'hidden search is not focusable',await p.locator('#month-q').evaluate(e=>e.getClientRects().length===0));
  await p.locator('#date-search').click();await p.locator('#search-date-input').fill('2026-10-20');await p.keyboard.press('Enter');
  ck(tag+'search does not force holiday panel open',await p.locator('#month-holidays-panel').isHidden());
  await p.evaluate(()=>window.gridBefore=document.querySelector('#mgrid'));await p.locator('#holiday-toggle').focus();await p.keyboard.press('Enter');
  ck(tag+'keyboard opens list',await p.locator('#holiday-toggle').getAttribute('aria-expanded')==='true'&&await p.locator('#month-holidays-panel').isVisible());
  ck(tag+'opening preserves calendar DOM',await p.evaluate(()=>gridBefore===document.querySelector('#mgrid')));
  ck(tag+'October holiday names visible',await p.locator('.monthly-list [data-open="2026-10-20"]').isVisible());
  ck(tag+'count represents full month',await p.locator('#holiday-toggle-count').textContent()===(lang==='bn'?'৮টি':'8'));
  await p.locator('#month-q').fill('Durga');await p.evaluate(()=>window.searchBefore=document.querySelector('#month-q'));
  await p.locator('#holiday-toggle').click();
  ck(tag+'click collapses list',await p.locator('#month-holidays-panel').isHidden());
  await p.keyboard.press('Space');
  ck(tag+'space reopens same query',await p.evaluate(()=>searchBefore===document.querySelector('#month-q')&&document.querySelector('#month-q').value==='Durga')&&await p.locator('#month-holidays-panel').isVisible());
  await p.locator('#month-q').fill('');await p.locator('.monthly-list [data-open="2026-10-20"]').click();
  ck(tag+'list detail stays on calendar',await p.locator('#tab-0').getAttribute('aria-selected')==='true'&&await p.locator('#sheet').isVisible());
  await p.evaluate(()=>BanglaCalendarBack());
  ck(tag+'first Back closes only details',await p.locator('#sheet').isHidden()&&await p.locator('#month-holidays-panel').isVisible());
  ck(tag+'next Back closes holiday panel',await p.evaluate(()=>BanglaCalendarBack())&&await p.locator('#month-holidays-panel').isHidden());
  ck(tag+'Back restores bar focus',await p.evaluate(()=>document.activeElement.id==='holiday-toggle'));
  ck(tag+'calendar Back can exit when no overlay',await p.evaluate(()=>BanglaCalendarBack())===false);
  await p.locator('#holiday-toggle').click();await p.locator('[data-act="nextM"]').click();
  ck(tag+'open state follows month change',await p.locator('#month-holidays-panel').isVisible()&&await p.locator('#mgrid button.cell').count()===30&&await p.locator('.monthly-list [data-open]').evaluateAll(a=>a.every(e=>e.dataset.open.startsWith('2026-11-'))));
  await p.locator('#tab-3').click();await p.locator('#tab-0').click();
  ck(tag+'settings roundtrip preserves month and disclosure',(await p.locator('.month-title-glass b').textContent()).includes('November 2026')&&await p.locator('#month-holidays-panel').isVisible());
  await p.locator('[data-act="jump"]').click();await p.locator('#j-year').fill('2028');await p.locator('[data-jm="2"]').click();await p.locator('#j-go').click();
  ck(tag+'unknown data year is explicit',await p.locator('#holiday-toggle-count').textContent()===(lang==='bn'?'তথ্য নেই':'No data')&&await p.locator('.banner').count()>0);
  ck(tag+'leap calendar still available',await p.locator('[data-date="2028-02-29"]').count()===1);
  await p.locator('[data-act="jump"]').click();await p.locator('#j-year').fill('2026');await p.locator('[data-jm="10"]').click();await p.locator('#j-go').click();
  await p.locator('#view').evaluate(e=>e.scrollTop=e.scrollHeight);
  ck(tag+'last list row clears dock',await p.evaluate(()=>document.querySelector('.monthly-list').getBoundingClientRect().bottom<=document.querySelector('#dock').getBoundingClientRect().top));
  ck(tag+'no horizontal overflow',await p.locator('#view').evaluate(e=>e.scrollWidth<=e.clientWidth+1));
  await p.locator('#view').evaluate(e=>e.scrollTop=0);await p.evaluate(()=>document.fonts.ready);
  if(lang==='bn'&&[390,1280].includes(width)){
   await p.screenshot({path:path.resolve(__dirname,`../previews/v1100-${theme}-${width}-expanded.png`)});
   await p.locator('#holiday-toggle').click();await p.locator('#view').evaluate(e=>e.scrollTop=0);
   await p.screenshot({path:path.resolve(__dirname,`../previews/v1100-${theme}-${width}-collapsed.png`)});
  }
  await p.reload();ck(tag+'new page starts clean and collapsed',await p.locator('#holiday-toggle').getAttribute('aria-expanded')==='false');await c.close();
 }
 ck('No page errors',errors.length===0);await b.close();fs.writeFileSync(path.resolve(__dirname,'../merged-bar-QA.json'),JSON.stringify({checks,errors},null,2));console.log(JSON.stringify({passed:checks.length,errors}));
})().catch(e=>{console.error(e);process.exit(1)});
