const {chromium}=require('playwright');const fs=require('fs');
(async()=>{const b=await chromium.launch({executablePath:'/usr/local/bin/chromium',args:['--no-sandbox']});const results=[];const errors=[];
for(const theme of ['light','dark'])for(const width of [320,360,390,720,760,1280]){
const c=await b.newContext({viewport:{width,height:844},colorScheme:theme});const p=await c.newPage();p.on('pageerror',e=>errors.push(e.message));await p.goto('http://127.0.0.1:8765');await p.evaluate(()=>document.fonts.ready);
for(let month=1;month<=12;month++){
await p.locator('[data-act="jump"]').click();await p.locator('#j-year').fill('2026');await p.locator(`[data-jm="${month}"]`).click();await p.locator('#j-go').click();
const state=await p.evaluate(()=>{const btn=document.querySelector('.month-title-glass');const r=btn.getBoundingClientRect(),prev=document.querySelector('[data-act="prevM"]').getBoundingClientRect(),next=document.querySelector('[data-act="nextM"]').getBoundingClientRect();return {overflow:btn.scrollWidth>btn.clientWidth+1,overlap:r.left<prev.right||r.right>next.left,centerError:Math.abs((r.left+r.right)/2-(prev.left+next.right)/2),pageOverflow:document.querySelector('#view').scrollWidth>document.querySelector('#view').clientWidth+1,radius:getComputedStyle(btn).borderRadius}});results.push({width,theme,month,...state});
if(month===9&&[320,390,760].includes(width)){await p.waitForTimeout(100);await p.screenshot({path:`/data/header-${theme}-${width}.png`})}
}
await p.locator('[data-act="today"]').count().then(async count=>{if(count)await p.locator('[data-act="today"]').click()});if(width===390){await p.screenshot({path:`/data/header-${theme}-current.png`})}await c.close()
}await b.close();const failures=results.filter(x=>x.overflow||x.overlap||x.pageOverflow||x.centerError>1);fs.writeFileSync('/data/calendar-header-results.json',JSON.stringify({results,errors,failures},null,2));console.log(JSON.stringify({checks:results.length,failures,pageErrors:errors},null,2));if(failures.length||errors.length)process.exit(1)
})().catch(e=>{console.error(e);process.exit(1)});
