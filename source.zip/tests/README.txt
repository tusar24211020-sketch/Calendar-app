Optional browser regression tests. Requires Node, Playwright and Chromium.
Serve www/ on http://127.0.0.1:8765, then run the scripts with Node.
Scripts use isolated browser contexts and synthetic events; they are NOT device tests.
The /data output path and Chromium executable path may need adaptation to your environment.
