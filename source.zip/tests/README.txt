Calendar 1.6.0 browser QA (Node + Playwright + Chromium required)
Serve www/ on http://127.0.0.1:8766, or set APP_URL to another origin.
Run each *-qa.js with Node. CHROMIUM_PATH optionally overrides /usr/local/bin/chromium.
Use NODE_PATH if needed to locate your installed Playwright. Tests require no external internet.
Current suites: navigation-glass, regression, interaction, header, date-label-layout.
JSON reports are written at the source root. Some historical screenshot output paths use /data and may need adapting.
Tests use isolated browser storage and synthetic gestures. They are not Android device/IME/WebView tests.
