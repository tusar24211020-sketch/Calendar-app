Calendar 1.7.0 QA

Web/browser tests (Node + Playwright + Chromium)
Serve www/ on http://127.0.0.1:8766 or set APP_URL to another origin.
Run each tests/*-qa.js using Node. CHROMIUM_PATH overrides /usr/local/bin/chromium.
Use NODE_PATH if needed to locate your Playwright installation.
Suites: date-label-layout, header, interaction, navigation-glass, regression, midnight-setup.
JSON reports are written at the source root. Existing screenshot paths under /data may
need adapting on another machine. Test contexts use isolated storage.
midnight-setup-qa.js uses a FAKE bridge; it does not test Android permission dialogs.

Static consistency check
python3 tools/validate-source.py
Checks 218 aliases and their date icons, receiver, permissions, XML and bridge contracts.

Native JVM tests (JDK 17 / Android SDK 35)
cd android && ./gradlew testDebugUnitTest lintDebug assembleRelease
DateRulesTest: leap/month/year boundaries, 00:00:00 milliseconds, phone timezone mapping,
DST 23/25-hour days, skipped civil days and every available timezone across 2026–2028.
DateIconTest: Robolectric API 33 simulation plus API 28 older alias-switching path;
exact+Doze/wakeup scheduling flags, permission-denied fallback, grant upgrade,
unique PendingIntents/idempotency and timezone-change rescheduling.
Robolectric simulates framework behavior; it is not a real Android device.

Manual device test still required
1. Update existing app (do not uninstall if you need to preserve events/settings).
2. Launch once; grant Alarms & reminders; check Settings → Midnight icon setup says exact.
3. Verify next alarm is the PHONE's local 00:00:00. Leave the app closed, not force-stopped.
4. Test across midnight with screen off and with app visible. Check both date and weekday.
5. Repeat after reboot, app update, timezone change and permission deny/regrant.
6. Repeat in battery saver / OEM restricted modes; inspect diagnostics and launcher delay.
7. Check that one launcher entry remains. Some launchers cache/remove pinned alias shortcuts.
8. A force-stop is intentionally NOT expected to work until manual app launch.
9. If you manually change the phone clock for a test, restore automatic time afterwards.
Do not call the fix device-verified until these tests run on the actual target launcher.
