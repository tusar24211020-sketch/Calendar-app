'use strict';
async function openMonthlyHolidays(page) {
  await page.locator('#tab-0').click();
  if (await page.locator('#holiday-toggle').getAttribute('aria-expanded') !== 'true') {
    await page.locator('#holiday-toggle').click();
  }
}
module.exports = {openMonthlyHolidays};
