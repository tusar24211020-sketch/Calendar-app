const {installPausedClock}=require('./clock-fixture');
/* Deterministic local-clock tests; no real launcher/Android claim. */
const {chromium}=require('playwright');
const fs=require('fs'),path=require('path');
(async()=>{
 const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/local/bin/chromium',args:['--no-sandbox']});
 const checks=[],errors=[]; const ck=(name,pass)=>{checks.push({name,passed:!!pass});if(!pass)throw Error(name)};
 const url=process.env.APP_URL||'http://127.0.0.1:8766';
 for(const [zone,before,after] of [
 ['Asia/Dhaka','2026-10-21T23:59:59.500+06:00','2026-10-22'],
 ['Asia/Dhaka','2026-12-31T23:59:59.500+06:00','2027-01-01'],
 ['Asia/Dhaka','2028-02-28T23:59:59.500+06:00','2028-02-29'],
 ['America/New_York','2026-03-08T23:59:59.500-04:00','2026-03-09'],
 ['America/New_York','2026-11-01T23:59:59.500-05:00','2026-11-02'],
 ['Pacific/Auckland','2026-10-21T23:59:59.500+13:00','2026-10-22']]){
  const ctx=await browser.newContext({timezoneId:zone,viewport:{width:390,height:844}});
  const p=await ctx.newPage();p.on('pageerror',e=>errors.push(e.message));
  await installPausedClock(p, before);await p.goto(url);
  // Simulate a loaded CI runner. No virtual time may elapse during this delay.
  if (zone==='America/New_York') await p.waitForTimeout(800);
  const old=before.slice(0,10);
  ck(zone+' known pre-midnight date '+old,await p.evaluate(()=>BC.todayStr())===old);
  ck(zone+' phone timezone enabled',await p.evaluate(()=>BC.settings().deviceZone));
  await p.evaluate(()=>window.savedTab=document.querySelector('#tab-0'));
  await p.clock.runFor(499);
  ck(zone+' no early date transition',await p.locator(`[data-date="${old}"]`).getAttribute('aria-current')==='date');
  await p.clock.runFor(2);
  ck(zone+' precise midnight '+after,await p.evaluate(()=>BC.todayStr())===after);
  ck(zone+' midnight render not 30 seconds late',await p.locator(`[data-date="${after}"]`).getAttribute('aria-current')==='date');
  ck(zone+' selected today rolls forward',await p.locator(`[data-date="${after}"]`).getAttribute('aria-pressed')==='true');
  ck(zone+' dock date updated',await p.locator('#tab-0 .ico').getAttribute('data-icon-date')===after);
  ck(zone+' tab node preserved',await p.evaluate(()=>savedTab===document.querySelector('#tab-0')));
  ck(zone+' old date no longer today',await p.locator(`[data-date="${old}"][aria-current="date"]`).count()===0);
  await ctx.close();
 }
 const ctx=await browser.newContext({timezoneId:'Asia/Dhaka',viewport:{width:390,height:844},reducedMotion:'reduce'});
 const p=await ctx.newPage();p.on('pageerror',e=>errors.push(e.message));
 await installPausedClock(p, '2026-10-21T23:59:59.500+06:00');await p.goto(url);
 await p.locator('[data-act="prevM"]').click();
 const historical=await p.locator('.month-title-glass b').textContent();
 await p.locator('#date-search').click();await p.locator('#search-date-input').fill('2028-02');
 await p.clock.runFor(501);
 ck('Historical browsing not hijacked at midnight',historical===await p.locator('.month-title-glass b').textContent());
 ck('Unsaved modal input survives midnight',await p.locator('#search-date-input').inputValue()==='2028-02');
 ck('Reduced motion does not animate date icon',await p.locator('#tab-0 .ico').evaluate(e=>e.getAnimations().length===0));
 await p.keyboard.press('Escape');
 await p.evaluate(()=>{window.savedTab=document.querySelector('#tab-0');document.querySelector('#tab-2').click()});
 ck('Smooth tab transitions preserve buttons',await p.evaluate(()=>savedTab===document.querySelector('#tab-0')));
 await p.locator('#tab-3').click();
 await p.locator('[data-act="openAnnual"]').click();await p.locator('#q').fill('custom search');
 await p.clock.setSystemTime(new Date('2026-10-23T01:00:00+06:00'));await p.evaluate(()=>BC.syncClock());
 ck('Annual search text survives clock change',await p.locator('#q').inputValue()==='custom search');
 await p.evaluate(()=>BanglaCalendarBack());await p.locator('#tab-0').click();
 await p.evaluate(()=>{window.realHidden=Object.getOwnPropertyDescriptor(document,'hidden');Object.defineProperty(document,'hidden',{configurable:true,value:true});document.dispatchEvent(new Event('visibilitychange'))});
 await p.clock.setSystemTime(new Date('2026-10-24T01:00:00+06:00'));
 await p.evaluate(()=>{delete document.hidden;document.dispatchEvent(new Event('visibilitychange'))});
 ck('Wake/visibility catches up immediately',await p.locator('#tab-0 .ico').getAttribute('data-icon-date')==='2026-10-24');
 await ctx.close();
 // One-time migration corrects old Dhaka default; later explicit choice persists.
 const migration=await browser.newContext({timezoneId:'America/Los_Angeles'});
 await migration.addInitScript(()=>{if(!localStorage.getItem('seeded')){localStorage.setItem('bc.settings',JSON.stringify({deviceZone:false,lang:'en'}));localStorage.setItem('seeded','1')}});
 const mp=await migration.newPage();await installPausedClock(mp, '2026-10-22T02:00:00Z');await mp.goto(url);
 ck('Upgrade migrates old timezone default',await mp.evaluate(()=>BC.settings().deviceZone===true&&BC.todayStr()==='2026-10-21'));
 await mp.locator('#tab-3').click();await mp.locator('[data-set="deviceZone"][data-val="false"]').click();await mp.reload();
 ck('Explicit Dhaka preference survives reload',await mp.evaluate(()=>!BC.settings().deviceZone&&BC.todayStr()==='2026-10-22'));
 ck('Dock still uses PHONE date in Dhaka view',await mp.locator('#tab-0 .ico').getAttribute('data-icon-date')==='2026-10-21');
 await migration.close();
 ck('No JavaScript errors',errors.length===0);
 await browser.close();fs.writeFileSync(path.resolve(__dirname,'../clock-glass-QA.json'),JSON.stringify({checks,errors},null,2));
 console.log(JSON.stringify({passed:checks.length,errors}));
})().catch(e=>{console.error(e);process.exit(1)});
