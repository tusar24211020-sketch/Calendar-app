const {chromium} = require('playwright');
const fs = require('fs');
(async () => {
 const browser = await chromium.launch({executablePath:'/usr/local/bin/chromium',headless:true,args:['--no-sandbox']});
 const results=[]; const errors=[];
 for (const theme of ['light','dark']) {
  const context=await browser.newContext({viewport:{width:390,height:844},colorScheme:theme});
  const p=await context.newPage(); p.on('pageerror',e=>errors.push(e.message));
  await p.goto('http://127.0.0.1:8765');await p.evaluate(()=>document.fonts.ready); await p.waitForTimeout(200);
  for (let tab=0;tab<4;tab++) {
   await p.locator(`[data-tab="${tab}"]`).click();await p.waitForTimeout(300);
   await p.screenshot({path:`/data/calendar-${theme}-${['month','year','holidays','settings'][tab]}.png`});
   const state=await p.evaluate(()=>{
    const n=document.querySelector('#tabs'),r=n.getBoundingClientRect(),v=document.querySelector('#view');
    return {selected:document.querySelector('[aria-selected="true"]').dataset.tab,horizontalOverflow:v.scrollWidth>v.clientWidth+1,
      dockInside:r.left>=0&&r.right<=innerWidth&&r.bottom<=innerHeight,blur:getComputedStyle(n).backdropFilter,radius:getComputedStyle(n).borderRadius};
   });results.push({theme,tab,...state});
  }
  // Theme switching persists; native bridge is deliberately absent in browser tests.
  await p.locator('[data-set="theme"][data-val="dark"]').click();
  if(await p.locator('html').getAttribute('data-theme')!=='dark')throw Error('Theme did not apply');
  await p.locator('[data-set="theme"][data-val="light"]').click();
  await p.reload(); if(await p.locator('html').getAttribute('data-theme')!=='light')throw Error('Theme not persisted');
  await p.locator('[data-tab="3"]').click();
  await p.locator(`[data-set="theme"][data-val="${theme}"]`).click();
  await p.locator('[data-tab="0"]').click();
  const before=await p.locator('.hdr .title b').textContent();await p.locator('[data-act="nextM"]').click();
  if(await p.locator('.hdr .title b').textContent()===before)throw Error('Month next broken');
  await p.locator('[data-act="prevM"]').click();
  await p.locator('button.cell[data-date]').first().click();await p.waitForTimeout(150);
  await p.screenshot({path:`/data/calendar-${theme}-sheet.png`});
  if(await p.locator('#sheet').isHidden())throw Error('Date sheet did not open');
  await p.locator('[data-act="addSheet"]').click();await p.waitForTimeout(150);
  await p.screenshot({path:`/data/calendar-${theme}-editor.png`});
  if(await p.locator('#modal').isHidden())throw Error('Event editor did not open');
  if(await p.locator('#f-time').isVisible())throw Error('All-day time field should be hidden');
  await p.locator('#e-allday').uncheck();
  if(!await p.locator('#f-time').isVisible())throw Error('Time field should appear');
  await p.locator('#e-allday').check();
  await p.evaluate(()=>window.BanglaCalendarBack());
  if(!await p.locator('#modal').isHidden())throw Error('Back did not close modal');
  await p.evaluate(()=>window.BanglaCalendarBack());
  await p.locator('[data-tab="1"]').click();await p.locator('#tab-1').focus();await p.keyboard.press('ArrowRight');
  if(await p.locator('[aria-selected="true"]').getAttribute('data-tab')!=='2')throw Error('Keyboard tab switch broken');
  // Save a real event and verify persistence after reload.
  await p.locator('[data-tab="0"]').click();
  await p.locator('button.cell[data-date]').first().click();
  await p.locator('[data-act="addSheet"]').click();
  await p.locator('#e-title').fill('Glass QA event');
  await p.locator('#e-save').click();
  if(!await p.locator('#sheet').textContent().then(t=>t.includes('Glass QA event')))throw Error('Event save broken');
  await p.reload();
  const saved=await p.evaluate(()=>JSON.parse(localStorage.getItem('bc.events')||'[]'));
  if(!saved.some(e=>e.title==='Glass QA event'))throw Error('Event persistence broken');
  await context.close();
 }
 for (const width of [320,360,760,1280]) {
  const context=await browser.newContext({viewport:{width,height:844},colorScheme:'light'});
  const p=await context.newPage();await p.goto('http://127.0.0.1:8765');await p.evaluate(()=>document.fonts.ready);
  for(let tab=0;tab<4;tab++) {
   await p.locator(`[data-tab="${tab}"]`).click();
   const overflow=await p.evaluate(()=>document.querySelector('#view').scrollWidth>document.querySelector('#view').clientWidth+1);
   results.push({width,tab,horizontalOverflow:overflow});
  }
  await p.locator('[data-tab="0"]').click();
  await p.waitForTimeout(300);
  if(width===320||width===1280)await p.screenshot({path:`/data/calendar-width-${width}.png`});
  await context.close();
 }
 await browser.close();
 fs.writeFileSync('/data/calendar-qa-results.json',JSON.stringify({results,errors},null,2));
 const bad=results.filter(x=>x.horizontalOverflow||x.dockInside===false);
 console.log(JSON.stringify({tested:results.length,pageErrors:errors,layoutFailures:bad,interactionTests:'passed'},null,2));
 if(bad.length||errors.length)process.exit(1);
})().catch(e=>{console.error(e);process.exit(1)});
