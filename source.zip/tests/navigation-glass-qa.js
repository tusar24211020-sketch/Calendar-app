const{chromium}=require('playwright');const fs=require('fs');const root=require('path').resolve(__dirname,'..');
(async()=>{const b=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/local/bin/chromium',args:['--no-sandbox']});const checks=[],errors=[];const ck=(name,ok)=>{checks.push({name,passed:!!ok});if(!ok)throw Error(name)};
for(const theme of ['light','dark'])for(const width of [320,390,760,1280]){
 const ctx=await b.newContext({viewport:{width,height:844},colorScheme:theme,reducedMotion:'reduce'});const p=await ctx.newPage();p.on('pageerror',e=>errors.push(e.message));await p.goto(process.env.APP_URL||'http://127.0.0.1:8766');await p.evaluate(()=>document.fonts.ready);
 const prefix=`${theme}/${width}: `;
 ck(prefix+'Year tab removed',await p.locator('#tab-1').count()===0);ck(prefix+'Three tabs plus separate date search',await p.locator('[role="tab"]').count()===3&&await p.locator('#date-search').count()===1);
 ck(prefix+'No month holiday bar on calendar',await p.locator('.holhead,.holiday-card').count()===0);
 await p.locator('#date-search').click();await p.locator('#search-date-input').fill('১৬/১০/২০২৬');await p.keyboard.press('Enter');
 ck(prefix+'Search preserved with Bangla digits',await p.locator('[data-date="2026-10-16"]').getAttribute('aria-pressed')==='true');await p.locator('#tab-0').click();
 if(width===390)await p.screenshot({path:`${root}/previews/${theme}-month.png`});
 if(theme==='dark'&&[320,1280].includes(width))await p.screenshot({path:`${root}/previews/dark-${width}.png`});
 await p.locator('#tab-2').click();
 ck(prefix+'Monthly holidays heading',await p.locator('#view').textContent().then(t=>t.includes('এই মাসের ছুটি')));
 ck(prefix+'Monthly list limited to viewed month',await p.locator('[data-open]').evaluateAll(a=>a.length>0&&a.every(e=>e.dataset.open.startsWith('2026-10-'))));
 if(width===390)await p.screenshot({path:`${root}/previews/${theme}-monthly-holidays.png`});
 await p.locator('[data-act="nextM"]').click();ck(prefix+'Monthly navigation stays scoped',await p.locator('[data-open]').evaluateAll(a=>a.every(e=>e.dataset.open.startsWith('2026-11-'))));
 await p.locator('#tab-0').click();ck(prefix+'Month and Holidays share displayed month',(await p.locator('.month-title-glass b').textContent()).includes('November 2026'));
 await p.locator('#tab-2').click();await p.locator('[data-act="prevM"]').click();
 await p.locator('[data-month-filter="1"]').click();ck(prefix+'Public filter only public',await p.locator('.monthly-list .cat').evaluateAll(a=>a.length>0&&a.every(e=>e.classList.contains('k-pub'))));
 await p.locator('[data-month-filter="2"]').click();ck(prefix+'Optional filter only optional',await p.locator('.monthly-list .cat').evaluateAll(a=>a.length>0&&a.every(e=>e.classList.contains('k-opt'))));
 await p.locator('[data-month-filter="0"]').click();await p.locator('#month-q').fill('NO-MATCH-ZZZ');ck(prefix+'Month empty search state',await p.locator('[data-open]').count()===0);await p.locator('#month-q').fill('');
 await p.locator('#tab-3').click();ck(prefix+'Yearly list now reachable in Settings',await p.locator('[data-act="openAnnual"]').isVisible());
 if(width===390)await p.screenshot({path:`${root}/previews/${theme}-settings.png`});
 await p.locator('[data-act="openAnnual"]').click();ck(prefix+'Annual subpage opens under Settings',await p.locator('[data-act="closeAnnual"]').isVisible()&&await p.locator('#tab-3').getAttribute('aria-selected')==='true');
 ck(prefix+'Annual list spans several months',await p.locator('[data-open]').evaluateAll(a=>new Set(a.map(e=>e.dataset.open.slice(0,7))).size>1));
 if(width===390)await p.screenshot({path:`${root}/previews/${theme}-annual-holidays.png`});
 await p.locator('[data-act="nextY"]').click();ck(prefix+'Annual year controls work',await p.locator('.hdr .title b').textContent().then(t=>t.includes('২০২৭')));
 await p.evaluate(()=>BanglaCalendarBack());ck(prefix+'Native Back returns annual to Settings',await p.locator('[data-act="openAnnual"]').isVisible());
 ck(prefix+'Back restores annual opener focus',await p.evaluate(()=>document.activeElement.dataset.act==='openAnnual'));
 await p.locator('#tab-0').click();ck(prefix+'Annual year browsing does not change month',(await p.locator('.month-title-glass b').textContent()).includes('October 2026'));
 await p.locator('#tab-0').focus();await p.keyboard.press('ArrowRight');ck(prefix+'Tab arrow skips removed Year',await p.locator('#tab-2').getAttribute('aria-selected')==='true');await p.keyboard.press('End');ck(prefix+'End selects Settings',await p.locator('#tab-3').getAttribute('aria-selected')==='true');await p.keyboard.press('Home');ck(prefix+'Home selects Month',await p.locator('#tab-0').getAttribute('aria-selected')==='true');
 for(const value of ['31/02/2026','29/02/2027','2300-01-01']){await p.locator('#date-search').click();await p.locator('#search-date-input').fill(value);await p.keyboard.press('Enter');ck(prefix+'Reject invalid date '+value,await p.locator('#search-date-input').getAttribute('aria-invalid')==='true');await p.keyboard.press('Escape')}
 if(width===390&&theme==='dark'){await p.locator('#date-search').click();await p.screenshot({path:`${root}/previews/dark-search.png`});await p.locator('#search-date-input').fill('31/02/2026');await p.keyboard.press('Enter');await p.screenshot({path:`${root}/previews/dark-search-error.png`});await p.keyboard.press('Escape');await p.locator('[data-date="2026-10-16"]').click();await p.screenshot({path:`${root}/previews/dark-details.png`});await p.locator('[data-act="addSheet"]').click();await p.screenshot({path:`${root}/previews/dark-editor.png`});await p.evaluate(()=>BanglaCalendarBack());await p.evaluate(()=>BanglaCalendarBack());}
 for(const tab of [0,2,3]){await p.locator(`#tab-${tab}`).click();const m=await p.evaluate(()=>{const v=document.querySelector('#view'),d=document.querySelector('#dock'),r=d.getBoundingClientRect();return {overflow:v.scrollWidth>v.clientWidth+1,inside:r.left>=0&&r.right<=innerWidth&&r.bottom<=innerHeight,touch:[...d.querySelectorAll('button')].every(e=>{const r=e.getBoundingClientRect();return r.width>=44&&r.height>=44}),blur:getComputedStyle(d).backdropFilter}});ck(prefix+'Layout, touch targets and glass on tab '+tab,!m.overflow&&m.inside&&m.touch&&m.blur.includes('32px'));}
 await ctx.close();
}
ck('No page errors',errors.length===0);await b.close();fs.writeFileSync(`${root}/navigation-glass-QA.json`,JSON.stringify({checks,errors},null,2));console.log(JSON.stringify({passed:checks.length,errors}));})().catch(e=>{console.error(e);process.exit(1)});
