const {chromium}=require('playwright');const fs=require('fs'),path=require('path');
(async()=>{
 const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/local/bin/chromium',args:['--no-sandbox']});
 const checks=[],errors=[];const ck=(name,ok)=>{checks.push({name,passed:!!ok});if(!ok)throw Error(name)};
 const url=process.env.APP_URL||'http://127.0.0.1:8766';
 for(const theme of ['light','dark'])for(const width of [320,390,900,1280])for(const lang of ['bn','en']){
  const ctx=await browser.newContext({viewport:{width,height:844},colorScheme:theme,timezoneId:'Asia/Dhaka',reducedMotion:'reduce'});
  await ctx.addInitScript(({lang})=>localStorage.setItem('bc.settings',JSON.stringify({lang})),{lang});
  const p=await ctx.newPage();p.on('pageerror',e=>errors.push(e.message));await p.goto(url);
  const tag=`${theme}/${width}/${lang} `;
  await p.locator('#date-search').click();await p.locator('#search-date-input').fill('2026-10-20');await p.keyboard.press('Enter');await p.locator('#tab-2').click();
  ck(tag+'calendar shown inside Holidays',await p.locator('.holiday-calendar #mgrid button.cell').count()===31);
  ck(tag+'month list shown on same page',await p.locator('.holiday-list-pane .monthly-list').count()===1);
  ck(tag+'active tab remains Holidays',await p.locator('#tab-2').getAttribute('aria-selected')==='true');
  ck(tag+'holiday date marked green',await p.locator('[data-date="2026-10-20"] .n').evaluate(e=>e.classList.contains('c-green')));
  ck(tag+'selected date names shown',await p.locator('#holiday-selected li').count()>0);
  const expected=await p.locator('[data-date="2026-10-20"]').getAttribute('aria-label');
  ck(tag+'date accessibility includes holiday name',expected.includes('Durga'));
  await p.locator('[data-date="2026-10-20"]').click();
  ck(tag+'date opens matching holiday details',(await p.locator('#sheet .rec .nm').allTextContents()).some(t=>t.includes(lang==='bn'?'দুর্গাপূজা':'Durga')));
  await p.keyboard.press('Escape');
  ck(tag+'closing details returns date focus',await p.evaluate(()=>document.activeElement.dataset.date==='2026-10-20'));
  ck(tag+'date details did not switch tabs',await p.locator('#tab-2').getAttribute('aria-selected')==='true');
  await p.locator('.monthly-list [data-open="2026-10-20"]').click();await p.keyboard.press('Escape');
  ck(tag+'list details preserve Holidays',await p.locator('#tab-2').getAttribute('aria-selected')==='true');
  await p.evaluate(()=>{window.originalGrid=document.querySelector('#mgrid');window.originalSearch=document.querySelector('#month-q')});
  await p.locator('#month-q').fill('NO-MATCH-ZZZ');
  ck(tag+'empty search retains calendar',await p.locator('#mgrid button.cell').count()===31&&await p.locator('.monthly-list [data-open]').count()===0);
  ck(tag+'typing preserves search and calendar DOM',await p.evaluate(()=>originalGrid===document.querySelector('#mgrid')&&originalSearch===document.querySelector('#month-q')));
  await p.locator('#month-q').fill('');await p.locator('[data-month-filter="2"]').click();
  ck(tag+'optional filter list correct',await p.locator('.monthly-list .cat').evaluateAll(a=>a.length>0&&a.every(e=>e.classList.contains('k-opt'))));
  ck(tag+'filter does not hide calendar dates',await p.locator('#mgrid button.cell').count()===31);
  await p.locator('[data-month-filter="0"]').click();
  await p.locator('[data-act="nextM"]').click();
  ck(tag+'month arrow updates both panes',await p.locator('#mgrid button.cell').count()===30&&await p.locator('.monthly-list [data-open]').evaluateAll(a=>a.every(e=>e.dataset.open.startsWith('2026-11-'))));
  ck(tag+'another month does not invent a selected holiday',await p.locator('#holiday-selected li').count()===0&&await p.locator('#mgrid [aria-pressed="true"]').count()===0);
  await p.locator('[data-act="jump"]').click();await p.locator('#j-year').fill('2028');await p.locator('[data-jm="2"]').click();await p.locator('#j-go').click();
  ck(tag+'month picker preserves Holidays and leap day',await p.locator('#tab-2').getAttribute('aria-selected')==='true'&&await p.locator('[data-date="2028-02-29"]').count()===1);
  ck(tag+'missing year warns without hiding calendar',await p.locator('.banner').count()>0&&await p.locator('#mgrid button.cell').count()===29);
  await p.locator('[data-act="jump"]').click();await p.locator('#j-year').fill('2026');await p.locator('[data-jm="10"]').click();await p.locator('#j-go').click();
  await p.locator('[data-date="2026-10-20"]').click();await p.keyboard.press('Escape');
  await p.locator('#view').evaluate(e=>e.scrollTop=0);await p.evaluate(()=>document.fonts.ready);
  ck(tag+'no horizontal overflow',await p.locator('#view').evaluate(e=>e.scrollWidth<=e.clientWidth+1));
  ck(tag+'calendar clears dock when scrolled to bottom',await p.evaluate(()=>{const v=document.querySelector('#view');v.scrollTop=v.scrollHeight;const pane=document.querySelector('.holiday-list-pane');return pane.getBoundingClientRect().bottom<=document.querySelector('#dock').getBoundingClientRect().top}));
  await p.locator('#view').evaluate(e=>e.scrollTop=0);
  if(lang==='bn'&&[390,1280].includes(width))await p.screenshot({path:path.resolve(__dirname,`../previews/v190-${theme}-${width}-holidays.png`)});
  await ctx.close();
 }
 // Midnight while typing in the holiday search must retain the same editable input.
 const ctx=await browser.newContext({timezoneId:'Asia/Dhaka'}),p=await ctx.newPage();
 p.on('pageerror',e=>errors.push(e.message));await p.clock.install({time:new Date('2026-10-21T23:59:59.500+06:00')});await p.goto(url);await p.locator('#tab-2').click();await p.locator('#month-q').fill('Durga');await p.evaluate(()=>window.field=document.querySelector('#month-q'));await p.clock.runFor(501);
 ck('Midnight preserves live holiday input',await p.evaluate(()=>field===document.querySelector('#month-q')&&field.value==='Durga'));
 ck('Midnight updates holiday calendar today',await p.locator('[data-date="2026-10-22"]').getAttribute('aria-current')==='date');await ctx.close();
 // Month/year-boundary resync must not replace an active mobile search field.
 for(const [before,after] of [['2026-10-31T23:59:59.500+06:00','2026-11-01'],['2026-12-31T23:59:59.500+06:00','2027-01-01']]){
  const c=await browser.newContext({timezoneId:'Asia/Dhaka'}),page=await c.newPage();
  page.on('pageerror',e=>errors.push(e.message));await page.clock.install({time:new Date(before)});await page.goto(url);await page.locator('#tab-2').click();await page.locator('#month-q').fill('unchanged text');await page.evaluate(()=>window.field=document.querySelector('#month-q'));await page.clock.runFor(501);
  ck(after+' midnight retains live input',await page.evaluate(()=>field===document.querySelector('#month-q')&&field.value==='unchanged text'));
  ck(after+' calendar advances to new month',await page.locator(`[data-date="${after}"]`).getAttribute('aria-current')==='date');await c.close();
 }
 // Imported event identifiers must never become executable markup.
 const secure=await browser.newContext();await secure.addInitScript(()=>localStorage.setItem('bc.events',JSON.stringify([{id:'bad" onclick="window.injected=1',date:'2026-10-20',title:'Safe imported event',allDay:true}])));
 const sp=await secure.newPage();await sp.goto(url);await sp.locator('#date-search').click();await sp.locator('#search-date-input').fill('2026-10-20');await sp.keyboard.press('Enter');await sp.locator('[data-date="2026-10-20"]').click();
 ck('Imported ID is escaped in edit action',await sp.locator('[data-edit]').getAttribute('data-edit')==='bad" onclick="window.injected=1');
 ck('Imported ID cannot inject event handler',await sp.locator('[data-edit]').getAttribute('onclick')===null);
 await secure.close();ck('No page errors',errors.length===0);await browser.close();
 fs.writeFileSync(path.resolve(__dirname,'../holiday-calendar-QA.json'),JSON.stringify({checks,errors},null,2));console.log(JSON.stringify({passed:checks.length,errors}));
})().catch(e=>{console.error(e);process.exit(1)});
