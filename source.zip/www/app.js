/* বাংলা ক্যালেন্ডার — অফলাইন HTML অ্যাপ (com.t.calendar)
 * রঙের নিয়ম: শুক্র ও শনি সবসময় লাল; রবি–বৃহস্পতি সরকারি ছুটি (GENERAL/EXECUTIVE/SPECIAL) সবুজ; বাকি সব সাধারণ।
 */
(function () {
  'use strict';

  // ---------- Storage ----------
  const LS = {
    get(k, d) { try { const v = localStorage.getItem('bc.' + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem('bc.' + k, JSON.stringify(v)); } catch (e) {} },
  };
  const MIN_Y = 1900, MAX_Y = 2299;
  const defaults = { lang: 'bn', theme: 'system', weekStart: 0, showBangla: true, showIslamic: true, hijriShift: -1, deviceZone: true };
  const storedSettings = LS.get('settings', {});
  let settings = Object.assign({}, defaults, storedSettings && typeof storedSettings === 'object' && !Array.isArray(storedSettings) ? storedSettings : {});
  if (!['bn', 'en'].includes(settings.lang)) settings.lang = defaults.lang;
  if (!['system', 'light', 'dark'].includes(settings.theme)) settings.theme = defaults.theme;
  if (![0, 1, 6].includes(settings.weekStart)) settings.weekStart = defaults.weekStart;
  if (![-2, -1, 0, 1].includes(settings.hijriShift)) settings.hijriShift = defaults.hijriShift;
  ['showBangla', 'showIslamic', 'deviceZone'].forEach((k) => {
    if (typeof settings[k] !== 'boolean') settings[k] = defaults[k];
  });
  // One-time upgrade: both the page and launcher initially follow the phone clock.
  // Users may still explicitly choose Dhaka in Settings afterwards.
  if (LS.get('clockPolicy', '') !== 'phone-v180') {
    settings.deviceZone = true;
    LS.set('settings', settings); LS.set('clockPolicy', 'phone-v180');
  }
  let events = LS.get('events', []);          // {id,title,desc,date,allDay,time}
  let imported = LS.get('imported', {});
  if (!imported || typeof imported !== 'object' || Array.isArray(imported)) imported = {};      // year -> holiday-year JSON

  // ---------- Dates (all as 'YYYY-MM-DD' strings, calculated in UTC to avoid DST/zone bugs) ----------
  const pad = (n) => String(n).padStart(2, '0');
  const iso = (y, m, d) => `${y}-${pad(m)}-${pad(d)}`;
  const parse = (s) => { const [y, m, d] = s.split('-').map(Number); return { y, m, d }; };
  const epochDay = (s) => { const p = parse(s); return Math.floor(Date.UTC(p.y, p.m - 1, p.d) / 86400000); };
  const fromEpoch = (e) => { const t = new Date(e * 86400000); return iso(t.getUTCFullYear(), t.getUTCMonth() + 1, t.getUTCDate()); };
  const addDays = (s, n) => fromEpoch(epochDay(s) + n);
  const dow = (s) => ((epochDay(s) % 7) + 7 + 4) % 7; // 1970-01-01 was Thursday → 0=Sun … 6=Sat
  const daysInMonth = (y, m) => new Date(Date.UTC(y, m, 0)).getUTCDate();
  const isLeap = (y) => (y % 4 === 0 && y % 100 !== 0) || y % 400 === 0;
  function validDate(s) {
    if (typeof s !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
    const p = parse(s);
    return p.y >= MIN_Y && p.y <= MAX_Y && p.m >= 1 && p.m <= 12 && p.d >= 1 && p.d <= daysInMonth(p.y, p.m);
  }
  function normalizeEvent(x) {
    if (!x || typeof x !== 'object' || typeof x.title !== 'string' || !x.title.trim() || !validDate(x.date)) return null;
    const allDay = x.allDay !== false;
    return { id: typeof x.id === 'string' && x.id ? x.id : uid(),
      title: x.title.trim().slice(0, 200), desc: typeof x.desc === 'string' ? x.desc : '', date: x.date,
      allDay, time: allDay ? null : (/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(x.time || '') ? x.time : '09:00') };
  }
  const storedEventIds = new Set();
  events = (Array.isArray(events) ? events : []).map(normalizeEvent).filter((x) => {
    if (!x || storedEventIds.has(x.id)) return false;
    storedEventIds.add(x.id); return true;
  });

  const isWeekly = (s) => { const w = dow(s); return w === 5 || w === 6; };
  function todayStr() {
    const opt = settings.deviceZone ? {} : { timeZone: 'Asia/Dhaka' };
    try {
      const parts = new Intl.DateTimeFormat('en-CA', Object.assign({ year: 'numeric', month: '2-digit', day: '2-digit' }, opt)).formatToParts(new Date());
      const g = (t) => parts.find((p) => p.type === t).value;
      return `${g('year')}-${g('month')}-${g('day')}`;
    } catch (e) { const d = new Date(); return iso(d.getFullYear(), d.getMonth() + 1, d.getDate()); }
  }

  // ---------- Bengali calendar (Bangladesh revised; 1 Boishakh = 14 April) ----------
  function bnMonthLengths(startYear) { return [31, 31, 31, 31, 31, 31, 30, 30, 30, 30, isLeap(startYear + 1) ? 30 : 29, 30]; }
  function toBangla(s) {
    const p = parse(s);
    const base = (p.m < 4 || (p.m === 4 && p.d < 14)) ? p.y - 1 : p.y;
    let rem = epochDay(s) - epochDay(iso(base, 4, 14));
    const L = bnMonthLengths(base); let mi = 0;
    while (rem >= L[mi]) { rem -= L[mi]; mi++; }
    return { y: base - 593, m: mi, d: rem + 1 };
  }

  // ---------- Islamic (Hijri) calendar ----------
  // Umm al-Qura (via Intl) shifted by settings.hijriShift days. Bangladesh sights the moon locally, usually ~1 day after Saudi → default -1.
  function hjParts(f, e) {
    try {
      const o = {}; f.formatToParts(new Date(e * 86400000 + 43200000)).forEach((x) => { o[x.type] = x.value; });
      const y = +o.year, m = +o.month, d = +o.day;
      return y > 0 && m >= 1 && m <= 12 && d >= 1 && d <= 30 ? { y, m, d } : null;
    } catch (err) { return null; }
  }
  function hjCivil(e) { // tabular Islamic calendar, fallback if Intl has no Islamic calendar
    const EPOCH = 1948439.5, jd = e + 2440587.5;
    const toJd = (yy, mm, dd) => dd + Math.ceil(29.5 * (mm - 1)) + (yy - 1) * 354 + Math.floor((3 + 11 * yy) / 30) + EPOCH - 1;
    const y = Math.floor((30 * (jd - EPOCH) + 10646) / 10631);
    const m = Math.min(12, Math.ceil((jd - (29 + toJd(y, 1, 1))) / 29.5) + 1);
    return { y, m, d: jd - toJd(y, m, 1) + 1 };
  }
  const hjFmt = (() => {
    try {
      const f = new Intl.DateTimeFormat('en-u-ca-islamic-umalqura-nu-latn', { timeZone: 'UTC', day: 'numeric', month: 'numeric', year: 'numeric' });
      const p = hjParts(f, Math.floor(Date.UTC(2026, 2, 20) / 86400000));
      return p && p.y === 1447 && p.m === 10 && p.d === 1 ? f : null;
    } catch (err) { return null; }
  })();
  const hjCache = new Map();
  function toHijri(s) {
    const e = epochDay(s) + (+settings.hijriShift || 0), key = e;
    let r = hjCache.get(key); if (r) return r;
    r = (hjFmt && hjParts(hjFmt, e)) || hjCivil(e); hjCache.set(key, r); return r;
  }

  // ---------- Strings ----------
  const BN_DIG = '০১২৩৪৫৬৭৮৯';
  const S = {
    bn: {
      tabs: ['মাস', 'বছর', 'ছুটি', 'সেটিংস'], today: 'আজ', months: ['জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'],
      bmonths: ['বৈশাখ', 'জ্যৈষ্ঠ', 'আষাঢ়', 'শ্রাবণ', 'ভাদ্র', 'আশ্বিন', 'কার্তিক', 'অগ্রহায়ণ', 'পৌষ', 'মাঘ', 'ফাল্গুন', 'চৈত্র'],
      wd: ['রবিবার', 'সোমবার', 'মঙ্গলবার', 'বুধবার', 'বৃহস্পতিবার', 'শুক্রবার', 'শনিবার'], wds: ['রবি', 'সোম', 'মঙ্গল', 'বুধ', 'বৃহঃ', 'শুক্র', 'শনি'],
      hmonths: ['মুহাররম', 'সফর', 'রবিউল আউয়াল', 'রবিউস সানি', 'জমাদিউল আউয়াল', 'জমাদিউস সানি', 'রজব', 'শাবান', 'রমজান', 'শাওয়াল', 'জিলকদ', 'জিলহজ'], hj: 'হিজরি',
      showIslamic: 'ইসলামিক (হিজরি) তারিখ দেখান', hjAdj: 'হিজরি তারিখ সমন্বয়', hjOpt: ['২ দিন পিছনে', '১ দিন পিছনে (বাংলাদেশ)', 'সৌদি (উম্মুল কুরা)', '১ দিন এগিয়ে'],
      hjInfo: 'হিজরি তারিখ উম্মুল কুরা পদ্ধতিতে হিসাব করা। বাংলাদেশে চাঁদ দেখার উপর নির্ভর করে ১ দিনের হেরফের হতে পারে — মিল না থাকলে এখান থেকে ঠিক করুন।',
      bs: 'বঙ্গাব্দ', legend: 'রঙের অর্থ', lRed: 'লাল: সাপ্তাহিক ছুটি (শুক্র ও শনি)', lGreen: 'সবুজ: সরকারি ছুটি (রবি–বৃহস্পতি)', lNormal: 'সাধারণ: কর্মদিবস',
      lToday: 'বৃত্ত: আজ', lBar: 'সবুজ দাগ: শুক্র/শনিতে পড়া সরকারি ছুটি', lOpt: 'ফাঁপা বৃত্ত: ঐচ্ছিক ছুটি', lObs: 'ড্যাশ: দিবস (ছুটি নয়)', lEv: 'বিন্দু: আপনার ইভেন্ট',
      monthHol: 'এই মাসের ছুটি', noHolMonth: 'এই মাসে কোনো সরকারি ছুটি নেই', upcoming: 'আসন্ন সরকারি ছুটি', noUpcoming: 'আসন্ন ছুটির যাচাইকৃত তথ্য নেই',
      noData: (y) => `${N(y)} সালের যাচাইকৃত ছুটির তথ্য নেই। শুধু শুক্র ও শনি দেখানো হচ্ছে। সেটিংস থেকে সরকারি তালিকা (JSON) ইমপোর্ট করুন।`,
      weekly: 'সাপ্তাহিক ছুটি', working: 'কর্মদিবস', cWeekly: 'সাপ্তাহিক ছুটি', cPublic: 'সরকারি ছুটি', cTotal: 'মোট ছুটির দিন', cOpt: 'ঐচ্ছিক',
      selected: 'নির্বাচিত তারিখ', details: 'বিস্তারিত', events: 'ইভেন্ট', noEvents: 'কোনো ইভেন্ট নেই', addEvent: 'ইভেন্ট যোগ করুন', editEvent: 'ইভেন্ট সম্পাদনা',
      title: 'শিরোনাম', desc: 'বিবরণ', date: 'তারিখ', time: 'সময়', allDay: 'সারাদিন', titleReq: 'শিরোনাম লিখুন', delConfirm: 'এই ইভেন্টটি মুছে ফেলবেন?',
      save: 'সংরক্ষণ', cancel: 'বাতিল', del: 'মুছুন', edit: 'সম্পাদনা', close: 'বন্ধ', go: 'যান', jump: 'তারিখে যান', year: 'বছর', exact: 'নির্দিষ্ট তারিখ',
      holList: 'ছুটির তালিকা', search: 'ছুটি খুঁজুন', fAll: 'সব', fPub: 'সরকারি', fOpt: 'ঐচ্ছিক', fObs: 'দিবস', noRes: 'কিছু পাওয়া যায়নি', source: 'উৎস',
      moon: 'চাঁদ দেখার উপর নির্ভরশীল — তারিখ পরিবর্তন হতে পারে', dataStatus: 'তথ্যের অবস্থা', bundled: 'অ্যাপের সাথে', importedL: 'ইমপোর্ট করা', reviewed: 'সর্বশেষ যাচাই',
      settings: 'সেটিংস', language: 'ভাষা', theme: 'থিম', tSys: 'সিস্টেম অনুযায়ী', tLight: 'লাইট', tDark: 'ডার্ক', weekStart: 'সপ্তাহ শুরু', showBangla: 'বাংলা তারিখ দেখান',
      tz: 'সময় অঞ্চল', tzDhaka: 'বাংলাদেশ (Asia/Dhaka)', tzDevice: 'ডিভাইসের সময় অঞ্চল', holData: 'ছুটির তথ্যভাণ্ডার', importBtn: 'ছুটির JSON ইমপোর্ট',
      importInfo: 'নতুন বছরের সরকারি তালিকা অ্যাপ আপডেট ছাড়াই যোগ করা যায় (একই বছরের তথ্য প্রতিস্থাপিত হবে)।', removeImp: 'ইমপোর্ট মুছুন',
      importOk: (y, n) => `${N(y)} সালের ${N(n)}টি রেকর্ড ইমপোর্ট হয়েছে`, importFail: (m) => `ইমপোর্ট ব্যর্থ: ${m}`,
      backup: 'ইভেন্ট ব্যাকআপ', exportEv: 'ইভেন্ট এক্সপোর্ট', importEv: 'ইভেন্ট রিস্টোর', evRestored: (n) => `${N(n)}টি ইভেন্ট ফিরিয়ে আনা হয়েছে`,
      about: 'অ্যাপ সম্পর্কে', aboutText: 'বাংলাদেশের গ্রেগরীয়, বঙ্গাব্দ ও হিজরি ক্যালেন্ডার। ছুটির তথ্য জনপ্রশাসন মন্ত্রণালয়ের প্রজ্ঞাপন থেকে নেওয়া; চাঁদনির্ভর ছুটি সরকারি ঘোষণায় বদলাতে পারে। সম্পূর্ণ অফলাইন — কোনো ইন্টারনেট, বিজ্ঞাপন বা ট্র্যাকিং নেই। ইভেন্ট শুধু এই ফোনেই থাকে।',
      prevM: 'আগের মাস', nextM: 'পরের মাস', prevY: 'আগের বছর', nextY: 'পরের বছর', tomorrow: 'আগামীকাল', inDays: (n) => `${N(n)} দিন পর`,
      cat: { GENERAL: 'সাধারণ ছুটি', EXECUTIVE: 'নির্বাহী আদেশে ছুটি', SPECIAL: 'বিশেষ সরকারি ছুটি', REGIONAL: 'আঞ্চলিক ছুটি (নির্দিষ্ট জেলা)', OPTIONAL: 'ঐচ্ছিক ছুটি', OBSERVANCE: 'দিবস (ছুটি নয়)', WORKING_DAY: 'অফিস খোলা (কর্মদিবস)' },
      grp: { MUSLIM: 'মুসলিম', HINDU: 'হিন্দু', CHRISTIAN: 'খ্রিস্টান', BUDDHIST: 'বৌদ্ধ', ETHNIC: 'ক্ষুদ্র নৃগোষ্ঠী' },
      ver: { VERIFIED: 'যাচাইকৃত', PROVISIONAL: 'প্রাথমিক ঘোষণা — চূড়ান্ত প্রজ্ঞাপনের অপেক্ষায়', UNVERIFIED: 'যাচাই হয়নি' }, moonShort: 'চাঁদনির্ভর',
      am: 'পূর্বাহ্ণ', pm: 'অপরাহ্ণ',
    },
    en: {
      tabs: ['Month', 'Year', 'Holidays', 'Settings'], today: 'Today', months: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
      bmonths: ['Boishakh', 'Joishtho', 'Asharh', 'Srabon', 'Bhadro', 'Ashwin', 'Kartik', 'Ogrohayon', 'Poush', 'Magh', 'Falgun', 'Choitro'],
      wd: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'], wds: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
      hmonths: ['Muharram', 'Safar', "Rabi' I", "Rabi' II", 'Jumada I', 'Jumada II', 'Rajab', "Sha'ban", 'Ramadan', 'Shawwal', "Dhul Qa'dah", 'Dhul Hijjah'], hj: 'AH',
      showIslamic: 'Show Islamic (Hijri) dates', hjAdj: 'Hijri date adjustment', hjOpt: ['2 days back', '1 day back (Bangladesh)', 'Saudi (Umm al-Qura)', '1 day ahead'],
      hjInfo: 'Hijri dates are calculated with the Umm al-Qura method. Bangladesh follows local moon sighting, so it can differ by a day — adjust here if it does not match.',
      bs: 'BS', legend: 'Colour guide', lRed: 'Red: weekly holiday (Fri & Sat)', lGreen: 'Green: government holiday (Sun–Thu)', lNormal: 'Normal: working day',
      lToday: 'Ring: today', lBar: 'Green bar: govt holiday on Fri/Sat', lOpt: 'Hollow ring: optional holiday', lObs: 'Dash: observance (no holiday)', lEv: 'Dot: your event',
      monthHol: 'Holidays this month', noHolMonth: 'No government holidays this month', upcoming: 'Upcoming government holidays', noUpcoming: 'No verified upcoming holidays',
      noData: (y) => `No verified holiday data for ${y}. Only Fridays and Saturdays are shown. Import the official list (JSON) in Settings.`,
      weekly: 'Weekly holiday', working: 'Working day', cWeekly: 'Weekly holidays', cPublic: 'Govt holidays', cTotal: 'Total days off', cOpt: 'Optional',
      selected: 'Selected date', details: 'Details', events: 'Events', noEvents: 'No events', addEvent: 'Add event', editEvent: 'Edit event',
      title: 'Title', desc: 'Description', date: 'Date', time: 'Time', allDay: 'All day', titleReq: 'Title is required', delConfirm: 'Delete this event?',
      save: 'Save', cancel: 'Cancel', del: 'Delete', edit: 'Edit', close: 'Close', go: 'Go', jump: 'Go to date', year: 'Year', exact: 'Exact date',
      holList: 'Holiday list', search: 'Search holidays', fAll: 'All', fPub: 'Public', fOpt: 'Optional', fObs: 'Observances', noRes: 'No results', source: 'Source',
      moon: 'Depends on moon sighting — date may change', dataStatus: 'Data status', bundled: 'Bundled', importedL: 'Imported', reviewed: 'Last reviewed',
      settings: 'Settings', language: 'Language', theme: 'Theme', tSys: 'Follow system', tLight: 'Light', tDark: 'Dark', weekStart: 'Week starts on', showBangla: 'Show Bangla dates',
      tz: 'Time zone', tzDhaka: 'Bangladesh (Asia/Dhaka)', tzDevice: 'Device time zone', holData: 'Holiday database', importBtn: 'Import holiday JSON',
      importInfo: "Add a new year's official list without updating the app (replaces that year's data).", removeImp: 'Remove import',
      importOk: (y, n) => `Imported ${n} records for ${y}`, importFail: (m) => `Import failed: ${m}`,
      backup: 'Event backup', exportEv: 'Export events', importEv: 'Restore events', evRestored: (n) => `Restored ${n} events`,
      about: 'About', aboutText: 'Gregorian, Bengali (Bangabda) and Hijri calendar for Bangladesh. Holiday data from Ministry of Public Administration notifications; moon-dependent holidays may change. Fully offline — no internet, ads or tracking. Events stay on this phone.',
      prevM: 'Previous month', nextM: 'Next month', prevY: 'Previous year', nextY: 'Next year', tomorrow: 'tomorrow', inDays: (n) => `in ${n} days`,
      cat: { GENERAL: 'General holiday', EXECUTIVE: 'Executive-order holiday', SPECIAL: 'Special public holiday', REGIONAL: 'Regional holiday (specific districts)', OPTIONAL: 'Optional holiday', OBSERVANCE: 'Observance (no holiday)', WORKING_DAY: 'Offices open (working day)' },
      grp: { MUSLIM: 'Muslim', HINDU: 'Hindu', CHRISTIAN: 'Christian', BUDDHIST: 'Buddhist', ETHNIC: 'Ethnic minority' },
      ver: { VERIFIED: 'Verified', PROVISIONAL: 'Provisional — awaiting final notification', UNVERIFIED: 'Unverified' }, moonShort: 'moon-dependent',
      am: 'AM', pm: 'PM',
    },
  };
  let T = S[settings.lang];
  const bn = () => settings.lang === 'bn';
  function N(n) { const s = String(n); return bn() ? s.replace(/[0-9]/g, (c) => BN_DIG[c]) : s; }
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const toBn = (n) => String(n).replace(/[0-9]/g, (c) => BN_DIG[c]);
  function withLang(l, fn) { const ol = settings.lang, ot = T; settings.lang = l; T = S[l]; try { return fn(); } finally { settings.lang = ol; T = ot; } }
  const mName = (m) => T.months[m - 1];
  const monthYear = (y, m) => `${mName(m)} ${N(y)}`;
  const fullDate = (s) => { const p = parse(s); return `${T.wd[dow(s)]}, ${N(p.d)} ${mName(p.m)} ${N(p.y)}`; };
  const numericDate = (s) => { const p = parse(s); return `${pad(p.d)}/${pad(p.m)}/${p.y}`; };
  const shortDate = (s) => { const p = parse(s); return `${N(p.d)} ${bn() ? mName(p.m) : mName(p.m).slice(0, 3)}`; };
  const banglaDate = (s) => { const b = toBangla(s); return `${N(b.d)} ${T.bmonths[b.m]} ${N(b.y)} ${T.bs}`; };
  const islamicDate = (s) => { const h = toHijri(s); return `${N(h.d)} ${T.hmonths[h.m - 1]} ${N(h.y)} ${T.hj}`; };
  function islamicSpan(y, m) {
    const a = toHijri(iso(y, m, 1)), b = toHijri(iso(y, m, daysInMonth(y, m))), nm = (x) => T.hmonths[x.m - 1];
    if (a.y === b.y) return a.m === b.m ? `${nm(a)} ${N(a.y)} ${T.hj}` : `${nm(a)}–${nm(b)} ${N(a.y)} ${T.hj}`;
    return `${nm(a)} ${N(a.y)} – ${nm(b)} ${N(b.y)} ${T.hj}`;
  }
  function banglaSpan(y, m) {
    const a = toBangla(iso(y, m, 1)), b = toBangla(iso(y, m, daysInMonth(y, m)));
    return a.y === b.y ? `${T.bmonths[a.m]}–${T.bmonths[b.m]} ${N(a.y)} ${T.bs}` : `${T.bmonths[a.m]} ${N(a.y)} – ${T.bmonths[b.m]} ${N(b.y)} ${T.bs}`;
  }
  function fmtTime(t) { if (!t) return ''; const [h, mi] = t.split(':').map(Number); const h12 = h % 12 === 0 ? 12 : h % 12; return `${N(h12)}:${N(pad(mi))} ${h < 12 ? T.am : T.pm}`; }

  // ---------- Holiday database ----------
  const CATS = ['GENERAL', 'EXECUTIVE', 'SPECIAL', 'REGIONAL', 'OPTIONAL', 'OBSERVANCE', 'WORKING_DAY'];
  const PUBLIC = new Set(['GENERAL', 'EXECUTIVE', 'SPECIAL']);
  const GROUPS = ['MUSLIM', 'HINDU', 'CHRISTIAN', 'BUDDHIST', 'ETHNIC'];
  const VERS = ['VERIFIED', 'PROVISIONAL', 'UNVERIFIED'];
  function validateYear(o) {
    if (!o || typeof o !== 'object') throw new Error('not a JSON object');
    if (o.schema !== 1) throw new Error('schema must be 1');
    if (o.country !== 'BD') throw new Error('country must be "BD"');
    const y = o.year; if (!(Number.isInteger(y) && y >= 1971 && y <= 2200)) throw new Error('year must be 1971–2200');
    if (!Array.isArray(o.holidays)) throw new Error('holidays array missing');
    const ids = new Set();
    const list = o.holidays.map((h, i) => {
      if (!/^\d{4}-\d{2}-\d{2}$/.test(h.date || '')) throw new Error(`record ${i}: invalid date`);
      const p = parse(h.date); if (p.y !== y || p.m < 1 || p.m > 12 || p.d < 1 || p.d > daysInMonth(p.y, p.m)) throw new Error(`record ${i}: date ${h.date} invalid or outside ${y}`);
      const nb = (h.nameBn || '').trim(), ne = (h.nameEn || '').trim(); if (!nb && !ne) throw new Error(`record ${i}: name required`);
      if (!CATS.includes(h.category)) throw new Error(`record ${i}: category '${h.category}'`);
      if (h.optionalGroup != null && !GROUPS.includes(h.optionalGroup)) throw new Error(`record ${i}: optionalGroup`);
      const v = h.verification == null ? 'UNVERIFIED' : h.verification; if (!VERS.includes(v)) throw new Error(`record ${i}: verification`);
      const id = h.id || `${h.date}-${i}`; if (ids.has(id)) throw new Error(`record ${i}: duplicate id`); ids.add(id);
      return { id, date: h.date, nameBn: nb || ne, nameEn: ne || nb, category: h.category, optionalGroup: h.optionalGroup || null, moonDependent: !!h.moonDependent, verification: v, source: h.source || null, sourceUrl: typeof h.sourceUrl === 'string' && /^https?:\/\//i.test(h.sourceUrl) ? h.sourceUrl : null, notes: h.notes || null };
    }).sort((a, b) => a.date < b.date ? -1 : a.date > b.date ? 1 : 0);
    return { year: y, title: o.title || '', primarySource: o.primarySource && o.primarySource.name, lastReviewed: o.lastReviewed || null, holidays: list };
  }
  let DB = {}, byDate = {};
  function buildDB() {
    DB = {}; byDate = {};
    (window.BUNDLED_HOLIDAYS || []).forEach((o) => { try { const y = validateYear(o); y.origin = 'bundled'; DB[y.year] = y; } catch (e) { console.error(e); } });
    Object.values(imported).forEach((o) => { try { const y = validateYear(o); y.origin = 'imported'; DB[y.year] = y; } catch (e) {} });
    Object.values(DB).forEach((y) => y.holidays.forEach((h) => { (byDate[h.date] = byDate[h.date] || []).push(h); }));
  }
  const on = (s) => byDate[s] || [];
  const hasYear = (y) => !!DB[y];
  function classify(s) {
    const recs = on(s), weekly = isWeekly(s);
    const pub = recs.filter((h) => PUBLIC.has(h.category));
    return {
      weekly, pub, recs, color: weekly ? 'red' : pub.length ? 'green' : 'normal',
      opt: recs.some((h) => h.category === 'OPTIONAL' || h.category === 'REGIONAL'),
      obs: recs.some((h) => h.category === 'OBSERVANCE' || h.category === 'WORKING_DAY'),
    };
  }
  function upcomingPublic(from, n) {
    const out = []; Object.keys(DB).sort().forEach((y) => DB[y].holidays.forEach((h) => { if (h.date >= from && PUBLIC.has(h.category)) out.push(h); }));
    return out.slice(0, n);
  }
  const hName = (h) => bn() ? h.nameBn : h.nameEn;
  const kindClass = (h) => PUBLIC.has(h.category) ? 'k-pub' : (h.category === 'OPTIONAL' || h.category === 'REGIONAL') ? 'k-opt' : h.category === 'OBSERVANCE' ? 'k-obs' : 'k-work';
  function catLine(h) {
    const p = [T.cat[h.category]]; if (h.optionalGroup) p.push(T.grp[h.optionalGroup]); if (h.moonDependent) p.push(T.moonShort);
    if (h.verification !== 'VERIFIED') p.push(T.ver[h.verification]); return p.join(' · ');
  }

  // ---------- State ----------
  let today = todayStr();
  const tp = parse(today);
  const st = { tab: 0, y: tp.y, m: tp.m, sel: today, year: tp.y, q: '', filter: 1, monthQ: '', monthFilter: 0, annual: false, holidaysOpen: false, holidayScrollTop: 0 };
  const $ = (id) => document.getElementById(id);

  function applyTheme() {
    const dark = settings.theme === 'dark' || (settings.theme === 'system' && window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches);
    document.documentElement.dataset.theme = dark ? 'dark' : 'light';
    document.documentElement.lang = settings.lang;
    const meta = document.querySelector('meta[name="theme-color"]'); if (meta) meta.content = dark ? '#121316' : '#FAFAF7';
    document.title = 'Calendar';
    if (window.AndroidBridge && typeof AndroidBridge.setTheme === 'function') {
      try { AndroidBridge.setTheme(dark); } catch (e) { /* Browser preview has no native bridge. */ }
    }
  }
  function saveSettings() { LS.set('settings', settings); T = S[settings.lang]; applyTheme(); today = todayStr(); render(); armClock(); }
  function clearToast() { clearTimeout(toast.h); $('toast').hidden = true; }
  let sheetOpener = null, modalOpener = null;
  function syncDialogAccessibility() {
    const modalOpen = !$('modal').hidden, sheetOpen = !$('sheet').hidden;
    $('app').inert = modalOpen || sheetOpen;
    if (modalOpen || sheetOpen) $('app').setAttribute('aria-hidden', 'true');
    else $('app').removeAttribute('aria-hidden');
    $('sheet').inert = modalOpen;
    if (modalOpen) $('sheet').setAttribute('aria-hidden', 'true');
    else $('sheet').removeAttribute('aria-hidden');
  }
  function restoreFocus(el) {
    const target = el && el.isConnected ? el : $('tab-' + st.tab);
    if (target && !target.closest('[hidden], [inert]')) target.focus({ preventScroll: true });
  }
  function toast(msg) { const t = $('toast'); t.textContent = msg; t.hidden = false; clearTimeout(toast.h); toast.h = setTimeout(() => (t.hidden = true), 3500); }

  // ---------- Rendering ----------
  // Local vector icons: consistent in Android WebView, no fonts or network required.
  const icon = (paths) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" focusable="false" aria-hidden="true">${paths}</svg>`;
  const ICONS = [
    icon('<rect x="3" y="5" width="18" height="16" rx="4"/><path d="M7 3v4m10-4v4M3 10h18M8 14h2m4 0h2m-8 3h2"/>'),
    icon('<rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/>'),
    icon('<path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2-5.6-2.9-5.6 2.9 1.1-6.2L3 9.6l6.2-.9L12 3Z"/>'),
    icon('<path d="m9.3 3-.6 2.2-1.9 1.1-2.2-.6-2 3.4 1.6 1.6v2.2l-1.6 1.6 2 3.4 2.2-.6 1.9 1.1.6 2.2h4l.6-2.2 1.9-1.1 2.2.6 2-3.4-1.6-1.6v-2.2L22 9.1l-2-3.4-2.2.6-1.9-1.1-.6-2.2h-6Z"/><circle cx="12" cy="12" r="3"/>')
  ];
  const SEARCH_ICON = icon('<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>');
  const NAV_TABS = [0, 3]; // Unified month/holidays, Settings; Search is a separate action.
  function renderTabs() {
    $('tabs').style.setProperty('--active-tab', NAV_TABS.indexOf(st.tab));
    const searchLabel = bn() ? 'খুঁজুন' : 'Search';
    $('dock').setAttribute('aria-label', bn() ? 'ক্যালেন্ডার নেভিগেশন' : 'Calendar navigation');
    $('date-search').setAttribute('aria-label', bn() ? 'তারিখ খুঁজুন' : 'Search date');
    const searchHtml = `<span class="ico" aria-hidden="true">${SEARCH_ICON}</span><span class="tab-label">${searchLabel}</span>`;
    if ($('date-search').innerHTML !== searchHtml) $('date-search').innerHTML = searchHtml;
    $('tabs').setAttribute('aria-label', bn() ? 'ক্যালেন্ডার নেভিগেশন' : 'Calendar navigation');
    $('view').setAttribute('aria-labelledby', 'tab-' + st.tab);
    const tabsHtml = NAV_TABS.map((i) => { const l = i === 0 ? (bn() ? 'মাস ও ছুটি' : 'Calendar') : T.tabs[i]; return `<button id="tab-${i}" role="tab" aria-controls="view" tabindex="${st.tab === i ? 0 : -1}" aria-selected="${st.tab === i}" data-tab="${i}"><span class="ico" aria-hidden="true">${ICONS[i]}</span><span class="tab-label">${esc(l)}</span></button>`; }).join('');
    // Preserve the indicator pseudo-element and focused controls between renders.
    // Replacing all tab nodes on every date/tap used to restart CSS transitions.
    if ($('tabs').dataset.lang !== settings.lang || !$('tab-0')) {
      $('tabs').innerHTML = tabsHtml; $('tabs').dataset.lang = settings.lang;
    }
    NAV_TABS.forEach((i) => {
      const tab = $('tab-' + i), active = st.tab === i;
      tab.setAttribute('aria-selected', String(active)); tab.tabIndex = active ? 0 : -1;
    });
    const phone = new Date();
    const dateKey = iso(phone.getFullYear(), phone.getMonth() + 1, phone.getDate());
    const monthIcon = $('tab-0').querySelector('.ico');
    if (monthIcon.dataset.iconDate !== dateKey) {
      const day = N(parse(dateKey).d);
      monthIcon.innerHTML = icon(`<rect x="3" y="5" width="18" height="16" rx="4"/><path d="M7 3v4m10-4v4M3 10h18"/><text x="12" y="18" text-anchor="middle" stroke="none" fill="currentColor" font-size="8" font-weight="700">${day}</text>`);
      if (monthIcon.dataset.iconDate && !matchMedia('(prefers-reduced-motion: reduce)').matches && monthIcon.animate) {
        monthIcon.animate([{opacity:.25, transform:'translateY(2px) scale(.94)'}, {opacity:1, transform:'none'}], {duration:220, easing:'cubic-bezier(.2,.8,.2,1)'});
      }
      monthIcon.dataset.iconDate = dateKey;
    }
  }
  function weekOrder() { return [0, 1, 2, 3, 4, 5, 6].map((i) => (settings.weekStart + i) % 7); }
  function weekdaysHtml(short) {
    return `<div class="weekdays" aria-hidden="true">${weekOrder().map((d) => `<div class="${d === 5 || d === 6 ? 'wk' : ''}">${short ? (bn() ? T.wds[d] : T.wds[d].slice(0, 1)) : `<span class="weekday-full">${T.wds[d]}</span><span class="weekday-short">${bn() ? T.wds[d] : T.wds[d].slice(0, 3)}</span>`}</div>`).join('')}</div>`;
  }
  function gridCells(y, m) {
    const first = dow(iso(y, m, 1)); const blanks = (first - settings.weekStart + 7) % 7; const n = daysInMonth(y, m);
    const cells = []; for (let i = 0; i < 42; i++) { const d = i - blanks + 1; cells.push(d >= 1 && d <= n ? iso(y, m, d) : null); } return cells;
  }
  function describe(s, c, evn) {
    const p = [fullDate(s), banglaDate(s)]; if (settings.showIslamic) p.push(islamicDate(s)); if (s === today) p.push(T.today); if (c.weekly) p.push(T.weekly);
    c.recs.forEach((h) => p.push(`${hName(h)}, ${T.cat[h.category]}`)); if (evn) p.push(`${N(evn)} ${T.events}`); return p.join('. ');
  }
  function evCount(s) { return events.filter((e) => e.date === s).length; }
  function monthGridHtml(y, m) { // always English digits for the Gregorian date; Bangla + Hijri sub-dates in Bengali digits
    const sb = settings.showBangla, si = settings.showIslamic, cn = sb || si ? '' : ' nob';
    return `<div class="grid" id="mgrid">${gridCells(y, m).map((s) => {
      if (!s) return `<div class="cell${cn}"></div>`;
      const c = classify(s), p = parse(s), ev = evCount(s);
      const cls = c.color === 'red' ? 'c-red' : c.color === 'green' ? 'c-green' : '';
      const marks = (c.weekly && c.pub.length ? '<i class="m-bar"></i>' : '') + (c.opt ? '<i class="m-opt"></i>' : '') + (c.obs ? '<i class="m-obs"></i>' : '') + (ev ? '<i class="m-ev"></i>' : '');
      let sub = '';
      if (sb || si) {
        const b = toBangla(s), h = si ? toHijri(s) : null;
        sub = `<span class="sub"><span class="b${b.d === 1 ? ' first' : ''}">${sb ? (b.d === 1 ? S.bn.bmonths[b.m] : toBn(b.d)) : ''}</span><span class="h${h && h.d === 1 ? ' first' : ''}">${h ? toBn(h.d) : ''}</span></span>`;
      }
      return `<button class="cell${cn}${s === today ? ' today' : ''}${s === st.sel ? ' sel' : ''}" data-date="${s}" aria-current="${s === today ? 'date' : 'false'}" aria-pressed="${s === st.sel}" aria-label="${esc(describe(s, c, ev))}"><span class="n ${cls}">${N(p.d)}</span>${sub}<span class="marks">${marks}</span></button>`;
    }).join('')}</div>`;
  }
  function holidayRow(h, opts) {
    const w = isWeekly(h.date), p = parse(h.date);
    const badge = `<div class="dbadge"><b class="${w ? 'c-red' : PUBLIC.has(h.category) ? 'c-green' : ''}">${N(p.d)}</b><small class="${w ? 'c-red' : ''}">${T.wds[dow(h.date)]}</small></div>`;
    const extra = opts && opts.away != null ? `<small class="muted">${esc(opts.away)}</small>` : '';
    return `<button class="row${opts && opts.past ? ' past' : ''}" data-open="${h.date}">${badge}<div style="flex:1"><div class="nm">${esc(hName(h))}</div><div class="cat ${kindClass(h)}">${esc(catLine(h))}</div></div>${extra}</button>`;
  }
  function counts(days, recs) {
    const weekly = days.filter((s) => isWeekly(s)).length;
    const pubW = days.filter((s) => !isWeekly(s) && classify(s).pub.length).length;
    const opt = recs.filter((h) => h.category === 'OPTIONAL').length;
    return `<div class="counts"><div><b class="c-red">${N(weekly)}</b><small>${T.cWeekly}</small></div><div><b class="c-green">${N(pubW)}</b><small>${T.cPublic}</small></div><div><b>${N(weekly + pubW)}</b><small>${T.cTotal}</small></div><div><b class="k-opt">${N(opt)}</b><small>${T.cOpt}</small></div></div>`;
  }
  function legendHtml() {
    return `<div class="card"><h3>${T.legend}</h3><div class="legend">
      <span><b class="c-red">${N(5)}</b>${T.lRed}</span><span><b class="c-green">${N(5)}</b>${T.lGreen}</span><span><b>${N(5)}</b>${T.lNormal}</span>
      <span><i class="lg-ring"></i>${T.lToday}</span><span><i class="m-bar"></i>${T.lBar}</span><span><i class="m-opt" style="width:8px;height:8px"></i>${T.lOpt}</span>
      <span><i class="m-obs" style="width:10px"></i>${T.lObs}</span><span><i class="m-ev" style="width:7px;height:7px"></i>${T.lEv}</span></div></div>`;
  }
  function monthPanelHtml() {
    const { y, m } = st; const isCur = parse(today).y === y && parse(today).m === m;
    const title = withLang('en', () => monthYear(y, m)); // month header always shows the English month name (user preference)
    const spans = (settings.showBangla || settings.showIslamic) ? `<div class="spans"><span class="sp-bn">${settings.showBangla ? withLang('bn', () => banglaSpan(y, m)) : ''}</span><span class="sp-hj">${settings.showIslamic ? withLang('bn', () => islamicSpan(y, m)) : ''}</span></div>` : '';
    const grid = withLang('en', () => weekdaysHtml(false) + monthGridHtml(y, m));
    const left = `<div class="hdr"><button class="iconbtn" data-act="prevM" aria-label="${T.prevM}">‹</button>
      <button class="title month-title-glass" data-act="jump" aria-label="${T.jump}"><b>${title}</b><small class="header-date" id="header-date">${numericDate(today)}</small></button>
      <button class="iconbtn" data-act="nextM" aria-label="${T.nextM}">›</button></div>
      ${isCur ? '' : `<div class="month-actions"><button class="textbtn" data-act="today">${T.today}</button></div>`}
      ${spans}${grid}`;
    return `<div class="calendar-panel">${left}</div>`;
  }
  function holidayBarCount() {
    return DB[st.y] ? (bn() ? `${N(monthlyHolidayRecords().length)}টি` : `${monthlyHolidayRecords().length}`) : (bn() ? 'তথ্য নেই' : 'No data');
  }
  function syncHolidayDisclosure() {
    const button = $('holiday-toggle'), panel = $('month-holidays-panel');
    if (!button || !panel) return;
    // Hidden descendants must never retain focus or be exposed to keyboard users.
    if (!st.holidaysOpen && panel.contains(document.activeElement)) button.focus({preventScroll:true});
    panel.hidden = !st.holidaysOpen;
    button.setAttribute('aria-expanded', String(st.holidaysOpen));
    $('holiday-toggle-count').textContent = holidayBarCount();
  }
  function toggleHolidays() {
    if (!st.holidaysOpen) st.holidayScrollTop = $('view').scrollTop;
    st.holidaysOpen = !st.holidaysOpen;
    syncHolidayDisclosure();
    // Reveal actual holiday names immediately on a phone, rather than leaving
    // the newly opened list below the dock. No calendar/input DOM replacement.
    if (st.holidaysOpen) {
      const reduce = !window.matchMedia || matchMedia('(prefers-reduced-motion: reduce)').matches;
      $('holiday-toggle').scrollIntoView({block:'start', behavior:reduce ? 'auto' : 'smooth'});
    } else $('view').scrollTop = st.holidayScrollTop;
  }
  function renderMonth() {
    $('view').innerHTML = `<div class="wrap month-only unified-month">
      <section class="holiday-calendar" aria-label="${bn() ? 'মাসের ক্যালেন্ডার' : 'Month calendar'}">${monthPanelHtml()}</section>
      <button type="button" id="holiday-toggle" class="holiday-toggle" data-act="toggleHolidays" aria-controls="month-holidays-panel" aria-expanded="${st.holidaysOpen}">
        <span class="holiday-toggle-label">${T.monthHol}</span><span id="holiday-toggle-count" class="holiday-toggle-count">${holidayBarCount()}</span><span class="holiday-toggle-chevron" aria-hidden="true">${icon('<path d="m6 9 6 6 6-6"/>')}</span>
      </button>
      <section id="month-holidays-panel" class="holiday-list-pane" aria-labelledby="holiday-toggle" ${st.holidaysOpen ? '' : 'hidden'}>
        <input id="month-q" class="search" type="search" placeholder="${T.search}" aria-label="${T.search}" value="${esc(st.monthQ)}" aria-controls="month-holiday-results">
        <div class="chips">${[T.fAll, T.fPub, T.fOpt].map((label, i) => `<button class="chip" data-month-filter="${i}" aria-pressed="${st.monthFilter === i}">${label}</button>`).join('')}</div>
        <div id="month-holiday-results">${monthlyHolidayResultsHtml()}</div>
      </section>
    </div>`;
    const input = $('month-q');
    input.addEventListener('input', () => { st.monthQ = input.value; refreshMonthlyHolidayResults(); });
  }
  function monthlyHolidayRecords() {
    const data = DB[st.y];
    return data ? data.holidays.filter((h) => parse(h.date).m === st.m &&
      (PUBLIC.has(h.category) || h.category === 'OPTIONAL' || h.category === 'REGIONAL')) : [];
  }
  function monthlyHolidayResultsHtml() {
    const q = st.monthQ.trim().toLowerCase();
    if (!DB[st.y]) return `<div class="banner">${esc(T.noData(st.y))}</div>`;
    const list = monthlyHolidayRecords().filter((h) => {
      const category = st.monthFilter === 1 ? PUBLIC.has(h.category) : st.monthFilter === 2 ?
        (h.category === 'OPTIONAL' || h.category === 'REGIONAL') : true;
      return category && (!q || h.nameBn.toLowerCase().includes(q) || h.nameEn.toLowerCase().includes(q) || h.date.includes(q));
    });
    return `<div class="card monthly-list"><div class="list-heading"><h3>${T.monthHol}</h3><span class="cnt" aria-label="${bn() ? 'ছুটির সংখ্যা' : 'Holiday count'}">${N(list.length)}</span></div>${list.length ? list.map((h) => holidayRow(h, {past:h.date < today})).join('') : `<p class="muted">${q || st.monthFilter ? T.noRes : T.noHolMonth}</p>`}</div>`;
  }
  function refreshMonthlyHolidayResults() {
    // Do not recreate the calendar/search on each keystroke: preserves keyboard,
    // caret, scroll position, and the day currently being inspected.
    const results = $('month-holiday-results');
    if (results) results.innerHTML = monthlyHolidayResultsHtml();
    document.querySelectorAll('[data-month-filter]').forEach((button) =>
      button.setAttribute('aria-pressed', String(+button.dataset.monthFilter === st.monthFilter)));
  }
  function renderAnnualHolidays() {
    const y = st.year, data = DB[y], q = st.q.trim().toLowerCase();
    const list = (data ? data.holidays : []).filter((h) => {
      const f = st.filter === 1 ? PUBLIC.has(h.category) : st.filter === 2 ? (h.category === 'OPTIONAL' || h.category === 'REGIONAL') : st.filter === 3 ? (h.category === 'OBSERVANCE' || h.category === 'WORKING_DAY') : true;
      return f && (!q || h.nameBn.toLowerCase().includes(q) || h.nameEn.toLowerCase().includes(q) || mName(parse(h.date).m).toLowerCase().includes(q));
    });
    let html = `<div class="wrap holiday-page"><div class="subpage-top"><button class="textbtn" data-act="closeAnnual">‹ ${T.settings}</button><h2>${bn() ? 'পুরো বছরের ছুটি' : 'Full-year holidays'}</h2></div><div class="hdr"><button class="iconbtn" data-act="prevY" aria-label="${T.prevY}">‹</button><div class="title"><b>${N(y)}</b><small>${T.holList}</small></div><button class="iconbtn" data-act="nextY" aria-label="${T.nextY}">›</button></div>
      <input id="q" class="search" type="search" placeholder="🔍 ${T.search}" value="${esc(st.q)}" aria-label="${T.search}">
      <div class="chips">${[T.fAll, T.fPub, T.fOpt, T.fObs].map((l, i) => `<button class="chip" aria-pressed="${st.filter === i}" data-filter="${i}">${l}</button>`).join('')}</div>`;
    if (!data) html += `<div class="banner">ℹ️ <span>${esc(T.noData(y))}</span></div>`;
    else html += `<div class="card"><h3>${T.dataStatus}</h3><div>${data.origin === 'bundled' ? T.bundled : T.importedL} · ${N(data.holidays.length)}</div>${data.primarySource ? `<div class="small muted">${T.source}: ${esc(data.primarySource)}</div>` : ''}${data.lastReviewed ? `<div class="small muted">${T.reviewed}: ${esc(data.lastReviewed)}</div>` : ''}<div class="small k-opt">${T.moon}</div></div>`;
    if (data && !list.length) html += `<p class="muted">${T.noRes}</p>`;
    let lastM = 0;
    list.forEach((h) => { const m = parse(h.date).m; if (m !== lastM) { html += `<div class="mhead">${mName(m)}</div>`; lastM = m; } html += holidayRow(h, { past: h.date < today }); });
    $('view').innerHTML = html + '</div>';
    const qi = $('q'); qi.addEventListener('input', () => { st.q = qi.value; const pos = qi.selectionStart; renderAnnualHolidays(); const n = $('q'); n.focus(); try { n.setSelectionRange(pos, pos); } catch (e) {} });
  }
  function choice(name, opts, cur) {
    return `<div class="chips" role="radiogroup">${opts.map(([v, l]) => `<button class="chip" role="radio" aria-pressed="${String(v) === String(cur)}" aria-checked="${String(v) === String(cur)}" data-set="${name}" data-val="${v}">${esc(l)}</button>`).join('')}</div>`;
  }
  function renderSettings() {
    const years = Object.values(DB).sort((a, b) => a.year - b.year);
    $('view').innerHTML = `<div class="wrap"><h2 style="margin:6px 4px">${T.settings}</h2>
      <button class="card settings-link" data-act="openAnnual" aria-label="${bn() ? 'পুরো বছরের ছুটি দেখুন' : 'View full-year holidays'}"><span class="settings-link-icon" aria-hidden="true">${ICONS[2]}</span><span><b>${bn() ? 'পুরো বছরের ছুটি' : 'Full-year holidays'}</b><small>${bn() ? 'বছরভিত্তিক ছুটির তালিকা দেখুন' : 'Browse the holiday list by year'}</small></span><span class="settings-link-arrow" aria-hidden="true">›</span></button>
      <div class="card">
        <div class="setrow"><span class="lbl">${T.language}</span>${choice('lang', [['bn', 'বাংলা'], ['en', 'English']], settings.lang)}</div>
        <div class="setrow"><span class="lbl">${T.theme}</span>${choice('theme', [['system', T.tSys], ['light', T.tLight], ['dark', T.tDark]], settings.theme)}</div>
        <div class="setrow"><span class="lbl">${T.weekStart}</span>${choice('weekStart', [[0, T.wd[0]], [6, T.wd[6]], [1, T.wd[1]]], settings.weekStart)}</div>
        <label class="switch"><span>${T.showBangla}</span><input type="checkbox" id="showBangla" ${settings.showBangla ? 'checked' : ''}></label>
        <label class="switch"><span>${T.showIslamic}</span><input type="checkbox" id="showIslamic" ${settings.showIslamic ? 'checked' : ''}></label>
        <div class="setrow"><span class="lbl">${T.hjAdj}</span>${choice('hijriShift', [[-2, T.hjOpt[0]], [-1, T.hjOpt[1]], [0, T.hjOpt[2]], [1, T.hjOpt[3]]], settings.hijriShift)}<div class="small muted">${T.hjInfo}</div></div>
        <div class="setrow"><span class="lbl">${T.tz}</span>${choice('deviceZone', [['false', T.tzDhaka], ['true', T.tzDevice]], settings.deviceZone)}</div>
      </div>
      <div class="card"><h3>${T.holData}</h3>
        ${years.map((y) => `<div class="row"><div style="flex:1"><b>${N(y.year)}</b> · ${N(y.holidays.length)}<div class="small muted">${y.origin === 'bundled' ? T.bundled : T.importedL}${y.lastReviewed ? ' · ' + T.reviewed + ': ' + esc(y.lastReviewed) : ''}</div></div>${y.origin === 'imported' ? `<button class="textbtn" data-rmimp="${y.year}">${T.removeImp}</button>` : ''}</div>`).join('')}
        <p class="small muted">${T.importInfo}</p>
        <label class="btn tonal" style="display:inline-block">${T.importBtn}<input type="file" id="impfile" accept=".json,application/json,text/plain" hidden></label>
      </div>
      <div class="card"><h3>${T.backup}</h3><div class="actions" style="justify-content:flex-start"><button class="btn tonal" data-act="exportEv">${T.exportEv}</button>
        <label class="btn tonal">${T.importEv}<input type="file" id="evfile" accept=".json,application/json" hidden></label></div></div>
      ${window.AndroidBridge && typeof AndroidBridge.iconSetup === 'function' ? `<button class="card settings-link" data-act="iconSetup"><span><b>${bn() ? 'আইকন আপডেট সেটআপ' : 'Midnight icon setup'}</b><small>${bn() ? 'রাত ১২টার অ্যালার্ম অনুমতি ও আপডেটের অবস্থা' : 'Midnight alarm permission and update status'}</small></span><span class="settings-link-arrow" aria-hidden="true">›</span></button>` : ''}
      <div class="card"><h3>${T.about}</h3><p style="margin:0">${T.aboutText}</p><p class="small muted">v1.10.0 · com.t.calendar</p></div></div>`;
    $('showBangla').addEventListener('change', (e) => { settings.showBangla = e.target.checked; saveSettings(); });
    $('showIslamic').addEventListener('change', (e) => { settings.showIslamic = e.target.checked; saveSettings(); });
    $('impfile').addEventListener('change', (e) => readFile(e.target.files[0], (txt) => {
      try { const o = JSON.parse(txt); const y = validateYear(o); imported[y.year] = o; LS.set('imported', imported); buildDB(); toast(T.importOk(y.year, y.holidays.length)); render(); }
      catch (err) { toast(T.importFail(err.message)); }
    }));
    $('evfile').addEventListener('change', (e) => readFile(e.target.files[0], (txt) => {
      try { const arr = JSON.parse(txt); if (!Array.isArray(arr)) throw new Error('not a list');
        const ids = new Set(events.map((x) => x.id)); let restored = 0;
        arr.map(normalizeEvent).forEach((x) => {
          if (x && !ids.has(x.id)) { events.push(x); ids.add(x.id); restored++; }
        });
        events.sort((a, b) => (a.date + (a.time || '')).localeCompare(b.date + (b.time || '')));
        LS.set('events', events); toast(T.evRestored(restored)); render(); } catch (err) { toast(T.importFail(err.message)); }
    }));
  }
  function readFile(f, cb) { if (!f) return; if (f.size > 2e6) { toast(T.importFail('file too large')); return; } const r = new FileReader(); r.onload = () => cb(String(r.result)); r.readAsText(f, 'utf-8'); }
  function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 7); }

  function render() {
    renderTabs();
    if (st.tab === 0) renderMonth();
    else if (st.annual) renderAnnualHolidays();
    else renderSettings();
    if (!$('sheet').hidden) openSheet(st.sheetDate, true);
  }

  // ---------- Bottom sheet: date details ----------
  function openSheet(s, refresh) {
    if (!refresh) { sheetOpener = document.activeElement; clearToast(); }
    st.sheetDate = s; const c = classify(s), evs = events.filter((e) => e.date === s);
    const recs = c.recs.map((h) => `<div class="rec"><div class="nm">${esc(hName(h))}</div><div class="${kindClass(h)} small">${esc(catLine(h))}</div>
      ${h.moonDependent ? `<div class="small muted">${T.moon}</div>` : ''}${h.verification !== 'VERIFIED' ? `<div class="small k-opt">${T.ver[h.verification]}</div>` : ''}
      ${h.notes ? `<div class="small muted">${esc(h.notes)}</div>` : ''}${h.source ? `<div class="small muted">${T.source}: ${esc(h.source)}</div>` : ''}
      ${h.sourceUrl ? `<a href="${esc(h.sourceUrl)}" target="_blank" rel="noopener">${esc(h.sourceUrl.replace(/^https?:\/\//, '').split('/')[0])}</a>` : ''}</div>`).join('');
    $('sheet').innerHTML = `<div class="grab"></div><div style="display:flex;align-items:start"><div style="flex:1"><h2 class="${c.color === 'red' ? 'c-red' : c.color === 'green' ? 'c-green' : ''}">${fullDate(s)}</h2>
      <div style="color:var(--bn)">${banglaDate(s)}</div>${settings.showIslamic ? `<div style="color:var(--hj)">${islamicDate(s)}</div>` : ''}${s === today ? `<div style="color:var(--ring);font-weight:600">${T.today}</div>` : ''}</div><button class="iconbtn" data-act="closeSheet" aria-label="${T.close}">${icon('<path d="m6 6 12 12M18 6 6 18"/>')}</button></div>
      <div style="margin-top:10px">${c.weekly ? `<div class="c-red">● ${T.weekly}</div>` : c.pub.length ? '' : `<div class="muted">● ${T.working}</div>`}</div>
      ${hasYear(parse(s).y) ? '' : `<div class="banner">ℹ️ <span>${esc(T.noData(parse(s).y))}</span></div>`}${recs}
      <div style="display:flex;align-items:center;margin-top:18px"><h3 style="flex:1;margin:0">${T.events}</h3><button class="btn" data-act="addSheet">＋ ${T.addEvent}</button></div>
      ${evs.length ? evs.map((e) => `<div class="evrow"><div class="t"><div style="font-weight:500">${esc(e.title)}</div><div class="small muted">${e.allDay ? T.allDay : fmtTime(e.time)}</div>${e.desc ? `<div class="small">${esc(e.desc)}</div>` : ''}</div>
        <button class="iconbtn" data-edit="${esc(e.id)}" aria-label="${T.edit}">✎</button><button class="iconbtn" data-del="${esc(e.id)}" aria-label="${T.del}">🗑</button></div>`).join('') : `<p class="muted">${T.noEvents}</p>`}`;
    $('sheet').hidden = false; $('sheet-backdrop').hidden = false;
    if (!refresh) {
      $('sheet').scrollTop = 0;
      $('sheet').querySelector('[data-act="closeSheet"]').focus({ preventScroll: true });
    }
    syncDialogAccessibility();
  }
  function closeSheet() {
    const wasOpen = !$('sheet').hidden;
    $('sheet').hidden = true; $('sheet-backdrop').hidden = true;
    syncDialogAccessibility();
    if (wasOpen) restoreFocus(sheetOpener);
  }

  // ---------- Modal dialogs ----------
  function openModal(html) {
    modalOpener = document.activeElement; clearToast();
    $('modal').removeAttribute('aria-labelledby');
    $('modal').setAttribute('aria-label', T.details);
    $('modal').innerHTML = html; $('modal').hidden = false; $('modal-backdrop').hidden = false;
    const f = $('modal').querySelector('input:not([type="hidden"]),button');
    if (f) f.focus({ preventScroll: true });
    syncDialogAccessibility();
  }
  function closeModal() {
    const wasOpen = !$('modal').hidden;
    $('modal').hidden = true; $('modal-backdrop').hidden = true;
    syncDialogAccessibility();
    if (wasOpen) restoreFocus(modalOpener);
  }
  function openEditor(date, ev) {
    openModal(`<h2>${ev ? T.editEvent : T.addEvent}</h2>
      <label class="field" id="f-title"><span>${T.title}</span><input id="e-title" value="${esc(ev ? ev.title : '')}" maxlength="200"></label>
      <label class="field"><span>${T.desc}</span><textarea id="e-desc" rows="2">${esc(ev ? ev.desc : '')}</textarea></label>
      <label class="field"><span>${T.date}</span><input id="e-date" type="date" min="1900-01-01" max="2299-12-31" value="${ev ? ev.date : date}"></label>
      <label class="switch"><span>${T.allDay}</span><input type="checkbox" id="e-allday" ${!ev || ev.allDay ? 'checked' : ''}></label>
      <label class="field" id="f-time" ${!ev || ev.allDay ? 'hidden' : ''}><span>${T.time}</span><input id="e-time" type="time" value="${ev && ev.time ? ev.time : '09:00'}"></label>
      <div class="actions"><button class="textbtn" data-act="closeModal">${T.cancel}</button><button class="btn" id="e-save">${T.save}</button></div>`);
    $('e-allday').addEventListener('change', (e) => { $('f-time').hidden = e.target.checked; });
    $('e-save').addEventListener('click', () => {
      const title = $('e-title').value.trim(); const d = $('e-date').value;
      if (!title) { $('f-title').classList.add('err'); $('f-title').querySelector('span').textContent = T.titleReq; return; }
      if (!validDate(d)) { $('e-date').focus(); return; }
      const allDay = $('e-allday').checked; const rec = { id: ev ? ev.id : uid(), title, desc: $('e-desc').value.trim(), date: d, allDay, time: allDay ? null : ($('e-time').value || '09:00') };
      events = events.filter((x) => x.id !== rec.id).concat([rec]).sort((a, b) => (a.date + (a.time || '')).localeCompare(b.date + (b.time || '')));
      LS.set('events', events); closeModal(); st.sel = d; const p = parse(d); st.y = p.y; st.year = p.y; st.m = p.m; render(); openSheet(d);
    });
  }
  function confirmDelete(id) {
    const e = events.find((x) => x.id === id); if (!e) return;
    openModal(`<h2>${T.delConfirm}</h2><p>${esc(e.title)}</p><div class="actions"><button class="textbtn" data-act="closeModal">${T.cancel}</button><button class="btn danger" id="d-ok">${T.del}</button></div>`);
    $('d-ok').addEventListener('click', () => { events = events.filter((x) => x.id !== id); LS.set('events', events); closeModal(); render(); });
  }
  function openJump() {
    let jm = st.m;
    openModal(`<h2>${T.jump}</h2>
      <div style="display:flex;align-items:center;gap:6px"><button class="iconbtn" id="j-minus">−</button><label class="field" style="flex:1;margin:0"><span>${T.year} (${N(MIN_Y)}–${N(MAX_Y)})</span><input id="j-year" type="number" inputmode="numeric" min="${MIN_Y}" max="${MAX_Y}" value="${st.y}"></label><button class="iconbtn" id="j-plus">+</button></div>
      <div class="monthpick" style="margin-top:12px">${T.months.map((n, i) => `<button class="chip" data-jm="${i + 1}" aria-pressed="${i + 1 === jm}">${bn() ? n : n.slice(0, 3)}</button>`).join('')}</div>
      <label class="field"><span>${T.exact}</span><input id="j-date" type="date" min="1900-01-01" max="2299-12-31"></label>
      <div class="actions"><button class="textbtn" data-act="closeModal">${T.cancel}</button><button class="btn" id="j-go">${T.go}</button></div>`);
    const yi = $('j-year');
    $('j-minus').onclick = () => { yi.value = Math.max(MIN_Y, (+yi.value || st.y) - 1); };
    $('j-plus').onclick = () => { yi.value = Math.min(MAX_Y, (+yi.value || st.y) + 1); };
    $('modal').querySelectorAll('[data-jm]').forEach((b) => b.addEventListener('click', () => { jm = +b.dataset.jm; $('modal').querySelectorAll('[data-jm]').forEach((x) => x.setAttribute('aria-pressed', String(+x.dataset.jm === jm))); }));
    $('j-go').onclick = () => {
      const ex = $('j-date').value;
      if (ex) { closeModal(); goTo(ex, true); return; }
      const y = parseInt(yi.value, 10); if (!(y >= MIN_Y && y <= MAX_Y)) { yi.focus(); return; }
      closeModal(); goTo(iso(y, jm, 1), false);
    };
  }
  // Accept both Bengali/Latin digits. Never let Date silently roll an invalid day forward.
  function parseSearchDate(value) {
    const text = String(value).trim().replace(/[০-৯]/g, (d) => String(BN_DIG.indexOf(d)));
    let match = text.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
    let result;
    if (match) result = iso(+match[1], +match[2], +match[3]);
    else {
      match = text.match(/^(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{4})$/);
      if (!match) return null;
      result = iso(+match[3], +match[2], +match[1]);
    }
    return validDate(result) ? result : null;
  }
  function openDateSearch() {
    const label = bn() ? 'তারিখ খুঁজুন' : 'Search date';
    const hint = bn() ? 'দিন/মাস/বছর লিখুন — যেমন ১৬/১০/২০২৬। ইংরেজি সংখ্যাও চলবে।' : 'Enter day/month/year, e.g. 16/10/2026. YYYY-MM-DD also works.';
    const error = bn() ? 'সঠিক তারিখ লিখুন (১৯০০–২২৯৯)। যেমন ১৬/১০/২০২৬।' : 'Enter a valid date between 1900 and 2299, e.g. 16/10/2026.';
    openModal(`<form id="date-search-form" novalidate><h2 id="date-search-title">${label}</h2>
      <label class="field"><span>${T.date}</span><input id="search-date-input" type="text" inputmode="text" enterkeyhint="search" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="DD/MM/YYYY" maxlength="32" aria-describedby="date-search-hint date-search-error"></label>
      <p id="date-search-hint" class="small muted">${hint}</p>
      <p id="date-search-error" class="search-error" role="alert" hidden></p>
      <div class="actions"><button type="button" class="textbtn" data-act="closeModal">${T.cancel}</button><button class="btn" type="submit">${T.go}</button></div></form>`);
    $('modal').setAttribute('aria-labelledby', 'date-search-title');
    const input = $('search-date-input');
    input.addEventListener('input', () => { input.removeAttribute('aria-invalid'); $('date-search-error').hidden = true; });
    $('date-search-form').addEventListener('submit', (e) => {
      e.preventDefault();
      const date = parseSearchDate(input.value);
      if (!date) {
        input.setAttribute('aria-invalid', 'true');
        $('date-search-error').textContent = error;
        $('date-search-error').hidden = false; input.focus(); return;
      }
      closeModal(); closeSheet(); goTo(date, false);
      $('view').scrollTop = 0;
      const cell = document.querySelector(`#mgrid [data-date="${date}"]`);
      if (cell) { cell.scrollIntoView({ block: 'nearest' }); cell.focus({ preventScroll: true }); }
      toast(`${T.selected}: ${fullDate(date)}`);
    });
  }
  function goTo(s, open) {
    if (!validDate(s)) return;
    const p = parse(s);
    st.y = p.y; st.m = p.m; st.sel = s; st.year = p.y; st.tab = 0; st.annual = false; render(); if (open) openSheet(s);
  }
  function selectVisibleDate(date) {
    if (!validDate(date)) return;
    const scroll = $('view').scrollTop;
    st.sel = date; render();
    $('view').scrollTop = scroll;
    // Rendering used to destroy the opener, so closing details focused the dock.
    const cell = document.querySelector(`#mgrid [data-date="${date}"]`);
    if (cell) cell.focus({preventScroll:true});
    openSheet(date);
  }
  function shiftMonth(n) {
    let m = st.m + n, y = st.y; while (m < 1) { m += 12; y--; } while (m > 12) { m -= 12; y++; }
    if (y < MIN_Y || y > MAX_Y) return; st.y = y; st.year = y; st.m = m; render();
  }
  // Swipe anywhere on the month page; vertical gestures remain normal scrolling.
  function attachSwipe(el) {
    let start = null;
    el.addEventListener('touchstart', (e) => {
      start = null;
      if ((st.tab !== 0 || !e.target.closest('.holiday-calendar')) || !$('modal').hidden || !$('sheet').hidden || e.touches.length !== 1) return;
      if (e.target.closest('input, textarea, select, a')) return;
      start = { x: e.touches[0].clientX, y: e.touches[0].clientY };
    }, { passive: true });
    el.addEventListener('touchmove', (e) => {
      if (!start) return;
      if (e.touches.length !== 1) { start = null; return; }
      const dx = e.touches[0].clientX - start.x, dy = e.touches[0].clientY - start.y;
      if (Math.abs(dy) > 20 && Math.abs(dy) >= Math.abs(dx)) { start = null; return; }
      if (Math.abs(dx) > 20 && Math.abs(dx) > Math.abs(dy) * 1.5 && e.cancelable) e.preventDefault();
    }, { passive: false });
    el.addEventListener('touchend', (e) => {
      if (!start) return;
      const origin = start; start = null;
      if (!e.changedTouches.length || e.touches.length || st.tab !== 0 || !$('modal').hidden || !$('sheet').hidden) return;
      const dx = e.changedTouches[0].clientX - origin.x, dy = e.changedTouches[0].clientY - origin.y;
      if (Math.abs(dx) > 60 && Math.abs(dx) > Math.abs(dy) * 1.5) {
        st._swiped = Date.now(); shiftMonth(dx < 0 ? 1 : -1);
      }
    }, { passive: true });
    el.addEventListener('touchcancel', () => { start = null; }, { passive: true });
  }
  attachSwipe($('view'));

  // ---------- Events (delegated) ----------
  document.addEventListener('click', (e) => {
    if (st._swiped && Date.now() - st._swiped < 400) { e.preventDefault(); return; }
    const t = e.target.closest('button, [data-act]'); if (!t) return;
    const d = t.dataset;
    if (d.tab != null) {
      clearToast();
      const t = +d.tab;
      if (!NAV_TABS.includes(t)) return;
      st.tab = t; st.annual = false; closeSheet(); render(); $('view').scrollTop = 0; $('tab-' + st.tab).focus({ preventScroll: true }); return;
    }
    if (d.date) { if (st._swiped && Date.now() - st._swiped < 400) return; selectVisibleDate(d.date); return; }
    if (d.open) { if (st.tab === 0) selectVisibleDate(d.open); else goTo(d.open, true); return; }
    if (d.monthFilter != null) { st.monthFilter = +d.monthFilter; refreshMonthlyHolidayResults(); return; }
    if (d.filter != null) { st.filter = +d.filter; renderAnnualHolidays(); return; }
    if (d.set) { const v = d.val; settings[d.set] = (d.set === 'weekStart' || d.set === 'hijriShift') ? +v : d.set === 'deviceZone' ? v === 'true' : v; saveSettings(); return; }
    if (d.rmimp) { delete imported[d.rmimp]; LS.set('imported', imported); buildDB(); render(); return; }
    if (d.edit) { const ev = events.find((x) => x.id === d.edit); if (ev) openEditor(ev.date, ev); return; }
    if (d.del) { confirmDelete(d.del); return; }
    switch (d.act) {
      case 'toggleHolidays': toggleHolidays(); break;
      case 'iconSetup': if (window.AndroidBridge && typeof AndroidBridge.iconSetup === 'function') AndroidBridge.iconSetup(); break;
      case 'openAnnual': st.year = st.y; st.annual = true; st.settingsTop = $('view').scrollTop; clearToast(); render(); $('view').scrollTop = 0; $('view').focus({preventScroll:true}); break;
      case 'closeAnnual': closeAnnual(); break;
      case 'prevM': shiftMonth(-1); break;
      case 'nextM': shiftMonth(1); break;
      case 'today': goTo(today, false); break;
      case 'jump': openJump(); break;
      case 'dateSearch': openDateSearch(); break;
      case 'details': openSheet(st.sel); break;
      case 'add': openEditor(st.sel); break;
      case 'addSheet': openEditor(st.sheetDate); break;
      case 'closeSheet': closeSheet(); break;
      case 'closeModal': closeModal(); break;
      case 'prevY': if (st.year > MIN_Y) { st.year--; render(); } break;
      case 'nextY': if (st.year < MAX_Y) { st.year++; render(); } break;
      case 'exportEv': exportEvents(); break;
    }
  });
  $('sheet-backdrop').addEventListener('click', closeSheet);
  $('modal-backdrop').addEventListener('click', closeModal);
  document.addEventListener('keydown', (e) => {
    const dialog = !$('modal').hidden ? $('modal') : !$('sheet').hidden ? $('sheet') : null;
    if (dialog && e.key === 'Tab') {
      const targets = [...dialog.querySelectorAll('button, input, select, textarea, a[href], [tabindex="0"]')]
        .filter((x) => !x.disabled && !x.closest('[hidden], [inert]') && x.getClientRects().length);
      const first = targets[0], last = targets[targets.length - 1];
      if (!targets.length) { e.preventDefault(); return; }
      if (!dialog.contains(document.activeElement) || (e.shiftKey && document.activeElement === first)) {
        e.preventDefault(); (e.shiftKey ? last : first).focus(); return;
      }
      if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); return; }
    }
    if (e.target.closest && e.target.closest('#tabs') && ['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(e.key)) {
      e.preventDefault();
      const index = NAV_TABS.indexOf(st.tab);
      const i = e.key === 'Home' ? NAV_TABS[0] : e.key === 'End' ? NAV_TABS[NAV_TABS.length - 1] : NAV_TABS[(index + (e.key === 'ArrowRight' ? 1 : NAV_TABS.length - 1)) % NAV_TABS.length];
      $('tab-' + i).click();
      $('tab-' + i).focus();
      return;
    }
    if (e.key === 'Escape' && window.BanglaCalendarBack()) e.preventDefault();
    if ($('modal').hidden && $('sheet').hidden && st.tab === 0 && !/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)) {
      if (e.key === 'ArrowLeft') shiftMonth(-1); if (e.key === 'ArrowRight') shiftMonth(1);
    }
  });
  function closeAnnual() {
    st.annual = false; render(); $('view').scrollTop = st.settingsTop || 0;
    const opener = document.querySelector('[data-act="openAnnual"]'); if (opener) opener.focus({preventScroll:true});
  }
  // Android back button: the WebView wrapper calls this; returns true if something was closed.
  window.BanglaCalendarBack = function () { // called by the Android wrapper; returns true if handled
    if (!$('modal').hidden) { closeModal(); return true; } if (!$('sheet').hidden) { closeSheet(); return true; }
    if (st.annual) { closeAnnual(); return true; }
    if (st.tab === 0 && st.holidaysOpen) { toggleHolidays(); $('holiday-toggle').focus({preventScroll:true}); return true; }
    if (st.tab !== 0) { st.tab = 0; render(); $('view').scrollTop = 0; return true; }
    return false;
  };
  function exportEvents() {
    const json = JSON.stringify(events, null, 1), name = `bangla-calendar-events-${today}.json`;
    if (window.AndroidBridge && AndroidBridge.share) { AndroidBridge.share(name, json); return; } // Android wrapper: share/save sheet
    const blob = new Blob([json], { type: 'application/json' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  }

  // One timer, aligned to the next local midnight (or explicitly chosen Dhaka
  // midnight), plus a low-cost visible clock-jump guard. Hidden pages do no polling.
  let clockTimer = null;
  function armClock() {
    clearTimeout(clockTimer); clockTimer = null;
    if (document.hidden) return;
    const now = new Date();
    const local = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1).getTime();
    const dhaka = (Math.floor((now.getTime() + 21600000) / 86400000) + 1) * 86400000 - 21600000;
    const boundary = settings.deviceZone ? local : dhaka;
    clockTimer = setTimeout(syncClock, Math.max(1, Math.min(60000, boundary - now.getTime())));
  }
  function syncClock() {
    const n = todayStr();
    if (n !== today) {
      const old = today, oldParts = parse(old), fresh = parse(n);
      today = n;
      // Follow today only if the user was viewing today's month/date. Never jump
      // away from a historical month or destroy text being entered in a modal.
      if (st.sel === old) {
        st.sel = n;
        if (st.y === oldParts.y && st.m === oldParts.m) { st.y = fresh.y; st.m = fresh.m; }
      }
      const scroll = $('view').scrollTop;
      const focused = document.activeElement && document.activeElement.id;
      if (st.tab === 0 && st.holidaysOpen && focused === 'month-q') {
        renderTabs();
        const panel = document.querySelector('.holiday-calendar .calendar-panel');
        if (panel) panel.outerHTML = monthPanelHtml();
        refreshMonthlyHolidayResults();
        syncHolidayDisclosure();
      } else if (st.tab !== 3) render(); else renderTabs();
      $('view').scrollTop = scroll;
      const target = focused && $(focused); if (target) target.focus({preventScroll:true});
    } else renderTabs(); // phone-date dock icon can differ from explicit Dhaka mode
    armClock();
  }
  document.addEventListener('visibilitychange', () => { if (document.hidden) armClock(); else syncClock(); });
  window.addEventListener('focus', syncClock);
  window.addEventListener('pageshow', syncClock);
  if (window.matchMedia) {
    const mq = matchMedia('(prefers-color-scheme: dark)');
    const changed = () => { if (settings.theme === 'system') applyTheme(); };
    if (mq.addEventListener) mq.addEventListener('change', changed);
    else if (mq.addListener) mq.addListener(changed);
  }

  // Expose pure helpers for tests
  window.BC = { parseSearchDate, toBangla, toHijri, dow, classify, gridCells, validateYear, validDate, applyTheme, on, todayStr, syncClock, settings: () => settings };

  buildDB(); applyTheme(); render(); armClock();
})();
