/* বাংলা ক্যালেন্ডার — অফলাইন HTML অ্যাপ (com.t.calendar)
 * রঙের নিয়ম: শুক্র ও শনি সবসময় লাল; রবি–বৃহস্পতি সরকারি ছুটি (GENERAL/EXECUTIVE/SPECIAL) সবুজ; বাকি সব সাধারণ।
 */
(function () {
  'use strict';

  // ---------- Storage ----------
  const LS = {
    get(k, d) { try { const v = localStorage.getItem('bc.' + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem('bc.' + k, JSON.stringify(v)); } catch (e) {} },
  };
  const defaults = { lang: 'bn', theme: 'system', weekStart: 0, showBangla: true, showIslamic: true, hijriShift: -1, deviceZone: false };
  let settings = Object.assign({}, defaults, LS.get('settings', {}));
  let events = LS.get('events', []);          // {id,title,desc,date,allDay,time}
  let imported = LS.get('imported', {});      // year -> holiday-year JSON

  // ---------- Dates (all as 'YYYY-MM-DD' strings, calculated in UTC to avoid DST/zone bugs) ----------
  const pad = (n) => String(n).padStart(2, '0');
  const iso = (y, m, d) => `${y}-${pad(m)}-${pad(d)}`;
  const parse = (s) => { const [y, m, d] = s.split('-').map(Number); return { y, m, d }; };
  const epochDay = (s) => { const p = parse(s); return Math.floor(Date.UTC(p.y, p.m - 1, p.d) / 86400000); };
  const fromEpoch = (e) => { const t = new Date(e * 86400000); return iso(t.getUTCFullYear(), t.getUTCMonth() + 1, t.getUTCDate()); };
  const addDays = (s, n) => fromEpoch(epochDay(s) + n);
  const dow = (s) => ((epochDay(s) % 7) + 7 + 4) % 7; // 1970-01-01 was Thursday → 0=Sun … 6=Sat
  const daysInMonth = (y, m) => new Date(Date.UTC(y, m, 0)).getUTCDate();
  const isLeap = (y) => (y % 4 === 0 && y % 100 !== 0) || y % 400 === 0;
  const isWeekly = (s) => { const w = dow(s); return w === 5 || w === 6; };
  function todayStr() {
    const opt = settings.deviceZone ? {} : { timeZone: 'Asia/Dhaka' };
    try {
      const parts = new Intl.DateTimeFormat('en-CA', Object.assign({ year: 'numeric', month: '2-digit', day: '2-digit' }, opt)).formatToParts(new Date());
      const g = (t) => parts.find((p) => p.type === t).value;
      return `${g('year')}-${g('month')}-${g('day')}`;
    } catch (e) { const d = new Date(); return iso(d.getFullYear(), d.getMonth() + 1, d.getDate()); }
  }

  // ---------- Bengali calendar (Bangladesh revised; 1 Boishakh = 14 April) ----------
  function bnMonthLengths(startYear) { return [31, 31, 31, 31, 31, 31, 30, 30, 30, 30, isLeap(startYear + 1) ? 30 : 29, 30]; }
  function toBangla(s) {
    const p = parse(s);
    const base = (p.m < 4 || (p.m === 4 && p.d < 14)) ? p.y - 1 : p.y;
    let rem = epochDay(s) - epochDay(iso(base, 4, 14));
    const L = bnMonthLengths(base); let mi = 0;
    while (rem >= L[mi]) { rem -= L[mi]; mi++; }
    return { y: base - 593, m: mi, d: rem + 1 };
  }

  // ---------- Islamic (Hijri) calendar ----------
  // Umm al-Qura (via Intl) shifted by settings.hijriShift days. Bangladesh sights the moon locally, usually ~1 day after Saudi → default -1.
  function hjParts(f, e) {
    try {
      const o = {}; f.formatToParts(new Date(e * 86400000 + 43200000)).forEach((x) => { o[x.type] = x.value; });
      const y = +o.year, m = +o.month, d = +o.day;
      return y > 0 && m >= 1 && m <= 12 && d >= 1 && d <= 30 ? { y, m, d } : null;
    } catch (err) { return null; }
  }
  function hjCivil(e) { // tabular Islamic calendar, fallback if Intl has no Islamic calendar
    const EPOCH = 1948439.5, jd = e + 2440587.5;
    const toJd = (yy, mm, dd) => dd + Math.ceil(29.5 * (mm - 1)) + (yy - 1) * 354 + Math.floor((3 + 11 * yy) / 30) + EPOCH - 1;
    const y = Math.floor((30 * (jd - EPOCH) + 10646) / 10631);
    const m = Math.min(12, Math.ceil((jd - (29 + toJd(y, 1, 1))) / 29.5) + 1);
    return { y, m, d: jd - toJd(y, m, 1) + 1 };
  }
  const hjFmt = (() => {
    try {
      const f = new Intl.DateTimeFormat('en-u-ca-islamic-umalqura-nu-latn', { timeZone: 'UTC', day: 'numeric', month: 'numeric', year: 'numeric' });
      const p = hjParts(f, Math.floor(Date.UTC(2026, 2, 20) / 86400000));
      return p && p.y === 1447 && p.m === 10 && p.d === 1 ? f : null;
    } catch (err) { return null; }
  })();
  const hjCache = new Map();
  function toHijri(s) {
    const e = epochDay(s) + (+settings.hijriShift || 0), key = e;
    let r = hjCache.get(key); if (r) return r;
    r = (hjFmt && hjParts(hjFmt, e)) || hjCivil(e); hjCache.set(key, r); return r;
  }

  // ---------- Strings ----------
  const BN_DIG = '০১২৩৪৫৬৭৮৯';
  const S = {
    bn: {
      tabs: ['মাস', 'বছর', 'ছুটি', 'সেটিংস'], today: 'আজ', months: ['জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'],
      bmonths: ['বৈশাখ', 'জ্যৈষ্ঠ', 'আষাঢ়', 'শ্রাবণ', 'ভাদ্র', 'আশ্বিন', 'কার্তিক', 'অগ্রহায়ণ', 'পৌষ', 'মাঘ', 'ফাল্গুন', 'চৈত্র'],
      wd: ['রবিবার', 'সোমবার', 'মঙ্গলবার', 'বুধবার', 'বৃহস্পতিবার', 'শুক্রবার', 'শনিবার'], wds: ['রবি', 'সোম', 'মঙ্গল', 'বুধ', 'বৃহঃ', 'শুক্র', 'শনি'],
      hmonths: ['মুহাররম', 'সফর', 'রবিউল আউয়াল', 'রবিউস সানি', 'জমাদিউল আউয়াল', 'জমাদিউস সানি', 'রজব', 'শাবান', 'রমজান', 'শাওয়াল', 'জিলকদ', 'জিলহজ'], hj: 'হিজরি',
      showIslamic: 'ইসলামিক (হিজরি) তারিখ দেখান', hjAdj: 'হিজরি তারিখ সমন্বয়', hjOpt: ['২ দিন পিছনে', '১ দিন পিছনে (বাংলাদেশ)', 'সৌদি (উম্মুল কুরা)', '১ দিন এগিয়ে'],
      hjInfo: 'হিজরি তারিখ উম্মুল কুরা পদ্ধতিতে হিসাব করা। বাংলাদেশে চাঁদ দেখার উপর নির্ভর করে ১ দিনের হেরফের হতে পারে — মিল না থাকলে এখান থেকে ঠিক করুন।',
      bs: 'বঙ্গাব্দ', legend: 'রঙের অর্থ', lRed: 'লাল: সাপ্তাহিক ছুটি (শুক্র ও শনি)', lGreen: 'সবুজ: সরকারি ছুটি (রবি–বৃহস্পতি)', lNormal: 'সাধারণ: কর্মদিবস',
      lToday: 'বৃত্ত: আজ', lBar: 'সবুজ দাগ: শুক্র/শনিতে পড়া সরকারি ছুটি', lOpt: 'ফাঁপা বৃত্ত: ঐচ্ছিক ছুটি', lObs: 'ড্যাশ: দিবস (ছুটি নয়)', lEv: 'বিন্দু: আপনার ইভেন্ট',
      monthHol: 'এই মাসের ছুটি', noHolMonth: 'এই মাসে কোনো সরকারি ছুটি নেই', upcoming: 'আসন্ন সরকারি ছুটি', noUpcoming: 'আসন্ন ছুটির যাচাইকৃত তথ্য নেই',
      noData: (y) => `${N(y)} সালের যাচাইকৃত ছুটির তথ্য নেই। শুধু শুক্র ও শনি দেখানো হচ্ছে। সেটিংস থেকে সরকারি তালিকা (JSON) ইমপোর্ট করুন।`,
      weekly: 'সাপ্তাহিক ছুটি', working: 'কর্মদিবস', cWeekly: 'সাপ্তাহিক ছুটি', cPublic: 'সরকারি ছুটি', cTotal: 'মোট ছুটির দিন', cOpt: 'ঐচ্ছিক',
      selected: 'নির্বাচিত তারিখ', details: 'বিস্তারিত', events: 'ইভেন্ট', noEvents: 'কোনো ইভেন্ট নেই', addEvent: 'ইভেন্ট যোগ করুন', editEvent: 'ইভেন্ট সম্পাদনা',
      title: 'শিরোনাম', desc: 'বিবরণ', date: 'তারিখ', time: 'সময়', allDay: 'সারাদিন', titleReq: 'শিরোনাম লিখুন', delConfirm: 'এই ইভেন্টটি মুছে ফেলবেন?',
      save: 'সংরক্ষণ', cancel: 'বাতিল', del: 'মুছুন', edit: 'সম্পাদনা', close: 'বন্ধ', go: 'যান', jump: 'তারিখে যান', year: 'বছর', exact: 'নির্দিষ্ট তারিখ',
      holList: 'ছুটির তালিকা', search: 'ছুটি খুঁজুন', fAll: 'সব', fPub: 'সরকারি', fOpt: 'ঐচ্ছিক', fObs: 'দিবস', noRes: 'কিছু পাওয়া যায়নি', source: 'উৎস',
      moon: 'চাঁদ দেখার উপর নির্ভরশীল — তারিখ পরিবর্তন হতে পারে', dataStatus: 'তথ্যের অবস্থা', bundled: 'অ্যাপের সাথে', importedL: 'ইমপোর্ট করা', reviewed: 'সর্বশেষ যাচাই',
      settings: 'সেটিংস', language: 'ভাষা', theme: 'থিম', tSys: 'সিস্টেম অনুযায়ী', tLight: 'লাইট', tDark: 'ডার্ক', weekStart: 'সপ্তাহ শুরু', showBangla: 'বাংলা তারিখ দেখান',
      tz: 'সময় অঞ্চল', tzDhaka: 'বাংলাদেশ (Asia/Dhaka)', tzDevice: 'ডিভাইসের সময় অঞ্চল', holData: 'ছুটির তথ্যভাণ্ডার', importBtn: 'ছুটির JSON ইমপোর্ট',
      importInfo: 'নতুন বছরের সরকারি তালিকা অ্যাপ আপডেট ছাড়াই যোগ করা যায় (একই বছরের তথ্য প্রতিস্থাপিত হবে)।', removeImp: 'ইমপোর্ট মুছুন',
      importOk: (y, n) => `${N(y)} সালের ${N(n)}টি রেকর্ড ইমপোর্ট হয়েছে`, importFail: (m) => `ইমপোর্ট ব্যর্থ: ${m}`,
      backup: 'ইভেন্ট ব্যাকআপ', exportEv: 'ইভেন্ট এক্সপোর্ট', importEv: 'ইভেন্ট রিস্টোর', evRestored: (n) => `${N(n)}টি ইভেন্ট ফিরিয়ে আনা হয়েছে`,
      about: 'অ্যাপ সম্পর্কে', aboutText: 'বাংলাদেশের গ্রেগরীয়, বঙ্গাব্দ ও হিজরি ক্যালেন্ডার। ছুটির তথ্য জনপ্রশাসন মন্ত্রণালয়ের প্রজ্ঞাপন থেকে নেওয়া; চাঁদনির্ভর ছুটি সরকারি ঘোষণায় বদলাতে পারে। সম্পূর্ণ অফলাইন — কোনো ইন্টারনেট, বিজ্ঞাপন বা ট্র্যাকিং নেই। ইভেন্ট শুধু এই ফোনেই থাকে।',
      prevM: 'আগের মাস', nextM: 'পরের মাস', prevY: 'আগের বছর', nextY: 'পরের বছর', tomorrow: 'আগামীকাল', inDays: (n) => `${N(n)} দিন পর`,
      cat: { GENERAL: 'সাধারণ ছুটি', EXECUTIVE: 'নির্বাহী আদেশে ছুটি', SPECIAL: 'বিশেষ সরকারি ছুটি', REGIONAL: 'আঞ্চলিক ছুটি (নির্দিষ্ট জেলা)', OPTIONAL: 'ঐচ্ছিক ছুটি', OBSERVANCE: 'দিবস (ছুটি নয়)', WORKING_DAY: 'অফিস খোলা (কর্মদিবস)' },
      grp: { MUSLIM: 'মুসলিম', HINDU: 'হিন্দু', CHRISTIAN: 'খ্রিস্টান', BUDDHIST: 'বৌদ্ধ', ETHNIC: 'ক্ষুদ্র নৃগোষ্ঠী' },
      ver: { VERIFIED: 'যাচাইকৃত', PROVISIONAL: 'প্রাথমিক ঘোষণা — চূড়ান্ত প্রজ্ঞাপনের অপেক্ষায়', UNVERIFIED: 'যাচাই হয়নি' }, moonShort: 'চাঁদনির্ভর',
      am: 'পূর্বাহ্ণ', pm: 'অপরাহ্ণ',
    },
    en: {
      tabs: ['Month', 'Year', 'Holidays', 'Settings'], today: 'Today', months: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
      bmonths: ['Boishakh', 'Joishtho', 'Asharh', 'Srabon', 'Bhadro', 'Ashwin', 'Kartik', 'Ogrohayon', 'Poush', 'Magh', 'Falgun', 'Choitro'],
      wd: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'], wds: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
      hmonths: ['Muharram', 'Safar', "Rabi' I", "Rabi' II", 'Jumada I', 'Jumada II', 'Rajab', "Sha'ban", 'Ramadan', 'Shawwal', "Dhul Qa'dah", 'Dhul Hijjah'], hj: 'AH',
      showIslamic: 'Show Islamic (Hijri) dates', hjAdj: 'Hijri date adjustment', hjOpt: ['2 days back', '1 day back (Bangladesh)', 'Saudi (Umm al-Qura)', '1 day ahead'],
      hjInfo: 'Hijri dates are calculated with the Umm al-Qura method. Bangladesh follows local moon sighting, so it can differ by a day — adjust here if it does not match.',
      bs: 'BS', legend: 'Colour guide', lRed: 'Red: weekly holiday (Fri & Sat)', lGreen: 'Green: government holiday (Sun–Thu)', lNormal: 'Normal: working day',
      lToday: 'Ring: today', lBar: 'Green bar: govt holiday on Fri/Sat', lOpt: 'Hollow ring: optional holiday', lObs: 'Dash: observance (no holiday)', lEv: 'Dot: your event',
      monthHol: 'Holidays this month', noHolMonth: 'No government holidays this month', upcoming: 'Upcoming government holidays', noUpcoming: 'No verified upcoming holidays',
      noData: (y) => `No verified holiday data for ${y}. Only Fridays and Saturdays are shown. Import the official list (JSON) in Settings.`,
      weekly: 'Weekly holiday', working: 'Working day', cWeekly: 'Weekly holidays', cPublic: 'Govt holidays', cTotal: 'Total days off', cOpt: 'Optional',
      selected: 'Selected date', details: 'Details', events: 'Events', noEvents: 'No events', addEvent: 'Add event', editEvent: 'Edit event',
      title: 'Title', desc: 'Description', date: 'Date', time: 'Time', allDay: 'All day', titleReq: 'Title is required', delConfirm: 'Delete this event?',
      save: 'Save', cancel: 'Cancel', del: 'Delete', edit: 'Edit', close: 'Close', go: 'Go', jump: 'Go to date', year: 'Year', exact: 'Exact date',
      holList: 'Holiday list', search: 'Search holidays', fAll: 'All', fPub: 'Public', fOpt: 'Optional', fObs: 'Observances', noRes: 'No results', source: 'Source',
      moon: 'Depends on moon sighting — date may change', dataStatus: 'Data status', bundled: 'Bundled', importedL: 'Imported', reviewed: 'Last reviewed',
      settings: 'Settings', language: 'Language', theme: 'Theme', tSys: 'Follow system', tLight: 'Light', tDark: 'Dark', weekStart: 'Week starts on', showBangla: 'Show Bangla dates',
      tz: 'Time zone', tzDhaka: 'Bangladesh (Asia/Dhaka)', tzDevice: 'Device time zone', holData: 'Holiday database', importBtn: 'Import holiday JSON',
      importInfo: "Add a new year's official list without updating the app (replaces that year's data).", removeImp: 'Remove import',
      importOk: (y, n) => `Imported ${n} records for ${y}`, importFail: (m) => `Import failed: ${m}`,
      backup: 'Event backup', exportEv: 'Export events', importEv: 'Restore events', evRestored: (n) => `Restored ${n} events`,
      about: 'About', aboutText: 'Gregorian, Bengali (Bangabda) and Hijri calendar for Bangladesh. Holiday data from Ministry of Public Administration notifications; moon-dependent holidays may change. Fully offline — no internet, ads or tracking. Events stay on this phone.',
      prevM: 'Previous month', nextM: 'Next month', prevY: 'Previous year', nextY: 'Next year', tomorrow: 'tomorrow', inDays: (n) => `in ${n} days`,
      cat: { GENERAL: 'General holiday', EXECUTIVE: 'Executive-order holiday', SPECIAL: 'Special public holiday', REGIONAL: 'Regional holiday (specific districts)', OPTIONAL: 'Optional holiday', OBSERVANCE: 'Observance (no holiday)', WORKING_DAY: 'Offices open (working day)' },
      grp: { MUSLIM: 'Muslim', HINDU: 'Hindu', CHRISTIAN: 'Christian', BUDDHIST: 'Buddhist', ETHNIC: 'Ethnic minority' },
      ver: { VERIFIED: 'Verified', PROVISIONAL: 'Provisional — awaiting final notification', UNVERIFIED: 'Unverified' }, moonShort: 'moon-dependent',
      am: 'AM', pm: 'PM',
    },
  };
  let T = S[settings.lang];
  const bn = () => settings.lang === 'bn';
  function N(n) { const s = String(n); return bn() ? s.replace(/[0-9]/g, (c) => BN_DIG[c]) : s; }
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const toBn = (n) => String(n).replace(/[0-9]/g, (c) => BN_DIG[c]);
  function withLang(l, fn) { const ol = settings.lang, ot = T; settings.lang = l; T = S[l]; try { return fn(); } finally { settings.lang = ol; T = ot; } }
  const mName = (m) => T.months[m - 1];
  const monthYear = (y, m) => `${mName(m)} ${N(y)}`;
  const fullDate = (s) => { const p = parse(s); return `${T.wd[dow(s)]}, ${N(p.d)} ${mName(p.m)} ${N(p.y)}`; };
  const shortDate = (s) => { const p = parse(s); return `${N(p.d)} ${bn() ? mName(p.m) : mName(p.m).slice(0, 3)}`; };
  const banglaDate = (s) => { const b = toBangla(s); return `${N(b.d)} ${T.bmonths[b.m]} ${N(b.y)} ${T.bs}`; };
  const islamicDate = (s) => { const h = toHijri(s); return `${N(h.d)} ${T.hmonths[h.m - 1]} ${N(h.y)} ${T.hj}`; };
  function islamicSpan(y, m) {
    const a = toHijri(iso(y, m, 1)), b = toHijri(iso(y, m, daysInMonth(y, m))), nm = (x) => T.hmonths[x.m - 1];
    if (a.y === b.y) return a.m === b.m ? `${nm(a)} ${N(a.y)} ${T.hj}` : `${nm(a)}–${nm(b)} ${N(a.y)} ${T.hj}`;
    return `${nm(a)} ${N(a.y)} – ${nm(b)} ${N(b.y)} ${T.hj}`;
  }
  function banglaSpan(y, m) {
    const a = toBangla(iso(y, m, 1)), b = toBangla(iso(y, m, daysInMonth(y, m)));
    return a.y === b.y ? `${T.bmonths[a.m]}–${T.bmonths[b.m]} ${N(a.y)} ${T.bs}` : `${T.bmonths[a.m]} ${N(a.y)} – ${T.bmonths[b.m]} ${N(b.y)} ${T.bs}`;
  }
  function fmtTime(t) { if (!t) return ''; const [h, mi] = t.split(':').map(Number); const h12 = h % 12 === 0 ? 12 : h % 12; return `${N(h12)}:${N(pad(mi))} ${h < 12 ? T.am : T.pm}`; }

  // ---------- Holiday database ----------
  const CATS = ['GENERAL', 'EXECUTIVE', 'SPECIAL', 'REGIONAL', 'OPTIONAL', 'OBSERVANCE', 'WORKING_DAY'];
  const PUBLIC = new Set(['GENERAL', 'EXECUTIVE', 'SPECIAL']);
  const GROUPS = ['MUSLIM', 'HINDU', 'CHRISTIAN', 'BUDDHIST', 'ETHNIC'];
  const VERS = ['VERIFIED', 'PROVISIONAL', 'UNVERIFIED'];
  function validateYear(o) {
    if (!o || typeof o !== 'object') throw new Error('not a JSON object');
    if (o.schema !== 1) throw new Error('schema must be 1');
    if (o.country !== 'BD') throw new Error('country must be "BD"');
    const y = o.year; if (!(Number.isInteger(y) && y >= 1971 && y <= 2200)) throw new Error('year must be 1971–2200');
    if (!Array.isArray(o.holidays)) throw new Error('holidays array missing');
    const ids = new Set();
    const list = o.holidays.map((h, i) => {
      if (!/^\d{4}-\d{2}-\d{2}$/.test(h.date || '')) throw new Error(`record ${i}: invalid date`);
      const p = parse(h.date); if (p.y !== y || p.m < 1 || p.m > 12 || p.d < 1 || p.d > daysInMonth(p.y, p.m)) throw new Error(`record ${i}: date ${h.date} invalid or outside ${y}`);
      const nb = (h.nameBn || '').trim(), ne = (h.nameEn || '').trim(); if (!nb && !ne) throw new Error(`record ${i}: name required`);
      if (!CATS.includes(h.category)) throw new Error(`record ${i}: category '${h.category}'`);
      if (h.optionalGroup != null && !GROUPS.includes(h.optionalGroup)) throw new Error(`record ${i}: optionalGroup`);
      const v = h.verification == null ? 'UNVERIFIED' : h.verification; if (!VERS.includes(v)) throw new Error(`record ${i}: verification`);
      const id = h.id || `${h.date}-${i}`; if (ids.has(id)) throw new Error(`record ${i}: duplicate id`); ids.add(id);
      return { id, date: h.date, nameBn: nb || ne, nameEn: ne || nb, category: h.category, optionalGroup: h.optionalGroup || null, moonDependent: !!h.moonDependent, verification: v, source: h.source || null, sourceUrl: h.sourceUrl || null, notes: h.notes || null };
    }).sort((a, b) => a.date < b.date ? -1 : a.date > b.date ? 1 : 0);
    return { year: y, title: o.title || '', primarySource: o.primarySource && o.primarySource.name, lastReviewed: o.lastReviewed || null, holidays: list };
  }
  let DB = {}, byDate = {};
  function buildDB() {
    DB = {}; byDate = {};
    (window.BUNDLED_HOLIDAYS || []).forEach((o) => { try { const y = validateYear(o); y.origin = 'bundled'; DB[y.year] = y; } catch (e) { console.error(e); } });
    Object.values(imported).forEach((o) => { try { const y = validateYear(o); y.origin = 'imported'; DB[y.year] = y; } catch (e) {} });
    Object.values(DB).forEach((y) => y.holidays.forEach((h) => { (byDate[h.date] = byDate[h.date] || []).push(h); }));
  }
  const on = (s) => byDate[s] || [];
  const hasYear = (y) => !!DB[y];
  function classify(s) {
    const recs = on(s), weekly = isWeekly(s);
    const pub = recs.filter((h) => PUBLIC.has(h.category));
    return {
      weekly, pub, recs, color: weekly ? 'red' : pub.length ? 'green' : 'normal',
      opt: recs.some((h) => h.category === 'OPTIONAL' || h.category === 'REGIONAL'),
      obs: recs.some((h) => h.category === 'OBSERVANCE' || h.category === 'WORKING_DAY'),
    };
  }
  function upcomingPublic(from, n) {
    const out = []; Object.keys(DB).sort().forEach((y) => DB[y].holidays.forEach((h) => { if (h.date >= from && PUBLIC.has(h.category)) out.push(h); }));
    return out.slice(0, n);
  }
  const hName = (h) => bn() ? h.nameBn : h.nameEn;
  const kindClass = (h) => PUBLIC.has(h.category) ? 'k-pub' : (h.category === 'OPTIONAL' || h.category === 'REGIONAL') ? 'k-opt' : h.category === 'OBSERVANCE' ? 'k-obs' : 'k-work';
  function catLine(h) {
    const p = [T.cat[h.category]]; if (h.optionalGroup) p.push(T.grp[h.optionalGroup]); if (h.moonDependent) p.push(T.moonShort);
    if (h.verification !== 'VERIFIED') p.push(T.ver[h.verification]); return p.join(' · ');
  }

  // ---------- State ----------
  let today = todayStr();
  const tp = parse(today);
  const st = { tab: 0, y: tp.y, m: tp.m, sel: today, year: tp.y, q: '', filter: 1 };
  const MIN_Y = 1900, MAX_Y = 2299;
  const $ = (id) => document.getElementById(id);

  function applyTheme() {
    const dark = settings.theme === 'dark' || (settings.theme === 'system' && window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches);
    document.documentElement.dataset.theme = dark ? 'dark' : 'light';
    document.documentElement.lang = settings.lang;
    const meta = document.querySelector('meta[name="theme-color"]'); if (meta) meta.content = dark ? '#121316' : '#FAFAF7';
    document.title = 'Calender';
  }
  function saveSettings() { LS.set('settings', settings); T = S[settings.lang]; applyTheme(); today = todayStr(); render(); }
  function toast(msg) { const t = $('toast'); t.textContent = msg; t.hidden = false; clearTimeout(toast.h); toast.h = setTimeout(() => (t.hidden = true), 3500); }

  // ---------- Rendering ----------
  const ICONS = ['📅', '▦', '★', '⚙'];
  function renderTabs() {
    $('tabs').innerHTML = T.tabs.map((l, i) => `<button role="tab" aria-selected="${st.tab === i}" data-tab="${i}"><span class="ico" aria-hidden="true">${ICONS[i]}</span>${esc(l)}</button>`).join('');
  }
  function weekOrder() { return [0, 1, 2, 3, 4, 5, 6].map((i) => (settings.weekStart + i) % 7); }
  function weekdaysHtml(short) {
    return `<div class="weekdays" aria-hidden="true">${weekOrder().map((d) => `<div class="${d === 5 || d === 6 ? 'wk' : ''}">${short ? (bn() ? T.wds[d] : T.wds[d].slice(0, 1)) : T.wds[d]}</div>`).join('')}</div>`;
  }
  function gridCells(y, m) {
    const first = dow(iso(y, m, 1)); const blanks = (first - settings.weekStart + 7) % 7; const n = daysInMonth(y, m);
    const cells = []; for (let i = 0; i < 42; i++) { const d = i - blanks + 1; cells.push(d >= 1 && d <= n ? iso(y, m, d) : null); } return cells;
  }
  function describe(s, c, evn) {
    const p = [fullDate(s), banglaDate(s)]; if (settings.showIslamic) p.push(islamicDate(s)); if (s === today) p.push(T.today); if (c.weekly) p.push(T.weekly);
    c.recs.forEach((h) => p.push(`${hName(h)}, ${T.cat[h.category]}`)); if (evn) p.push(`${N(evn)} ${T.events}`); return p.join('. ');
  }
  function evCount(s) { return events.filter((e) => e.date === s).length; }
  function monthGridHtml(y, m) { // always English digits for the Gregorian date; Bangla + Hijri sub-dates in Bengali digits
    const sb = settings.showBangla, si = settings.showIslamic, cn = sb || si ? '' : ' nob';
    return `<div class="grid" id="mgrid">${gridCells(y, m).map((s) => {
      if (!s) return `<div class="cell${cn}"></div>`;
      const c = classify(s), p = parse(s), ev = evCount(s);
      const cls = c.color === 'red' ? 'c-red' : c.color === 'green' ? 'c-green' : '';
      const marks = (c.weekly && c.pub.length ? '<i class="m-bar"></i>' : '') + (c.opt ? '<i class="m-opt"></i>' : '') + (c.obs ? '<i class="m-obs"></i>' : '') + (ev ? '<i class="m-ev"></i>' : '');
      let sub = '';
      if (sb || si) {
        const b = toBangla(s), h = si ? toHijri(s) : null;
        sub = `<span class="sub"><span class="b${b.d === 1 ? ' first' : ''}">${sb ? (b.d === 1 ? S.bn.bmonths[b.m] : toBn(b.d)) : ''}</span><span class="h${h && h.d === 1 ? ' first' : ''}">${h ? toBn(h.d) : ''}</span></span>`;
      }
      return `<button class="cell${cn}${s === today ? ' today' : ''}${s === st.sel ? ' sel' : ''}" data-date="${s}" aria-label="${esc(describe(s, c, ev))}"><span class="n ${cls}">${N(p.d)}</span>${sub}<span class="marks">${marks}</span></button>`;
    }).join('')}</div>`;
  }
  function holidayRow(h, opts) {
    const w = isWeekly(h.date), p = parse(h.date);
    const badge = `<div class="dbadge"><b class="${w ? 'c-red' : PUBLIC.has(h.category) ? 'c-green' : ''}">${N(p.d)}</b><small class="${w ? 'c-red' : ''}">${T.wds[dow(h.date)]}</small></div>`;
    const extra = opts && opts.away != null ? `<small class="muted">${esc(opts.away)}</small>` : '';
    return `<button class="row${opts && opts.past ? ' past' : ''}" data-open="${h.date}">${badge}<div style="flex:1"><div class="nm">${esc(hName(h))}</div><div class="cat ${kindClass(h)}">${esc(catLine(h))}</div></div>${extra}</button>`;
  }
  function counts(days, recs) {
    const weekly = days.filter((s) => isWeekly(s)).length;
    const pubW = days.filter((s) => !isWeekly(s) && classify(s).pub.length).length;
    const opt = recs.filter((h) => h.category === 'OPTIONAL').length;
    return `<div class="counts"><div><b class="c-red">${N(weekly)}</b><small>${T.cWeekly}</small></div><div><b class="c-green">${N(pubW)}</b><small>${T.cPublic}</small></div><div><b>${N(weekly + pubW)}</b><small>${T.cTotal}</small></div><div><b class="k-opt">${N(opt)}</b><small>${T.cOpt}</small></div></div>`;
  }
  function legendHtml() {
    return `<div class="card"><h3>${T.legend}</h3><div class="legend">
      <span><b class="c-red">${N(5)}</b>${T.lRed}</span><span><b class="c-green">${N(5)}</b>${T.lGreen}</span><span><b>${N(5)}</b>${T.lNormal}</span>
      <span><i class="lg-ring"></i>${T.lToday}</span><span><i class="m-bar"></i>${T.lBar}</span><span><i class="m-opt" style="width:8px;height:8px"></i>${T.lOpt}</span>
      <span><i class="m-obs" style="width:10px"></i>${T.lObs}</span><span><i class="m-ev" style="width:7px;height:7px"></i>${T.lEv}</span></div></div>`;
  }
  function renderMonth() {
    const { y, m } = st; const isCur = parse(today).y === y && parse(today).m === m;
    const recs = Object.values(DB).length && DB[y] ? DB[y].holidays.filter((h) => parse(h.date).m === m) : [];
    const hols = recs.filter((h) => PUBLIC.has(h.category) || h.category === 'OPTIONAL' || h.category === 'REGIONAL');
    const title = withLang('en', () => monthYear(y, m)); // month header always shows the English month name (user preference)
    const spans = (settings.showBangla || settings.showIslamic) ? `<div class="spans"><span class="sp-bn">${settings.showBangla ? withLang('bn', () => banglaSpan(y, m)) : ''}</span><span class="sp-hj">${settings.showIslamic ? withLang('bn', () => islamicSpan(y, m)) : ''}</span></div>` : '';
    const grid = withLang('en', () => weekdaysHtml(false) + monthGridHtml(y, m));
    const left = `<div class="hdr"><button class="iconbtn" data-act="prevM" aria-label="${T.prevM}">‹</button>
      <button class="title" data-act="jump" aria-label="${T.jump}"><b>${title}</b></button>
      <button class="iconbtn" data-act="nextM" aria-label="${T.nextM}">›</button>${isCur ? '' : `<button class="textbtn" data-act="today">${T.today}</button>`}</div>
      ${spans}${grid}`;
    const right = withLang('bn', () => !hasYear(y) ? `<div class="banner">ℹ️ <span>${esc(T.noData(y))}</span></div>`
      : `<div class="card"><button class="holhead" data-act="toggleHol" aria-expanded="${!!st.holOpen}"><h3>${T.monthHol}</h3><span class="cnt">${N(hols.length)}</span><span class="chev" aria-hidden="true">${st.holOpen ? '▲' : '▼'}</span></button>${st.holOpen ? `<div class="holbody">${hols.length ? hols.map((h) => holidayRow(h)).join('') : `<div class="muted">${T.noHolMonth}</div>`}</div>` : ''}</div>`);
    $('view').innerHTML = `<div class="wrap cols"><div>${left}</div><div>${right}</div></div>`;
    attachSwipe($('mgrid'));
  }
  function renderYear() {
    const y = st.year; const days = []; for (let e = epochDay(iso(y, 1, 1)); e <= epochDay(iso(y, 12, 31)); e++) days.push(fromEpoch(e));
    const recs = DB[y] ? DB[y].holidays : []; const b = toBangla(iso(y, 1, 1)).y;
    let html = `<div class="wrap"><div class="hdr"><button class="iconbtn" data-act="prevY" aria-label="${T.prevY}">‹</button><div class="title"><b>${N(y)}</b>${settings.showBangla ? `<small>${N(b)}–${N(b + 1)} ${T.bs}</small>` : ''}</div><button class="iconbtn" data-act="nextY" aria-label="${T.nextY}">›</button></div>
      ${hasYear(y) ? '' : `<div class="banner">ℹ️ <span>${esc(T.noData(y))}</span></div>`}<div class="card">${counts(days, recs)}</div><div class="yeargrid">`;
    const tpp = parse(today);
    for (let m = 1; m <= 12; m++) {
      html += `<button class="mini${tpp.y === y && tpp.m === m ? ' cur' : ''}" data-month="${m}" aria-label="${monthYear(y, m)}"><h4>${mName(m)}</h4>${weekdaysHtml(true)}<div class="g">${gridCells(y, m).map((s) => {
        if (!s) return '<span></span>'; const c = classify(s); return `<span class="${c.color === 'red' ? 'c-red' : c.color === 'green' ? 'c-green' : ''}${s === today ? ' t' : ''}">${N(parse(s).d)}</span>`; }).join('')}</div></button>`;
    }
    $('view').innerHTML = html + '</div></div>';
  }
  function renderHolidays() {
    const y = st.year, data = DB[y], q = st.q.trim().toLowerCase();
    const list = (data ? data.holidays : []).filter((h) => {
      const f = st.filter === 1 ? PUBLIC.has(h.category) : st.filter === 2 ? (h.category === 'OPTIONAL' || h.category === 'REGIONAL') : st.filter === 3 ? (h.category === 'OBSERVANCE' || h.category === 'WORKING_DAY') : true;
      return f && (!q || h.nameBn.toLowerCase().includes(q) || h.nameEn.toLowerCase().includes(q) || mName(parse(h.date).m).toLowerCase().includes(q));
    });
    let html = `<div class="wrap"><div class="hdr"><button class="iconbtn" data-act="prevY" aria-label="${T.prevY}">‹</button><div class="title"><b>${N(y)}</b><small>${T.holList}</small></div><button class="iconbtn" data-act="nextY" aria-label="${T.nextY}">›</button></div>
      <input id="q" class="search" type="search" placeholder="🔍 ${T.search}" value="${esc(st.q)}" aria-label="${T.search}">
      <div class="chips">${[T.fAll, T.fPub, T.fOpt, T.fObs].map((l, i) => `<button class="chip" aria-pressed="${st.filter === i}" data-filter="${i}">${l}</button>`).join('')}</div>`;
    if (!data) html += `<div class="banner">ℹ️ <span>${esc(T.noData(y))}</span></div>`;
    else html += `<div class="card"><h3>${T.dataStatus}</h3><div>${data.origin === 'bundled' ? T.bundled : T.importedL} · ${N(data.holidays.length)}</div>${data.primarySource ? `<div class="small muted">${T.source}: ${esc(data.primarySource)}</div>` : ''}${data.lastReviewed ? `<div class="small muted">${T.reviewed}: ${esc(data.lastReviewed)}</div>` : ''}<div class="small k-opt">${T.moon}</div></div>`;
    if (data && !list.length) html += `<p class="muted">${T.noRes}</p>`;
    let lastM = 0;
    list.forEach((h) => { const m = parse(h.date).m; if (m !== lastM) { html += `<div class="mhead">${mName(m)}</div>`; lastM = m; } html += holidayRow(h, { past: h.date < today }); });
    $('view').innerHTML = html + '</div>';
    const qi = $('q'); qi.addEventListener('input', () => { st.q = qi.value; const pos = qi.selectionStart; renderHolidays(); const n = $('q'); n.focus(); try { n.setSelectionRange(pos, pos); } catch (e) {} });
  }
  function choice(name, opts, cur) {
    return `<div class="chips" role="radiogroup">${opts.map(([v, l]) => `<button class="chip" role="radio" aria-pressed="${String(v) === String(cur)}" aria-checked="${String(v) === String(cur)}" data-set="${name}" data-val="${v}">${esc(l)}</button>`).join('')}</div>`;
  }
  function renderSettings() {
    const years = Object.values(DB).sort((a, b) => a.year - b.year);
    $('view').innerHTML = `<div class="wrap"><h2 style="margin:6px 4px">${T.settings}</h2>
      <div class="card">
        <div class="setrow"><span class="lbl">${T.language}</span>${choice('lang', [['bn', 'বাংলা'], ['en', 'English']], settings.lang)}</div>
        <div class="setrow"><span class="lbl">${T.theme}</span>${choice('theme', [['system', T.tSys], ['light', T.tLight], ['dark', T.tDark]], settings.theme)}</div>
        <div class="setrow"><span class="lbl">${T.weekStart}</span>${choice('weekStart', [[0, T.wd[0]], [6, T.wd[6]], [1, T.wd[1]]], settings.weekStart)}</div>
        <label class="switch"><span>${T.showBangla}</span><input type="checkbox" id="showBangla" ${settings.showBangla ? 'checked' : ''}></label>
        <label class="switch"><span>${T.showIslamic}</span><input type="checkbox" id="showIslamic" ${settings.showIslamic ? 'checked' : ''}></label>
        <div class="setrow"><span class="lbl">${T.hjAdj}</span>${choice('hijriShift', [[-2, T.hjOpt[0]], [-1, T.hjOpt[1]], [0, T.hjOpt[2]], [1, T.hjOpt[3]]], settings.hijriShift)}<div class="small muted">${T.hjInfo}</div></div>
        <div class="setrow"><span class="lbl">${T.tz}</span>${choice('deviceZone', [['false', T.tzDhaka], ['true', T.tzDevice]], settings.deviceZone)}</div>
      </div>
      <div class="card"><h3>${T.holData}</h3>
        ${years.map((y) => `<div class="row"><div style="flex:1"><b>${N(y.year)}</b> · ${N(y.holidays.length)}<div class="small muted">${y.origin === 'bundled' ? T.bundled : T.importedL}${y.lastReviewed ? ' · ' + T.reviewed + ': ' + esc(y.lastReviewed) : ''}</div></div>${y.origin === 'imported' ? `<button class="textbtn" data-rmimp="${y.year}">${T.removeImp}</button>` : ''}</div>`).join('')}
        <p class="small muted">${T.importInfo}</p>
        <label class="btn tonal" style="display:inline-block">${T.importBtn}<input type="file" id="impfile" accept=".json,application/json,text/plain" hidden></label>
      </div>
      <div class="card"><h3>${T.backup}</h3><div class="actions" style="justify-content:flex-start"><button class="btn tonal" data-act="exportEv">${T.exportEv}</button>
        <label class="btn tonal">${T.importEv}<input type="file" id="evfile" accept=".json,application/json" hidden></label></div></div>
      <div class="card"><h3>${T.about}</h3><p style="margin:0">${T.aboutText}</p><p class="small muted">v1.3.0 · com.t.calendar</p></div></div>`;
    $('showBangla').addEventListener('change', (e) => { settings.showBangla = e.target.checked; saveSettings(); });
    $('showIslamic').addEventListener('change', (e) => { settings.showIslamic = e.target.checked; saveSettings(); });
    $('impfile').addEventListener('change', (e) => readFile(e.target.files[0], (txt) => {
      try { const o = JSON.parse(txt); const y = validateYear(o); imported[y.year] = o; LS.set('imported', imported); buildDB(); toast(T.importOk(y.year, y.holidays.length)); render(); }
      catch (err) { toast(T.importFail(err.message)); }
    }));
    $('evfile').addEventListener('change', (e) => readFile(e.target.files[0], (txt) => {
      try { const arr = JSON.parse(txt); if (!Array.isArray(arr)) throw new Error('not a list');
        const ok = arr.filter((x) => x && typeof x.title === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(x.date || ''));
        const ids = new Set(events.map((x) => x.id)); ok.forEach((x) => { if (!ids.has(x.id)) events.push({ id: x.id || uid(), title: x.title, desc: x.desc || '', date: x.date, allDay: x.allDay !== false, time: x.time || null }); });
        LS.set('events', events); toast(T.evRestored(ok.length)); render(); } catch (err) { toast(T.importFail(err.message)); }
    }));
  }
  function readFile(f, cb) { if (!f) return; if (f.size > 2e6) { toast(T.importFail('file too large')); return; } const r = new FileReader(); r.onload = () => cb(String(r.result)); r.readAsText(f, 'utf-8'); }
  const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);

  function render() {
    renderTabs();
    [renderMonth, renderYear, renderHolidays, renderSettings][st.tab]();
    if (!$('sheet').hidden) openSheet(st.sheetDate, true);
  }

  // ---------- Bottom sheet: date details ----------
  function openSheet(s, refresh) {
    st.sheetDate = s; const c = classify(s), evs = events.filter((e) => e.date === s);
    const recs = c.recs.map((h) => `<div class="rec"><div class="nm">${esc(hName(h))}</div><div class="${kindClass(h)} small">${esc(catLine(h))}</div>
      ${h.moonDependent ? `<div class="small muted">${T.moon}</div>` : ''}${h.verification !== 'VERIFIED' ? `<div class="small k-opt">${T.ver[h.verification]}</div>` : ''}
      ${h.notes ? `<div class="small muted">${esc(h.notes)}</div>` : ''}${h.source ? `<div class="small muted">${T.source}: ${esc(h.source)}</div>` : ''}
      ${h.sourceUrl ? `<a href="${esc(h.sourceUrl)}" target="_blank" rel="noopener">${esc(h.sourceUrl.replace(/^https?:\/\//, '').split('/')[0])}</a>` : ''}</div>`).join('');
    $('sheet').innerHTML = `<div class="grab"></div><div style="display:flex;align-items:start"><div style="flex:1"><h2 class="${c.color === 'red' ? 'c-red' : c.color === 'green' ? 'c-green' : ''}">${fullDate(s)}</h2>
      <div style="color:var(--bn)">${banglaDate(s)}</div>${settings.showIslamic ? `<div style="color:var(--hj)">${islamicDate(s)}</div>` : ''}${s === today ? `<div style="color:var(--ring);font-weight:600">${T.today}</div>` : ''}</div><button class="iconbtn" data-act="closeSheet" aria-label="${T.close}">✕</button></div>
      <div style="margin-top:10px">${c.weekly ? `<div class="c-red">● ${T.weekly}</div>` : c.pub.length ? '' : `<div class="muted">● ${T.working}</div>`}</div>
      ${hasYear(parse(s).y) ? '' : `<div class="banner">ℹ️ <span>${esc(T.noData(parse(s).y))}</span></div>`}${recs}
      <div style="display:flex;align-items:center;margin-top:18px"><h3 style="flex:1;margin:0">${T.events}</h3><button class="btn" data-act="addSheet">＋ ${T.addEvent}</button></div>
      ${evs.length ? evs.map((e) => `<div class="evrow"><div class="t"><div style="font-weight:500">${esc(e.title)}</div><div class="small muted">${e.allDay ? T.allDay : fmtTime(e.time)}</div>${e.desc ? `<div class="small">${esc(e.desc)}</div>` : ''}</div>
        <button class="iconbtn" data-edit="${e.id}" aria-label="${T.edit}">✎</button><button class="iconbtn" data-del="${e.id}" aria-label="${T.del}">🗑</button></div>`).join('') : `<p class="muted">${T.noEvents}</p>`}`;
    $('sheet').hidden = false; $('sheet-backdrop').hidden = false;
    if (!refresh) $('sheet').scrollTop = 0;
  }
  function closeSheet() { $('sheet').hidden = true; $('sheet-backdrop').hidden = true; }

  // ---------- Modal dialogs ----------
  function openModal(html) { $('modal').innerHTML = html; $('modal').hidden = false; $('modal-backdrop').hidden = false; const f = $('modal').querySelector('input,button'); if (f) f.focus(); }
  function closeModal() { $('modal').hidden = true; $('modal-backdrop').hidden = true; }
  function openEditor(date, ev) {
    openModal(`<h2>${ev ? T.editEvent : T.addEvent}</h2>
      <label class="field" id="f-title"><span>${T.title}</span><input id="e-title" value="${esc(ev ? ev.title : '')}" maxlength="200"></label>
      <label class="field"><span>${T.desc}</span><textarea id="e-desc" rows="2">${esc(ev ? ev.desc : '')}</textarea></label>
      <label class="field"><span>${T.date}</span><input id="e-date" type="date" min="1900-01-01" max="2299-12-31" value="${ev ? ev.date : date}"></label>
      <label class="switch"><span>${T.allDay}</span><input type="checkbox" id="e-allday" ${!ev || ev.allDay ? 'checked' : ''}></label>
      <label class="field" id="f-time" ${!ev || ev.allDay ? 'hidden' : ''}><span>${T.time}</span><input id="e-time" type="time" value="${ev && ev.time ? ev.time : '09:00'}"></label>
      <div class="actions"><button class="textbtn" data-act="closeModal">${T.cancel}</button><button class="btn" id="e-save">${T.save}</button></div>`);
    $('e-allday').addEventListener('change', (e) => { $('f-time').hidden = e.target.checked; });
    $('e-save').addEventListener('click', () => {
      const title = $('e-title').value.trim(); const d = $('e-date').value;
      if (!title) { $('f-title').classList.add('err'); $('f-title').querySelector('span').textContent = T.titleReq; return; }
      if (!/^\d{4}-\d{2}-\d{2}$/.test(d)) return;
      const allDay = $('e-allday').checked; const rec = { id: ev ? ev.id : uid(), title, desc: $('e-desc').value.trim(), date: d, allDay, time: allDay ? null : ($('e-time').value || '09:00') };
      events = events.filter((x) => x.id !== rec.id).concat([rec]).sort((a, b) => (a.date + (a.time || '')).localeCompare(b.date + (b.time || '')));
      LS.set('events', events); closeModal(); st.sel = d; const p = parse(d); st.y = p.y; st.m = p.m; render(); openSheet(d);
    });
  }
  function confirmDelete(id) {
    const e = events.find((x) => x.id === id); if (!e) return;
    openModal(`<h2>${T.delConfirm}</h2><p>${esc(e.title)}</p><div class="actions"><button class="textbtn" data-act="closeModal">${T.cancel}</button><button class="btn danger" id="d-ok">${T.del}</button></div>`);
    $('d-ok').addEventListener('click', () => { events = events.filter((x) => x.id !== id); LS.set('events', events); closeModal(); render(); });
  }
  function openJump() {
    let jm = st.m;
    openModal(`<h2>${T.jump}</h2>
      <div style="display:flex;align-items:center;gap:6px"><button class="iconbtn" id="j-minus">−</button><label class="field" style="flex:1;margin:0"><span>${T.year} (${N(MIN_Y)}–${N(MAX_Y)})</span><input id="j-year" type="number" inputmode="numeric" min="${MIN_Y}" max="${MAX_Y}" value="${st.y}"></label><button class="iconbtn" id="j-plus">+</button></div>
      <div class="monthpick" style="margin-top:12px">${T.months.map((n, i) => `<button class="chip" data-jm="${i + 1}" aria-pressed="${i + 1 === jm}">${bn() ? n : n.slice(0, 3)}</button>`).join('')}</div>
      <label class="field"><span>${T.exact}</span><input id="j-date" type="date" min="1900-01-01" max="2299-12-31"></label>
      <div class="actions"><button class="textbtn" data-act="closeModal">${T.cancel}</button><button class="btn" id="j-go">${T.go}</button></div>`);
    const yi = $('j-year');
    $('j-minus').onclick = () => { yi.value = Math.max(MIN_Y, (+yi.value || st.y) - 1); };
    $('j-plus').onclick = () => { yi.value = Math.min(MAX_Y, (+yi.value || st.y) + 1); };
    $('modal').querySelectorAll('[data-jm]').forEach((b) => b.addEventListener('click', () => { jm = +b.dataset.jm; $('modal').querySelectorAll('[data-jm]').forEach((x) => x.setAttribute('aria-pressed', String(+x.dataset.jm === jm))); }));
    $('j-go').onclick = () => {
      const ex = $('j-date').value;
      if (ex) { closeModal(); goTo(ex, true); return; }
      const y = parseInt(yi.value, 10); if (!(y >= MIN_Y && y <= MAX_Y)) { yi.focus(); return; }
      closeModal(); goTo(iso(y, jm, 1), false);
    };
  }
  function goTo(s, open) {
    const p = parse(s); if (p.y < MIN_Y || p.y > MAX_Y) return;
    st.y = p.y; st.m = p.m; st.sel = s; st.year = p.y; st.tab = 0; render(); if (open) openSheet(s);
  }
  function shiftMonth(n) {
    let m = st.m + n, y = st.y; while (m < 1) { m += 12; y--; } while (m > 12) { m -= 12; y++; }
    if (y < MIN_Y || y > MAX_Y) return; st.y = y; st.m = m; render();
  }
  function attachSwipe(el) {
    if (!el) return; let x0 = null, y0 = null;
    el.addEventListener('touchstart', (e) => { x0 = e.touches[0].clientX; y0 = e.touches[0].clientY; }, { passive: true });
    el.addEventListener('touchend', (e) => {
      if (x0 == null) return; const dx = e.changedTouches[0].clientX - x0, dy = e.changedTouches[0].clientY - y0; x0 = null;
      if (Math.abs(dx) > 60 && Math.abs(dx) > Math.abs(dy) * 1.5) { st._swiped = Date.now(); shiftMonth(dx < 0 ? 1 : -1); }
    }, { passive: true });
  }

  // ---------- Events (delegated) ----------
  document.addEventListener('click', (e) => {
    const t = e.target.closest('button, [data-act]'); if (!t) return;
    const d = t.dataset;
    if (d.tab != null) {
      const t = +d.tab;
      if (t === 1 || t === 2) st.year = st.y; // year/holiday views follow the month being viewed (bugfix)
      else if (t === 0) st.y = st.year;       // month view follows the year being viewed (bugfix)
      st.tab = t; closeSheet(); render(); $('view').scrollTop = 0; return;
    }
    if (d.date) { if (st._swiped && Date.now() - st._swiped < 400) return; st.sel = d.date; render(); openSheet(d.date); return; }
    if (d.open) { goTo(d.open, true); return; }
    if (d.month) { st.y = st.year; st.m = +d.month; st.tab = 0; render(); return; }
    if (d.filter != null) { st.filter = +d.filter; renderHolidays(); return; }
    if (d.set) { const v = d.val; settings[d.set] = (d.set === 'weekStart' || d.set === 'hijriShift') ? +v : d.set === 'deviceZone' ? v === 'true' : v; saveSettings(); return; }
    if (d.rmimp) { delete imported[d.rmimp]; LS.set('imported', imported); buildDB(); render(); return; }
    if (d.edit) { const ev = events.find((x) => x.id === d.edit); if (ev) openEditor(ev.date, ev); return; }
    if (d.del) { confirmDelete(d.del); return; }
    switch (d.act) {
      case 'toggleHol': { const v = $('view'), top = v.scrollTop; st.holOpen = !st.holOpen; renderMonth(); v.scrollTop = top; break; }
      case 'prevM': shiftMonth(-1); break;
      case 'nextM': shiftMonth(1); break;
      case 'today': goTo(today, false); break;
      case 'jump': openJump(); break;
      case 'details': openSheet(st.sel); break;
      case 'add': openEditor(st.sel); break;
      case 'addSheet': openEditor(st.sheetDate); break;
      case 'closeSheet': closeSheet(); break;
      case 'closeModal': closeModal(); break;
      case 'prevY': if (st.year > MIN_Y) { st.year--; render(); } break;
      case 'nextY': if (st.year < MAX_Y) { st.year++; render(); } break;
      case 'exportEv': exportEvents(); break;
    }
  });
  $('sheet-backdrop').addEventListener('click', closeSheet);
  $('modal-backdrop').addEventListener('click', closeModal);
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { if (!$('modal').hidden) closeModal(); else if (!$('sheet').hidden) closeSheet(); }
    if ($('modal').hidden && $('sheet').hidden && st.tab === 0 && !/INPUT|TEXTAREA/.test(document.activeElement.tagName)) {
      if (e.key === 'ArrowLeft') shiftMonth(-1); if (e.key === 'ArrowRight') shiftMonth(1);
    }
  });
  // Android back button: the WebView wrapper calls this; returns true if something was closed.
  window.BanglaCalendarBack = function () { // called by the Android wrapper; returns true if handled
    if (!$('modal').hidden) { closeModal(); return true; } if (!$('sheet').hidden) { closeSheet(); return true; }
    if (st.tab !== 0) { st.tab = 0; render(); return true; } return false;
  };
  function exportEvents() {
    const json = JSON.stringify(events, null, 1), name = `bangla-calendar-events-${today}.json`;
    if (window.AndroidBridge && AndroidBridge.share) { AndroidBridge.share(name, json); return; } // Android wrapper: share/save sheet
    const blob = new Blob([json], { type: 'application/json' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); a.remove();
  }

  // Keep "today" correct across midnight / time-zone change while the app is open.
  setInterval(() => { const n = todayStr(); if (n !== today) { today = n; render(); } }, 30000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) { const n = todayStr(); if (n !== today) { today = n; render(); } } });
  if (window.matchMedia) matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => { if (settings.theme === 'system') applyTheme(); });

  // Expose pure helpers for tests
  window.BC = { toBangla, toHijri, dow, classify, gridCells, validateYear, on, todayStr, settings: () => settings };

  buildDB(); applyTheme(); render();
})();
