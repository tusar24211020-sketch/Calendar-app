#!/usr/bin/env python3
"""Static consistency checks, NOT Android device tests."""
from pathlib import Path
import re
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]
a = '{http://schemas.android.com/apk/res/android}'
manifest = ET.parse(root / 'android/app/src/main/AndroidManifest.xml').getroot()
app = manifest.find('application')
permissions = {x.get(a+'name') for x in manifest.findall('uses-permission')}
assert 'android.permission.RECEIVE_BOOT_COMPLETED' in permissions
assert 'android.permission.SCHEDULE_EXACT_ALARM' in permissions
assert 'android.permission.USE_EXACT_ALARM' not in permissions
aliases = {x.get(a+'name'): x for x in app.findall('activity-alias')}
assert len(aliases) == 218
assert sum(x.get(a+'enabled') == 'true' for x in aliases.values()) == 1
assert aliases['.AliasDefault'].get(a+'enabled') == 'true'
resources = root/'android/app/src/main/res'
for w in range(7):
    for d in range(1,32):
        x = aliases[f'.Alias{w}_{d:02}']
        assert x.get(a+'targetActivity') == '.MainActivity'
        assert x.get(a+'enabled') == 'false'
        for prop in ['icon','roundIcon']:
            resource = x.get(a+prop).split('/')[-1]
            assert list(resources.glob(f'mipmap*/{resource}.*')), resource
receiver = app.find('receiver')
assert receiver.get(a+'exported') == 'false'
assert receiver.get(a+'directBootAware') == 'true'
actions = {x.get(a+'name') for x in receiver.findall('intent-filter/action')}
assert {'android.intent.action.BOOT_COMPLETED','android.intent.action.LOCKED_BOOT_COMPLETED',
        'android.intent.action.DATE_CHANGED','android.intent.action.TIME_SET',
        'android.intent.action.TIMEZONE_CHANGED','android.intent.action.MY_PACKAGE_REPLACED',
        'android.app.action.SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED'} <= actions
native = root/'android/app/src/main/java/com/t/calendar'
code = (native/'DateIcon.java').read_text()
assert 'setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, midnight, primary)' in code
assert 'alarm(c, ACTION_TICK, 0)' in code and 'alarm(c, ACTION_WATCHDOG, 1)' in code
assert 'createDeviceProtectedStorageContext()' in code
assert 'setComponentEnabledSettings(changes)' in code
assert 'catch (Throwable ignored)' not in code
assert 'next.set(Calendar.SECOND, 0)' in (native/'DateRules.java').read_text()
activity = (native/'MainActivity.java').read_text()
assert 'unregisterReceiver(foregroundDateReceiver)' in activity
assert 'DateReceiver.refreshAsync(this, "activity_resume"' in activity
for xml in resources.glob('**/*.xml'):
    ET.parse(xml)
js=(root/'www/app.js').read_text()
assert 'v1.10.0' in js and "case 'iconSetup':" in js
print('PASS: 218 launcher aliases, 434 date icon references, receiver, permissions, alarms, XML and bridge contracts')
