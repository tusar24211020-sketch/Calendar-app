"""Create the single-file interactive preview using local app assets."""
from pathlib import Path
import base64
root=Path(__file__).resolve().parents[1]
html=(root/'www/index.html').read_text()
for name in ['style.css','glass.css']:
 css=(root/'www'/name).read_text().replace('url("NotoSansBengali.ttf")','url("data:font/ttf;base64,'+base64.b64encode((root/'www/NotoSansBengali.ttf').read_bytes()).decode()+'")')
 html=html.replace(f'<link rel="stylesheet" href="{name}">','<style>'+css+'</style>')
for name in ['holidays.js','app.js']:
 html=html.replace(f'<script src="{name}"></script>','<script>'+(root/'www'/name).read_text().replace('</script','<\\/script')+'</script>')
for line in ['<link rel="manifest" href="manifest.json">','<link rel="icon" href="icon-192.png">']:html=html.replace(line,'')
html=html.replace("theme: 'system', weekStart", "theme: 'dark', weekStart")
(root/'Calendar-preview.html').write_text(html)
