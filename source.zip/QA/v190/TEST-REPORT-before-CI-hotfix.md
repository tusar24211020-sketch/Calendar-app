# Calendar 1.9.0 — verification report

## Delivered feature
The Holidays dock tab contains a full calendar and the same month’s holiday list.
Phone layouts stack them; desktop layouts place them side by side. Tapping a date
shows its holiday names, categories and details, without leaving Holidays.
Month arrows, the month picker and Today keep calendar/list state synchronized.
Existing soft-glass themes, device-local date policy and midnight alarm fixes remain.
No holiday source data was invented or replaced; unavailable years show a warning.

## Bug fixes
- Monthly holiday-row details no longer switch away to the Month tab.
- Monthly search/filter updates only its results, preserving the live search field.
- Active holiday search survives midnight, month-end and New Year calendar updates.
- Closing date details restores keyboard focus to the selected calendar date.
- Browsing another month does not invent a first-day selection in the summary.
- Imported event IDs are escaped in edit/delete attributes, preventing HTML injection.

## Automated results on this delivery
**836 browser checks passed**, no reported JavaScript page errors:
- clock-glass: 52
- header: 144
- holiday-calendar: 329
- interaction: 27
- midnight-setup: 8
- navigation-glass: 217
- regression: 23
- date-label-layout: 36

Production DateRules.java was compiled to Java 17 bytecode with the available
JDK 25 compiler and run: **2,078,029 date-policy assertions passed**.
This covers all available timezones across 2026–2028, local midnight, weekday/day
aliases, leap/year/DST boundaries and the independent 00:15 recovery deadline.
The JDK emits deprecation warnings for legacy three-letter timezone aliases;
these are warnings in the exhaustive test, not assertion failures.

Static source validation passed (218 launcher aliases, 434 icon references,
permissions, direct-boot storage, resources and bridge contracts). JavaScript
syntax, workflow YAML and its shell-script syntax passed. Original signing files
are unchanged. ZIP integrity and matching bundled/separate YAML were checked.

Visual inspection covered the mobile calendar, selected-day summary, holiday list,
empty search, date-detail sheet and desktop side-by-side layout, in light/dark styles.
Browser checks cover 320, 390, 900 and 1280px holiday layouts in Bengali and English.

Fresh logs: QA/v190/. Fresh browser JSON reports: source root.
QA/v180/ and QA/v170/ contain historical results, not current Android build evidence.

## Not verified
- Full Android Gradle build, Android lint and Robolectric suites were NOT executed
  here. The supplied GitHub workflow runs these plus browser and Java date checks.
- No physical POCO X3 NFC / Android 12 / MIUI 14 midnight test or emulator run.
- The workflow has not been executed in the user’s GitHub account.
- The standalone Java checks do not simulate AlarmManager, PackageManager or a launcher.
- Bundled holiday announcements were not independently revalidated in this update.

Allow Alarms & reminders and MIUI Autostart, retain the app’s battery exemption,
and launch once after installing. Force stop/power-off/OEM restrictions/launcher
caching remain system constraints; there is no guaranteed home-screen crossfade.

VersionName 1.9.0; versionCode 14; application ID com.t.calendar.
Keep this source private because the original signing files remain included.
