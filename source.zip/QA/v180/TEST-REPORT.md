# Calendar 1.8.0 — delivery verification

## Checks performed on this final source
- **507 browser checks passed**, with no reported JavaScript page errors:
  - local clock / midnight / glass regression: 52
  - date-label layout: 36
  - month header: 144
  - interaction / accessibility / boundaries: 27
  - native-bridge setup card simulation: 8
  - navigation / glass / responsive layouts: 217
  - storage, import/export, event, calendar and theme regressions: 23
- Production `DateRules.java` compiled and executed with the available JDK 25:
  **2,078,029 assertions passed** across all available timezones and 2026–2028.
  Includes precise midnight, date/weekday aliases, Dhaka/UTC differences, leap day,
  New Year, 23/25-hour DST days, and preservation of today's 00:15 recovery deadline.
- Static source validation passed: 218 launcher aliases, 434 date icon references,
  XML/resources, permissions, alarm identities, direct-boot storage and bridge wiring.
- JavaScript syntax checks passed; build workflow YAML parsed and run scripts passed
  Bash syntax validation. The pinned browser package was confirmed available.
- Light/dark responsive browser screenshots were generated. Key month, holiday,
  settings, search/error, date details, event editor and desktop states were inspected.
- Original release.keystore and keystore.properties are byte-identical to the input.

Fresh browser JSON results are at source root; fresh execution logs are in QA/v180/.
QA/v170/ contains inherited historical reports, NOT results for this release.

## Important limitations
- **Full Android Gradle build, Android lint and Robolectric tests were not run here**:
  this environment does not have Android SDK 35/JDK 17 configured. Their execution
  remains part of the supplied GitHub Actions workflow, not a claimed local success.
- A standalone date-policy test is NOT an Android AlarmManager/PackageManager test.
- No physical-device/emulator midnight, locked-boot, launcher-cache or OEM-battery
  run was performed. Clock/browser tests do not establish Android background delivery.
- The workflow itself has not been executed in your GitHub account.
- Existing Robolectric tests are retained, updated for the new recovery deadline;
  a new pure policy test covers the midnight-to-00:15 regression.

## Expected behavior and required setup
The primary native alarm targets the PHONE's next local 00:00:00.000 using
`setExactAndAllowWhileIdle` when allowed. Calendar arithmetic handles DST rather
than assuming every civil day is 24 hours. A distinct best-effort recovery alarm
is retained at today's 00:15 when midnight has just passed. Repeated resume/date
broadcasts no longer postpone that recovery to tomorrow. Launcher reconciliation
runs off the UI thread; API 33+ switches aliases atomically, older versions enable
before disabling. Foreground web updates are midnight-aligned and resync on wake,
focus, pageshow and native time/resume signals. Unsaved editors are preserved.

Allow Alarms & reminders on Android 12+. Force stop, power-off, revoked permissions,
OEM background restrictions and launcher caches can prevent/delay visible changes.
The system launcher controls home-screen icon animation; an app cannot force a
smooth crossfade or guarantee a visible zero-latency replacement on every phone.
The in-app phone-date icon has a reduced-motion-aware 220ms transition.

Run the manual device checklist in tests/README.txt before calling it device-verified.
