package com.t.calendar;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.Log;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

/** Exact local-midnight alarm, independent recovery alarm, and launcher alias reconciliation. */
final class DateIcon {
    static final String ACTION_TICK = "com.t.calendar.DATE_TICK"; // retain old PendingIntent identity
    static final String ACTION_WATCHDOG = "com.t.calendar.DATE_WATCHDOG";
    private static final String TAG = "CalendarDateIcon";
    private static final String PKG = "com.t.calendar.";
    private static final long WATCHDOG_DELAY = 15 * 60 * 1000L;
    private static String verifiedAlias;

    private DateIcon() { }

    static SharedPreferences diagnostics(Context context) {
        // Receiver also runs after LOCKED_BOOT_COMPLETED, before credential storage unlocks.
        return context.createDeviceProtectedStorageContext()
                .getSharedPreferences("date_icon_v170", Context.MODE_PRIVATE);
    }

    static boolean canScheduleExact(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        return am != null && (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms());
    }

    static synchronized boolean isCurrent(Context c) {
        String target = DateRules.alias(System.currentTimeMillis(), TimeZone.getDefault());
        return target.equals(verifiedAlias) && c.getPackageManager().getComponentEnabledSetting(
                new ComponentName(c, PKG + target)) == PackageManager.COMPONENT_ENABLED_STATE_ENABLED;
    }

    static synchronized void refresh(Context context, String reason) {
        Context c = context.getApplicationContext();
        // Arm tomorrow FIRST. A launcher failure must never prevent tomorrow's alarm.
        schedule(c);
        try {
            update(c);
            diagnostics(c).edit().putString("last_reason", reason)
                    .putString("icon_error", "").apply();
        } catch (RuntimeException e) {
            verifiedAlias = null; // next recovery/foreground event retries ALL aliases
            Log.e(TAG, "Launcher update failed (" + reason + ")", e);
            diagnostics(c).edit().putString("icon_error", e.toString()).apply();
            // schedule() just moved the normal watchdog to tomorrow. If reconciliation failed,
            // replace it with a near-term retry so today's failure is not left until tomorrow.
            try {
                AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
                if (am != null) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,
                        System.currentTimeMillis() + WATCHDOG_DELAY, alarm(c, ACTION_WATCHDOG, 1));
            } catch (RuntimeException retryError) {
                Log.e(TAG, "Cannot schedule launcher retry", retryError);
            }
        }
    }

    private static void update(Context c) {
        String target = DateRules.alias(System.currentTimeMillis(), TimeZone.getDefault());
        PackageManager pm = c.getPackageManager();
        if (target.equals(verifiedAlias) && pm.getComponentEnabledSetting(new ComponentName(c,
                PKG + target)) == PackageManager.COMPONENT_ENABLED_STATE_ENABLED) return;

        List<ComponentName> disable = new ArrayList<>();
        collectIfEnabled(c, pm, "AliasDefault", true, target, disable);
        for (int w = 0; w < 7; w++) {
            for (int d = 1; d <= 31; d++) {
                collectIfEnabled(c, pm, String.format(Locale.US, "Alias%d_%02d", w, d),
                        false, target, disable);
            }
        }
        ComponentName selected = new ComponentName(c, PKG + target);
        boolean enable = pm.getComponentEnabledSetting(selected)
                != PackageManager.COMPONENT_ENABLED_STATE_ENABLED;
        if (Build.VERSION.SDK_INT >= 33) {
            // Android 13+: atomic batch, no transient two-icon / no-icon intermediate state.
            List<PackageManager.ComponentEnabledSetting> changes = new ArrayList<>();
            if (enable) changes.add(new PackageManager.ComponentEnabledSetting(selected,
                    PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP));
            for (ComponentName cn : disable) changes.add(new PackageManager.ComponentEnabledSetting(cn,
                    PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP));
            if (!changes.isEmpty()) pm.setComponentEnabledSettings(changes);
        } else {
            // Older Android: enable first so interruption never removes the last launcher entry.
            if (enable) pm.setComponentEnabledSetting(selected,
                    PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);
            for (ComponentName cn : disable) pm.setComponentEnabledSetting(cn,
                    PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);
        }
        verifiedAlias = target;
        diagnostics(c).edit().putString("last_alias", target)
                .putLong("last_icon_time", System.currentTimeMillis()).apply();
    }

    private static void collectIfEnabled(Context c, PackageManager pm, String name,
            boolean enabledByDefault, String target, List<ComponentName> disable) {
        if (name.equals(target)) return;
        ComponentName cn = new ComponentName(c, PKG + name);
        int state = pm.getComponentEnabledSetting(cn);
        if (state == PackageManager.COMPONENT_ENABLED_STATE_ENABLED
                || (state == PackageManager.COMPONENT_ENABLED_STATE_DEFAULT && enabledByDefault)) {
            disable.add(cn);
        }
    }

    private static PendingIntent alarm(Context c, String action, int requestCode) {
        Intent i = new Intent(c, DateReceiver.class).setAction(action);
        return PendingIntent.getBroadcast(c, requestCode, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static void schedule(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) {
            diagnostics(c).edit().putString("alarm_error", "AlarmManager unavailable")
                    .putString("alarm_mode", "unavailable").apply();
            return;
        }
        long midnight = DateRules.nextMidnight(System.currentTimeMillis(), TimeZone.getDefault());
        PendingIntent primary = alarm(c, ACTION_TICK, 0);
        String mode = "inexact (permission missing)";
        String error = "";
        boolean armed = false;
        try {
            if (canScheduleExact(c)) {
                // RTC_WAKEUP wakes the CPU; exact+allow-while-idle also works during Doze.
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, midnight, primary);
                mode = "exact";
                armed = true;
            }
        } catch (RuntimeException e) {
            // Includes permission revocation race; do not silently swallow failures.
            Log.w(TAG, "Exact alarm unavailable; trying inexact recovery", e);
            error = e.toString();
        }
        if (!armed) {
            try {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, midnight, primary);
                armed = true;
                mode = "inexact (best effort)";
            } catch (RuntimeException e) {
                Log.e(TAG, "Cannot schedule midnight alarm", e);
                error = error + " " + e;
                mode = "failed";
            }
        }
        // Different PendingIntent: cannot replace the exact alarm. Best effort only; not a
        // promise of 00:15 delivery. Spaced out to avoid aggressive allow-while-idle quotas.
        try {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, midnight + WATCHDOG_DELAY,
                    alarm(c, ACTION_WATCHDOG, 1));
        } catch (RuntimeException e) {
            Log.w(TAG, "Cannot schedule recovery alarm", e);
            error = error + " watchdog: " + e;
        }
        diagnostics(c).edit().putLong("next_alarm", armed ? midnight : 0)
                .putString("alarm_mode", mode).putString("alarm_error", error.trim())
                .putString("timezone", TimeZone.getDefault().getID()).apply();
    }
}
