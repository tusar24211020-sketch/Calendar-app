package com.t.calendar;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import java.util.Calendar;
import java.util.Locale;

/**
 * Launcher icon that shows today's weekday + date.
 * The manifest has one disabled activity-alias per (weekday, date) = 7 x 31, plus AliasDefault.
 * update() enables today's alias and disables every other one.
 */
final class DateIcon {
    private static final String PKG = "com.t.calendar.";
    static final String ACTION_TICK = "com.t.calendar.DATE_TICK";

    private DateIcon() { }

    static void update(Context c) {
        try {
            PackageManager pm = c.getPackageManager();
            Calendar now = Calendar.getInstance();
            int dow = now.get(Calendar.DAY_OF_WEEK) - 1;           // 0 = Sunday
            int day = now.get(Calendar.DAY_OF_MONTH);
            String target = String.format(Locale.US, "Alias%d_%02d", dow, day);

            // 1) enable today's icon first, so there is always a launcher entry
            ComponentName t = new ComponentName(c, PKG + target);
            if (pm.getComponentEnabledSetting(t) != PackageManager.COMPONENT_ENABLED_STATE_ENABLED) {
                pm.setComponentEnabledSetting(t, PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);
            }
            // 2) disable everything else that is currently on
            disableIfOn(pm, c, "AliasDefault", true, target);
            for (int w = 0; w < 7; w++) {
                for (int d = 1; d <= 31; d++) {
                    disableIfOn(pm, c, String.format(Locale.US, "Alias%d_%02d", w, d), false, target);
                }
            }
        } catch (Throwable ignored) { }
    }

    private static void disableIfOn(PackageManager pm, Context c, String name, boolean enabledByDefault, String target) {
        if (name.equals(target)) return;
        ComponentName cn = new ComponentName(c, PKG + name);
        int s = pm.getComponentEnabledSetting(cn);
        boolean on = s == PackageManager.COMPONENT_ENABLED_STATE_ENABLED
                || (s == PackageManager.COMPONENT_ENABLED_STATE_DEFAULT && enabledByDefault);
        if (on) pm.setComponentEnabledSetting(cn, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);
    }

    /** Wakes DateReceiver shortly after the next midnight (backup for the DATE_CHANGED broadcast). */
    static void schedule(Context c) {
        try {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;
            Calendar next = Calendar.getInstance();
            next.add(Calendar.DAY_OF_MONTH, 1);
            next.set(Calendar.HOUR_OF_DAY, 0);
            next.set(Calendar.MINUTE, 0);
            next.set(Calendar.SECOND, 3);
            next.set(Calendar.MILLISECOND, 0);
            Intent i = new Intent(c, DateReceiver.class).setAction(ACTION_TICK);
            PendingIntent pi = PendingIntent.getBroadcast(c, 0, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            am.setAndAllowWhileIdle(AlarmManager.RTC, next.getTimeInMillis(), pi);
        } catch (Throwable ignored) { }
    }
}
