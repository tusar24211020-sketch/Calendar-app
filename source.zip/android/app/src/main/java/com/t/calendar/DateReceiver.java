package com.t.calendar;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Runs on midnight / date or time change / boot / app update and refreshes the date icon. */
public class DateReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent intent) {
        DateIcon.update(c);
        DateIcon.schedule(c);
    }
}
