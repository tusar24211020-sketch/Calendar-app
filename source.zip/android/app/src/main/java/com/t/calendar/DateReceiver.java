package com.t.calendar;

import android.app.AlarmManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.os.Build;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** System recovery broadcasts plus explicit private alarm callbacks; never starts an Activity. */
public class DateReceiver extends BroadcastReceiver {
    private static final ExecutorService WORKER = Executors.newSingleThreadExecutor();

    @Override
    public void onReceive(Context c, Intent intent) {
        if (intent == null || intent.getAction() == null) return;
        String action = intent.getAction();
        if (!supported(action)) return;
        final PendingResult pending = goAsync();
        Context app = c.getApplicationContext();
        WORKER.execute(() -> {
            try {
                // TIME_TICK is registered dynamically ONLY while the Activity is visible.
                if (!Intent.ACTION_TIME_TICK.equals(action) || !DateIcon.isCurrent(app)) {
                    DateIcon.refresh(app, action);
                }
            } catch (RuntimeException e) {
                Log.e("CalendarDateIcon", "Receiver failed: " + action, e);
            } finally {
                pending.finish();
            }
        });
    }

    private static boolean supported(String action) {
        return DateIcon.ACTION_TICK.equals(action) || DateIcon.ACTION_WATCHDOG.equals(action)
                || Intent.ACTION_BOOT_COMPLETED.equals(action)
                || Intent.ACTION_LOCKED_BOOT_COMPLETED.equals(action)
                || Intent.ACTION_DATE_CHANGED.equals(action)
                || Intent.ACTION_TIME_CHANGED.equals(action)
                || Intent.ACTION_TIMEZONE_CHANGED.equals(action)
                || Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)
                || Intent.ACTION_TIME_TICK.equals(action) || Intent.ACTION_USER_PRESENT.equals(action)
                || (Build.VERSION.SDK_INT >= 31
                    && AlarmManager.ACTION_SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED.equals(action));
    }
}
