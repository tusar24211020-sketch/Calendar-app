package com.t.calendar;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import android.window.OnBackInvokedDispatcher;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/** Offline wrapper: shows assets/www/index.html (the HTML calendar) in a WebView. No internet permission. */
public class MainActivity extends Activity {
    private static final int FILE_REQ = 7;
    private WebView web;
    private FrameLayout container;
    private Boolean pageDarkTheme;
    private ValueCallback<Uri[]> fileCallback;
    private final DateReceiver foregroundDateReceiver = new DateReceiver();
    private boolean dateReceiverRegistered;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        if (Build.VERSION.SDK_INT >= 30) getWindow().setDecorFitsSystemWindows(false);
        web = new WebView(this);
        web.setBackgroundColor(isNight() ? 0xFF121316 : 0xFFFAFAF7);
        container = new FrameLayout(this);
        container.addView(web, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(container);
        // Target SDK 35 enforces edge-to-edge. Keep the WebView/dock clear of system bars and IME.
        container.setOnApplyWindowInsetsListener((view, insets) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets safe = insets.getInsets(
                        WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout() | WindowInsets.Type.ime());
                view.setPadding(safe.left, safe.top, safe.right, safe.bottom);
            } else {
                view.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(),
                        insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
            }
            return insets;
        });
        container.requestApplyInsets();
        styleBars();
        // Android 13+ gesture/button Back uses the same in-app navigation as older phones.
        if (Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    OnBackInvokedDispatcher.PRIORITY_DEFAULT, this::handleBack);
        }

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);          // localStorage keeps settings, events and imported holidays
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setTextZoom(100);
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                if ("file".equals(u.getScheme())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (ActivityNotFoundException ignored) { }
                return true; // source links open in the browser
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*");
                try { startActivityForResult(Intent.createChooser(i, null), FILE_REQ); } catch (ActivityNotFoundException e) { fileCallback.onReceiveValue(null); fileCallback = null; return true; }
                return true;
            }
        });
        if (state != null) {
            web.restoreState(state);
            // Bugfix: restoreState() restores the history list but not the page itself,
            // which could leave a blank screen after process death — reload if needed.
            String u = web.getUrl();
            if (u == null || !u.startsWith("file:")) web.loadUrl("file:///android_asset/www/index.html");
            else web.reload();
        } else web.loadUrl("file:///android_asset/www/index.html");
    }

    private boolean isNight() {
        return (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
    }

    private void styleBars() { styleBars(pageDarkTheme != null ? pageDarkTheme : isNight()); }

    private void styleBars(boolean night) {
        Window w = getWindow();
        w.setStatusBarColor(night ? 0xFF121316 : 0xFFFAFAF7);
        w.setNavigationBarColor(night || Build.VERSION.SDK_INT < 26 ? 0xFF121316 : 0xFFFAFAF7);
        if (web != null) web.setBackgroundColor(night ? 0xFF121316 : 0xFFFAFAF7);
        if (container != null) container.setBackgroundColor(night ? 0xFF121316 : 0xFFFAFAF7);
        if (Build.VERSION.SDK_INT >= 30) {
            android.view.WindowInsetsController controller = w.getInsetsController();
            if (controller != null) {
                int mask = android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                        | android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
                controller.setSystemBarsAppearance(night ? 0 : mask, mask);
            }
        } else if (Build.VERSION.SDK_INT >= 26) {
            int f = night ? 0 : (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
            w.getDecorView().setSystemUiVisibility(f);
        } else {
            // minSdk 24: status-bar dark icons work, navigation-bar dark icons do not.
            w.getDecorView().setSystemUiVisibility(night ? 0 : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
    }

    @Override
    public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        styleBars();
        if (web != null) web.evaluateJavascript("window.BC && window.BC.applyTheme()", null);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == FILE_REQ && fileCallback != null) {
            Uri[] r = (res == RESULT_OK && data != null && data.getData() != null) ? new Uri[]{data.getData()} : null;
            fileCallback.onReceiveValue(r);
            fileCallback = null;
            return;
        }
        super.onActivityResult(req, res, data);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() { handleBack(); }

    private boolean backPending;
    private void handleBack() {
        if (backPending || isFinishing()) return;
        if (web == null) { finish(); return; }
        backPending = true;
        web.evaluateJavascript("window.BanglaCalendarBack ? window.BanglaCalendarBack() : false", v -> {
            backPending = false;
            if (!"true".equals(v)) finish();
        });
    }

    @Override
    protected void onSaveInstanceState(Bundle out) { super.onSaveInstanceState(out); web.saveState(out); }

    @Override
    protected void onStart() {
        super.onStart();
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_DATE_CHANGED);
        filter.addAction(Intent.ACTION_TIME_CHANGED);
        filter.addAction(Intent.ACTION_TIMEZONE_CHANGED);
        filter.addAction(Intent.ACTION_TIME_TICK);
        filter.addAction(Intent.ACTION_USER_PRESENT);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(foregroundDateReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(foregroundDateReceiver, filter);
        }
        dateReceiverRegistered = true;
    }

    @Override
    protected void onStop() {
        if (dateReceiverRegistered) {
            unregisterReceiver(foregroundDateReceiver);
            dateReceiverRegistered = false;
        }
        super.onStop();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
        DateIcon.refresh(this, "activity_resume");
        web.post(() -> IconSetup.explainOnce(this));
    }

    @Override
    protected void onPause() { web.onPause(); super.onPause(); }

    @Override
    protected void onDestroy() {
        if (fileCallback != null) { fileCallback.onReceiveValue(null); fileCallback = null; }
        if (web != null) {
            web.removeJavascriptInterface("AndroidBridge");
            if (container != null) container.removeView(web);
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }

    /** Lets the page hand the event backup to Android's share sheet (Save to Files / Drive / etc.). */
    private class Bridge {
        @JavascriptInterface
        public void iconSetup() {
            runOnUiThread(() -> {
                DateIcon.refresh(MainActivity.this, "manual_setup");
                IconSetup.show(MainActivity.this);
            });
        }

        @JavascriptInterface
        public void setTheme(boolean dark) {
            runOnUiThread(() -> { pageDarkTheme = dark; styleBars(dark); });
        }

        @JavascriptInterface
        public void share(String name, String text) {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_SEND).setType("application/json")
                        .putExtra(Intent.EXTRA_SUBJECT, name).putExtra(Intent.EXTRA_TITLE, name).putExtra(Intent.EXTRA_TEXT, text);
                try { startActivity(Intent.createChooser(i, name)); } catch (ActivityNotFoundException ignored) { }
            });
        }
    }
}
