package com.t.calendar;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;
import java.text.DateFormat;
import java.util.Date;

/** User-controlled exact-alarm setup and honest, inspectable scheduling diagnostics. */
final class IconSetup {
    private IconSetup() { }

    static void explainOnce(Activity activity) {
        if (Build.VERSION.SDK_INT < 31 || DateIcon.canScheduleExact(activity)) return;
        SharedPreferences p = activity.getPreferences(Context.MODE_PRIVATE);
        if (p.getBoolean("midnight_setup_explained_v180", false)) return;
        p.edit().putBoolean("midnight_setup_explained_v180", true).apply();
        show(activity);
    }

    static void show(Activity activity) {
        if (activity.isFinishing() || activity.isDestroyed()) return;
        boolean allowed = DateIcon.canScheduleExact(activity);
        SharedPreferences p = DateIcon.diagnostics(activity);
        PowerManager power = (PowerManager) activity.getSystemService(Context.POWER_SERVICE);
        String battery = power != null && power.isIgnoringBatteryOptimizations(activity.getPackageName())
                ? "Unrestricted / exempt" : "Optimized (OEM restrictions may apply)";
        String message = "রাত ১২টার আইকন আপডেট / Midnight icon update\n\n"
                + "Exact alarms: " + (allowed ? "Allowed" : "Not allowed — অনুমতি দিন")
                + "\nAlarm mode: " + p.getString("alarm_mode", "not scheduled")
                + "\nNext alarm: " + date(p.getLong("next_alarm", 0))
                + "\nBackup alarm: " + date(p.getLong("next_recovery", 0))
                + "\nPhone timezone: " + p.getString("timezone", "unknown")
                + "\nLast icon reconciliation: " + date(p.getLong("last_icon_time", 0))
                + "\nAlias: " + p.getString("last_alias", "unknown")
                + "\nBattery: " + battery
                + "\n\nআইকন ফোনের স্থানীয় সময় অনুযায়ী বদলায়। অ্যালার্ম অনুমতি দিন। প্রয়োজনে App info → Battery → Unrestricted এবং ফোনের Auto-start অনুমতি চালু করুন।"
                + "\n\nForce stop বা ফোন বন্ধ থাকলে কাজ করবে না। Launcher cache-এর কারণে ছবিটি কিছু দেরিতে দেখা যেতে পারে; কোনো অ্যাপ সব ফোনে দৃশ্যমান পরিবর্তনের সেকেন্ড-নির্ভুল গ্যারান্টি দিতে পারে না।";
        String errors = p.getString("alarm_error", "") + " " + p.getString("icon_error", "");
        if (!errors.trim().isEmpty()) message += "\n\nLast error: " + errors.trim();
        AlertDialog.Builder dialog = new AlertDialog.Builder(activity)
                .setTitle("আইকন আপডেট সেটআপ · v1.9.0").setMessage(message)
                .setNeutralButton("ব্যাটারি / App info", (d, which) -> open(activity,
                        new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.parse("package:" + activity.getPackageName()))));
        if (!allowed && Build.VERSION.SDK_INT >= 31) {
            dialog.setPositiveButton("অ্যালার্ম অনুমতি দিন", (d, which) -> open(activity,
                    new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                            Uri.parse("package:" + activity.getPackageName()))));
            dialog.setNegativeButton("পরে", null);
        } else {
            dialog.setPositiveButton("ঠিক আছে", null);
        }
        dialog.show();
    }

    private static String date(long millis) {
        return millis == 0 ? "not recorded" : DateFormat.getDateTimeInstance().format(new Date(millis));
    }

    private static void open(Activity activity, Intent intent) {
        try {
            activity.startActivity(intent);
        } catch (ActivityNotFoundException | SecurityException e) {
            new AlertDialog.Builder(activity).setTitle("Settings unavailable")
                    .setMessage("ফোনের Settings → Apps → Calendar থেকে অনুমতি ও Battery settings খুলুন।")
                    .setPositiveButton("ঠিক আছে", null).show();
        }
    }
}
