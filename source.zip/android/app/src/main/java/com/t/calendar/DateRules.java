package com.t.calendar;

import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;

/** Pure Java date policy. Launcher dates deliberately follow the PHONE's local timezone. */
final class DateRules {
    private DateRules() { }

    static String alias(long nowMillis, TimeZone zone) {
        Calendar now = Calendar.getInstance(zone, Locale.US);
        now.setTimeInMillis(nowMillis);
        return String.format(Locale.US, "Alias%d_%02d",
                now.get(Calendar.DAY_OF_WEEK) - Calendar.SUNDAY, now.get(Calendar.DAY_OF_MONTH));
    }

    /** Independent recovery still runs TODAY after the midnight alarm has fired. */
    static long nextRecovery(long nowMillis, TimeZone zone) {
        Calendar today = Calendar.getInstance(zone, Locale.US);
        today.setTimeInMillis(nowMillis);
        today.set(Calendar.HOUR_OF_DAY, 0);
        today.set(Calendar.MINUTE, 0);
        today.set(Calendar.SECOND, 0);
        today.set(Calendar.MILLISECOND, 0);
        long recovery = today.getTimeInMillis() + 15 * 60 * 1000L;
        return recovery > nowMillis ? recovery : nextMidnight(nowMillis, zone) + 15 * 60 * 1000L;
    }

    static long nextMidnight(long nowMillis, TimeZone zone) {
        Calendar next = Calendar.getInstance(zone, Locale.US);
        next.setTimeInMillis(nowMillis);
        // Calendar arithmetic, NOT now + 24 hours: handles DST, leap/month/year boundaries.
        next.add(Calendar.DAY_OF_MONTH, 1);
        next.set(Calendar.HOUR_OF_DAY, 0);
        next.set(Calendar.MINUTE, 0);
        next.set(Calendar.SECOND, 0);
        next.set(Calendar.MILLISECOND, 0);
        // Lenient Calendar resolves a nonexistent midnight to the first valid local time.
        return next.getTimeInMillis();
    }
}
