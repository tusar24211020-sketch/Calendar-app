package com.t.calendar;

import android.app.AlarmManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import org.junit.Before;
import org.junit.After;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import org.robolectric.shadows.ShadowAlarmManager;
import org.robolectric.shadows.ShadowAlarmManager.ScheduledAlarm;
import java.util.Locale;
import java.util.TimeZone;
import static org.junit.Assert.*;
import static org.robolectric.Shadows.shadowOf;

/** Framework simulation, not a physical-device/launcher test. */
@RunWith(RobolectricTestRunner.class)
@Config(sdk = 33)
public class DateIconTest {
    private Context app;
    private ShadowAlarmManager alarms;
    private TimeZone originalZone;
    @Before public void setup() {
        app = RuntimeEnvironment.getApplication();
        alarms = shadowOf((AlarmManager) app.getSystemService(Context.ALARM_SERVICE));
        originalZone = TimeZone.getDefault();
        TimeZone.setDefault(TimeZone.getTimeZone("Asia/Dhaka"));
        ShadowAlarmManager.setCanScheduleExactAlarms(true);
    }
    @After public void teardown() { TimeZone.setDefault(originalZone); }
    private ScheduledAlarm alarm(String action) {
        for (ScheduledAlarm a : alarms.getScheduledAlarms()) {
            if (action.equals(shadowOf(a.operation).getSavedIntent().getAction())) return a;
        }
        throw new AssertionError("No alarm: " + action);
    }
    private void onlyTodayEnabled() {
        PackageManager pm = app.getPackageManager();
        String target = DateRules.alias(System.currentTimeMillis(), TimeZone.getDefault());
        assertEquals(PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                pm.getComponentEnabledSetting(new ComponentName(app, "com.t.calendar.AliasDefault")));
        for (int w = 0; w < 7; w++) for (int d = 1; d <= 31; d++) {
            String name = String.format(Locale.US, "Alias%d_%02d", w, d);
            int state = pm.getComponentEnabledSetting(new ComponentName(app, "com.t.calendar." + name));
            assertEquals(name, name.equals(target), state == PackageManager.COMPONENT_ENABLED_STATE_ENABLED);
        }
    }
    @Test public void exactWakeupAtZeroSecondsWithIndependentWatchdog() {
        DateIcon.refresh(app, "test");
        ScheduledAlarm a = alarm(DateIcon.ACTION_TICK), b = alarm(DateIcon.ACTION_WATCHDOG);
        assertEquals(AlarmManager.RTC_WAKEUP, a.type);
        assertEquals(0, a.getWindowLengthMs());
        assertTrue(a.allowWhileIdle);
        assertEquals(DateRules.nextMidnight(System.currentTimeMillis(), TimeZone.getDefault()), a.triggerAtTime);
        assertEquals(DateRules.nextRecovery(System.currentTimeMillis(), TimeZone.getDefault()), b.triggerAtTime);
        assertNotEquals(a.operation, b.operation);
        assertEquals("exact", DateIcon.diagnostics(app).getString("alarm_mode", ""));
        onlyTodayEnabled();
    }
    @Test public void deniedExactPermissionUsesInexactWakeupWithoutCrash() {
        ShadowAlarmManager.setCanScheduleExactAlarms(false);
        assertFalse(DateIcon.canScheduleExact(app));
        DateIcon.refresh(app, "denied");
        assertEquals(ShadowAlarmManager.WINDOW_HEURISTIC, alarm(DateIcon.ACTION_TICK).getWindowLengthMs());
        assertEquals(AlarmManager.RTC_WAKEUP, alarm(DateIcon.ACTION_TICK).type);
        assertTrue(DateIcon.diagnostics(app).getString("alarm_mode", "").startsWith("inexact"));
        onlyTodayEnabled();
    }
    @Test public void permissionGrantUpgradesFallbackAndDoesNotDuplicateAlarms() {
        ShadowAlarmManager.setCanScheduleExactAlarms(false);
        DateIcon.refresh(app, "denied");
        ShadowAlarmManager.setCanScheduleExactAlarms(true);
        DateIcon.refresh(app, "granted");
        DateIcon.refresh(app, "resume");
        assertEquals(2, alarms.getScheduledAlarms().size());
        assertEquals(0, alarm(DateIcon.ACTION_TICK).getWindowLengthMs());
        onlyTodayEnabled();
    }
    @Test public void timezoneChangeRecomputesDeadline() {
        DateIcon.refresh(app, "before_zone");
        long dhaka = alarm(DateIcon.ACTION_TICK).triggerAtTime;
        TimeZone.setDefault(TimeZone.getTimeZone("America/New_York"));
        DateIcon.refresh(app, "timezone_changed");
        assertNotEquals(dhaka, alarm(DateIcon.ACTION_TICK).triggerAtTime);
        assertEquals(DateRules.nextMidnight(System.currentTimeMillis(), TimeZone.getDefault()),
                alarm(DateIcon.ACTION_TICK).triggerAtTime);
        onlyTodayEnabled();
    }
    @Test @Config(sdk = 28) public void olderAndroidEnableFirstPathWorks() {
        DateIcon.refresh(app, "old_android");
        assertTrue(DateIcon.canScheduleExact(app));
        assertEquals(0, alarm(DateIcon.ACTION_TICK).getWindowLengthMs());
        onlyTodayEnabled();
    }
}
