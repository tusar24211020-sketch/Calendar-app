package com.t.calendar;

import org.junit.Test;
import static org.junit.Assert.*;
import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;

public class DateRulesTest {
    private long at(String zone, int year, int month, int day, int h, int m, int s) {
        Calendar c = Calendar.getInstance(TimeZone.getTimeZone(zone), Locale.US);
        c.clear(); c.set(year, month - 1, day, h, m, s);
        return c.getTimeInMillis();
    }
    private void boundary(String zone, int y, int m, int d, int ny, int nm, int nd) {
        long now = at(zone, y, m, d, 23, 59, 59);
        assertEquals(at(zone, ny, nm, nd, 0, 0, 0),
                DateRules.nextMidnight(now, TimeZone.getTimeZone(zone)));
    }
    @Test public void recoverySurvivesMidnightAndRepeatedResume() {
        TimeZone z = TimeZone.getTimeZone("Asia/Dhaka");
        long recovery = at(z.getID(), 2026, 10, 22, 0, 15, 0);
        assertEquals(recovery, DateRules.nextRecovery(at(z.getID(), 2026, 10, 21, 23, 59, 59), z));
        assertEquals(recovery, DateRules.nextRecovery(at(z.getID(), 2026, 10, 22, 0, 0, 0), z));
        assertEquals(recovery, DateRules.nextRecovery(at(z.getID(), 2026, 10, 22, 0, 14, 59), z));
        assertEquals(at(z.getID(), 2026, 10, 23, 0, 15, 0), DateRules.nextRecovery(recovery, z));
    }
    @Test public void dhakaMonthLeapAndYearBoundaries() {
        boundary("Asia/Dhaka", 2026, 10, 17, 2026, 10, 18);
        boundary("Asia/Dhaka", 2026, 12, 31, 2027, 1, 1);
        boundary("Asia/Dhaka", 2028, 2, 28, 2028, 2, 29);
        boundary("Asia/Dhaka", 2028, 2, 29, 2028, 3, 1);
        boundary("Asia/Dhaka", 2027, 2, 28, 2027, 3, 1);
    }
    @Test public void midnightIsNotThreeSecondsLateAndAlwaysFuture() {
        TimeZone z = TimeZone.getTimeZone("Asia/Dhaka");
        long today = at("Asia/Dhaka", 2026, 10, 17, 0, 0, 0);
        assertEquals(today, DateRules.nextMidnight(today - 1, z));
        assertEquals(at("Asia/Dhaka", 2026, 10, 18, 0, 0, 0), DateRules.nextMidnight(today, z));
    }
    @Test public void dstDaysAreNotAlways24Hours() {
        TimeZone z = TimeZone.getTimeZone("America/New_York");
        long spring = at(z.getID(), 2026, 3, 8, 0, 0, 0);
        long fall = at(z.getID(), 2026, 11, 1, 0, 0, 0);
        assertEquals(23 * 3600000L, DateRules.nextMidnight(spring, z) - spring);
        assertEquals(25 * 3600000L, DateRules.nextMidnight(fall, z) - fall);
    }
    @Test public void aliasesUsePhoneTimezoneAndCorrectWeekday() {
        long now = at("Asia/Dhaka", 2026, 10, 18, 0, 0, 0);
        assertEquals("Alias0_18", DateRules.alias(now, TimeZone.getTimeZone("Asia/Dhaka")));
        assertEquals("Alias6_17", DateRules.alias(now, TimeZone.getTimeZone("UTC")));
        assertEquals("Alias5_01", DateRules.alias(at("UTC", 2027, 1, 1, 0, 0, 0), TimeZone.getTimeZone("UTC")));
    }
    @Test public void dstMidnightGapAndSkippedCivilDayStayInFuture() {
        TimeZone sao = TimeZone.getTimeZone("America/Sao_Paulo");
        long beforeGap = at(sao.getID(), 2018, 11, 3, 22, 0, 0);
        Calendar c = Calendar.getInstance(sao);
        c.setTimeInMillis(DateRules.nextMidnight(beforeGap, sao));
        assertEquals(4, c.get(Calendar.DAY_OF_MONTH));
        assertEquals(1, c.get(Calendar.HOUR_OF_DAY));
        TimeZone apia = TimeZone.getTimeZone("Pacific/Apia");
        long beforeSkip = at(apia.getID(), 2011, 12, 29, 12, 0, 0);
        c = Calendar.getInstance(apia);
        c.setTimeInMillis(DateRules.nextMidnight(beforeSkip, apia));
        assertEquals(31, c.get(Calendar.DAY_OF_MONTH));
        assertEquals(0, c.get(Calendar.HOUR_OF_DAY));
    }
    @Test public void everyTimezoneEveryDayAcrossLeapAndDstYears() {
        // 612k+ local date computations, including rare historical timezone offsets.
        for (String zone : TimeZone.getAvailableIDs()) {
            TimeZone z = TimeZone.getTimeZone(zone);
            Calendar c = Calendar.getInstance(z, Locale.US);
            c.clear(); c.set(2026, Calendar.JANUARY, 1, 12, 34, 56);
            for (int day = 0; day < 1096; day++, c.add(Calendar.DAY_OF_MONTH, 1)) {
                long now = c.getTimeInMillis(), next = DateRules.nextMidnight(now, z);
                assertTrue(zone, next > now);
                assertTrue(zone, next - now <= 27 * 3600000L);
                String alias = DateRules.alias(now, z);
                assertTrue(zone + " " + alias, alias.matches("Alias[0-6]_(0[1-9]|[12][0-9]|3[01])"));
            }
        }
    }
}
